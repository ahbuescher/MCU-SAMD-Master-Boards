/*
  Copyright (c) 2014-2015 Arduino LLC.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
  update for SAMD21J18
*/


#pragma once

// The definitions here needs a SAMD core >=1.6.10
#define ARDUINO_SAMD_VARIANT_COMPLIANCE 10610

#include <WVariant.h>

// General definitions
// -------------------

// Frequency of the board main oscillator
#define VARIANT_MAINOSC (32768ul)

// Master clock frequency
#define VARIANT_MCK     (48000000ul)

// Pins
// ----
// Number of pins defined in PinDescription array
#ifdef __cplusplus
extern "C" unsigned int PINCOUNT_fn();
#endif
#define PINS_COUNT           (PINCOUNT_fn())
// #define PINS_COUNT           (40u)
#define NUM_DIGITAL_PINS     (28u)
#define NUM_ANALOG_INPUTS    (9u)
#define NUM_ANALOG_OUTPUTS   (1u)

// Low-level pin register query macros
// -----------------------------------
#define digitalPinToPort(P)      (&(PORT->Group[g_APinDescription[P].ulPort]))
#define digitalPinToBitMask(P)   (1 << g_APinDescription[P].ulPin)
//#define analogInPinToBit(P)    ()
#define portOutputRegister(port) (&(port->OUT.reg))
#define portInputRegister(port)  (&(port->IN.reg))
#define portModeRegister(port)   (&(port->DIR.reg))
#define digitalPinHasPWM(P)      (g_APinDescription[P].ulPWMChannel != NOT_ON_PWM || g_APinDescription[P].ulTCChannel != NOT_ON_TIMER)

/*
 * digitalPinToTimer(..) is AVR-specific and is not defined for SAMD
 * architecture. If you need to check if a pin supports PWM you must
 * use digitalPinHasPWM(..).
 *
 * https://github.com/arduino/Arduino/issues/1833
 */
// #define digitalPinToTimer(P)

//Battery
#define ADC_BATTERY (46u)

//NINA
#define NINA_GPIO0  (44u)
#define NINA_RESETN (45u)
#define NINA_ACK    (49u)


//VREF
#define PIN_VREF     (39u)
#define VREF         PIN_VREF

// LEDs
// ----
#define PIN_LED     (1u)
#define LED_BUILTIN PIN_LED


//Digital pins
//------------
#define PIN_D00 (0u)
#define PIN_D01 (1u)
#define PIN_D02 (2u)
#define PIN_D03 (3u)
#define PIN_D04 (4u)
#define PIN_D05 (5u)
#define PIN_D06 (6u)
#define PIN_D07 (7u)
#define PIN_D08 (8u)
#define PIN_D09 (9u)
#define PIN_D10 (10u)
#define PIN_D11 (11u)
#define PIN_D12 (12u)
#define PIN_D13 (13u)
#define PIN_D14 (14u)
#define PIN_D15 (15u)
#define PIN_D16 (16u)
#define PIN_D17 (17u)
#define PIN_D18 (18u)
#define PIN_D19 (19u)

// Digital PIN D0 - D10
static const uint8_t D0          = PIN_D00;
static const uint8_t D1          = PIN_D01;
static const uint8_t D2          = PIN_D02;
static const uint8_t D3          = PIN_D03;
static const uint8_t D4          = PIN_D04;
static const uint8_t D5          = PIN_D05;
static const uint8_t D6          = PIN_D06;
static const uint8_t D7          = PIN_D07;
static const uint8_t D8          = PIN_D08;
static const uint8_t D9          = PIN_D09;
static const uint8_t D10         = PIN_D10;

// Raspberry PI PINs
static const uint8_t RPI_CE1     = PIN_D00;
static const uint8_t GPIO21      = PIN_D01;
static const uint8_t GPIO22      = PIN_D02;
static const uint8_t GPIO23      = PIN_D03;
static const uint8_t GPIO24      = PIN_D04;
static const uint8_t GPIO25      = PIN_D05;
static const uint8_t GPIO26      = PIN_D06;
static const uint8_t GPIO27      = PIN_D07;
static const uint8_t GPIO28      = PIN_D08;
static const uint8_t GPIO29      = PIN_D09;
static const uint8_t RPI_CE0     = PIN_D10;

// Digital PIN D11 - D19
static const uint8_t CON_I2C_RST = PIN_D11;
static const uint8_t CON_SPI_CS  = PIN_D12;
static const uint8_t CON_SPI_DC  = PIN_D13;
static const uint8_t CON_SPI_RST = PIN_D14;
static const uint8_t RTC_INT     = PIN_D15;
static const uint8_t RTC_RST     = PIN_D16;
static const uint8_t SDCARD_CS   = PIN_D17;
static const uint8_t EEPROM_CS   = PIN_D18;
static const uint8_t BUZZER      = PIN_D19;

// Analog pins
// -----------
#define PIN_A00  (27u)
#define PIN_A01  (28u)
#define PIN_A02  (29u)
#define PIN_A03  (30u)
#define PIN_A04  (31u)
#define PIN_A05  (32u)
#define PIN_A06  (33u)
#define PIN_A07  (34u)
#define PIN_A08  (35u)

// Analog PIN A0 - A7
static const uint8_t A0   = PIN_A00;
static const uint8_t A1   = PIN_A01;
static const uint8_t A2   = PIN_A02;
static const uint8_t A3   = PIN_A03;
static const uint8_t A4   = PIN_A04;
static const uint8_t DAC0 = PIN_A04;
static const uint8_t A5   = PIN_A05;
static const uint8_t A6   = PIN_A06;
static const uint8_t A7   = PIN_A07;


// Raspberri Pi PINs
static const uint8_t GPIO0 = PIN_A00;
static const uint8_t GPIO1 = PIN_A01;
static const uint8_t GPIO2 = PIN_A02;
static const uint8_t GPIO3 = PIN_A03;
static const uint8_t GPIO4 = PIN_A04;
static const uint8_t GPIO5 = PIN_A05;
static const uint8_t GPIO6 = PIN_A06;
static const uint8_t GPIO7 = PIN_A07;

static const uint8_t LIGHT_SENSOR = PIN_A08;


#define ADC_RESOLUTION 12

// SPI Interfaces
// --------------
#define SPI_INTERFACES_COUNT 2

// SPI
#define PIN_SPI_MOSI  (20u)
#define PIN_SPI_SCK   (21u)
#define PIN_SPI_MISO  (22u)
#define PIN_SPI_SS    (4u)                // SPI Slave SS not used. Set here only for reference.
#define PERIPH_SPI    sercom1
#define PAD_SPI_TX    SPI_PAD_0_SCK_1
#define PAD_SPI_RX    SERCOM_RX_PAD_3

static const uint8_t SS   = PIN_SPI_SS;   // SPI Slave SS not used. Set here only for reference.
static const uint8_t MOSI = PIN_SPI_MOSI;
static const uint8_t MISO = PIN_SPI_MISO;
static const uint8_t SCK  = PIN_SPI_SCK;

// SPI1
#define PIN_SPI1_MOSI    (40u)
#define PIN_SPI1_MISO    (41u)
#define PIN_SPI1_SS      (42u)
#define PIN_SPI1_SCK     (43u)
#define PIN_SPI1_CE1     (7u)
#define PERIPH_SPI1   sercom4
#define PAD_SPI1_TX   SPI_PAD_0_SCK_3
#define PAD_SPI1_RX   SERCOM_RX_PAD_1
static const uint8_t SS1   = PIN_SPI1_SS;
static const uint8_t CE1   = PIN_SPI1_CE1;
static const uint8_t MOSI1 = PIN_SPI1_MOSI;
static const uint8_t MISO1 = PIN_SPI1_MISO;
static const uint8_t SCK1  = PIN_SPI1_SCK;

#define SPIWIFI_SS       PIN_SPI1_SS
#define SPIWIFI_ACK      NINA_ACK
#define SPIWIFI_RESET    (~NINA_RESETN)   // fixme! Inverted logic


// Wire Interfaces
// ---------------
#define WIRE_INTERFACES_COUNT 1

// Wire
#define PIN_WIRE_SDA        (23u)
#define PIN_WIRE_SCL        (24u)
static const uint8_t SDA = PIN_WIRE_SDA;
static const uint8_t SCL = PIN_WIRE_SCL;

#define PERIPH_WIRE         sercom2
#define WIRE_IT_HANDLER     SERCOM2_Handler

// USB
// ---
#define PIN_USB_DM          (36ul)
#define PIN_USB_DP          (37ul)
#define PIN_USB_HOST_ENABLE (38ul)

// I2S Interfaces
// --------------
#define I2S_INTERFACES_COUNT 1

#define I2S_DEVICE          0
#define I2S_CLOCK_GENERATOR 3
#define PIN_I2S_SD          (PIN_A00)  // PA07
#define PIN_I2S_SCK         (5u)       // PA10
#define PIN_I2S_FS          (10u)      // PA11

// Serial ports
// ------------
#ifdef __cplusplus
#include "SERCOM.h"
#include "Uart.h"

// Instances of SERCOM
extern SERCOM sercom0;
extern SERCOM sercom1;
extern SERCOM sercom2;
extern SERCOM sercom3;
extern SERCOM sercom4;
extern SERCOM sercom5;

// Serial1
extern Uart Serial1;
#define PIN_SERIAL1_RX (25ul)
#define PIN_SERIAL1_TX (26ul)
static const uint8_t RXD = PIN_SERIAL1_RX;
static const uint8_t TXD = PIN_SERIAL1_TX;

#define PAD_SERIAL1_TX (UART_TX_PAD_2)
#define PAD_SERIAL1_RX (SERCOM_RX_PAD_3)

// Serial2
extern Uart Serial2;
#define PIN_SERIAL2_RX (41ul)
#define PIN_SERIAL2_TX (40ul)
#define PAD_SERIAL2_TX (UART_TX_RTS_CTS_PAD_0_2_3)
#define PAD_SERIAL2_RX (SERCOM_RX_PAD_1)
#define PIN_SERIAL2_RTS (42u)
#define PIN_SERIAL2_CTS (43u)

#endif // __cplusplus

#ifdef __cplusplus
extern "C" {
#endif
unsigned int PINCOUNT_fn();
#ifdef __cplusplus
}
#endif

// These serial port names are intended to allow libraries and architecture-neutral
// sketches to automatically default to the correct port name for a particular type
// of use.  For example, a GPS module would normally connect to SERIAL_PORT_HARDWARE_OPEN,
// the first hardware serial port whose RX/TX pins are not dedicated to another use.
//
// SERIAL_PORT_MONITOR        Port which normally prints to the Arduino Serial Monitor
//
// SERIAL_PORT_USBVIRTUAL     Port which is USB virtual serial
//
// SERIAL_PORT_LINUXBRIDGE    Port which connects to a Linux system via Bridge library
//
// SERIAL_PORT_HARDWARE       Hardware serial port, physical RX & TX pins.
//
// SERIAL_PORT_HARDWARE_OPEN  Hardware serial ports which are open for use.  Their RX & TX
//                            pins are NOT connected to anything by default.
#define SERIAL_PORT_USBVIRTUAL      SerialUSB
#define SERIAL_PORT_MONITOR         SerialUSB
#define SERIAL_PORT_HARDWARE        Serial1
#define SERIAL_PORT_HARDWARE_OPEN   Serial1

// Alias Serial to SerialUSB
#define Serial                      SerialUSB

// Alias Serial1 to SerialNina (useful in libraries)
#define SerialNina                   Serial1

#define SPIWIFI                     SPI1

