// Copyright 2021 <Hermann Buescher>
//
// This is a library for the MCU-Modul V 4.01
// 
// Die Kommunikation erfolgt über die Serielle Schnittstelle.
//   Mit # kommt man in den Command Mode und kann die verschiedenen
//   Funktionen des Moduls einstellen.
//
//
// WLAN/MQTT
//   WLAN                   : wl[an]        (Y/N, SSID, Password)
//   MQTT                   : mq[tt]        (Y/N, Servername, Port, User)
//
// Sensors - BME 680 und Lichtstärke
//    Sensoren              : se[nsors]     (Y/N, 
//                                           Flash addr 1000 - 1.500.000,
//                                           size x 64KB)
// Logbook
//    Browse                : br[owse]      Einträge im Logbuch lesen
//    Logbook               : lo[gbook]     (Y/N, 
//                                           Flash addr 1000 - 1.500.000,
//                                                   size x 64KB)
// Clock: 
//   Einstellung Datum      : da[te]        (DDMMYYYY)
//   Einstellung Zeit       : ti[me]        (SSMMHH)
//
// Other
//    Battery               : ba[ttery] =>  BQ24195 Controller Mode 
//    OLED-Display          : ol[ed]        (Y/N)
//    RGB-LED               : rg[led]       (Y/N)
//
// Backup
//    Flash löschen         : er[flash]
//    Backup auf SD-Card    : sd[card]      (Y/N  SSMMHH)
//
// ECCX08                                (Slot  8 - Setup Parameter
//    Lade Setup - Slot8    : lx[ECCX08] (Slot  9 - WLAN IP, SSID, PW)
//    Sichere Setup - Slot8 : sx[[ECCX08](Slot 10 - MQTT IP, Port, User)
//
// Debug
//    Debug Mode            : de[bug]    (Y/N)
//    Debug tracking        : dt[track]  (Y/N)
//    Dump Memory           : du[ump]    => Dump Buffer Mode
//    Liste Setup           : li[st]
//    SRAM Memory Belegung  : me[mory]   (Y/N , SRAM Adress, DRAM Adress)
//
//  System
//    Modul                 : mo[dul]    = alle Funktionen ein/aus
//    Reboot                : [re]bo[ot] = Neustart sofort oder tgl. (SSMMHH)
//    Reset                 : re[set]    = alle Einstellungen werden gelöscht!
//    Test                  : te[st]     = Testfunktionen soweit vorhanden
//    Wacht Dog             : wa[tchDog] = Interrupt für System Neustart
//
//  Exit
//    Exit Command Mode     : ex[it]     (Y/N) 


// List of include libraries of the MCU_BasicModul 2.23:

// Arduino IDE
ArduinoCore-SAMD-Master Version 1.8.6 installed
- Wire.h
- SD.h
- SPI.h

// Wifi
WIFININA by Arduino Version 1.8.0 installed
- WIFININA.h
- ../src/utility/wifi_drv.h
- Firmware 1.4.0

// MQTT
MQTT by Joel Gaehwiler Version 2.4.8 installed
- MQTT.h

// Crypto
Arduino ECCX08 Version 1.3.4 installed
- ArduinoECCX08.h

// Clock
Arduino library for the DS3231 Version 1.0.2 installed 
by Andrew Wickert,Eric Ayars, Jean-Claude Wipper, Northern Widget
- RTClib.h

// Battery-Controller BQ24195
updated Version of Arduino_BQ24195 Beta 0.9.1
- Arduino_BQ24195_own.h

// Sensor BME 680
BSEC-Arduino-Master by Bosch Version 1.6.1480 installed
- bsec.h

// Utilities
MemoryFree by Michael P. Flaga
https://github.com/mpflaga/Arduino-MemoryFree.git
- MemoryFree.h

// Flash-Memory
SPIMemory by Prajwal Bhattram Version 3.4.0 installed
- SPIMemory.h

// OLED Display
GFX library by Adafruit Version 1.10.4 installed
- Adafruit_GFX.h

SSD1306 by Adafruit Version 2.4.1 installed
- Adafruit_SSD1306.h
 
// WatchDog
SleepyDog by Adafruit Version 1.3.2 installed
- Adafruit_SleepyDog.h
