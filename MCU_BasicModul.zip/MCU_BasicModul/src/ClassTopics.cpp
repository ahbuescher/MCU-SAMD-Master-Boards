// copyright 2019 <Hermann Buescher>
#include "./ClassTopics.h"

String tp_User(String username) {
  return TP_CLIENT + username;
}

String tp_Device(String username, String device) {
  return TP_CLIENT + username + device;
}

String tp_DeviceStatus(String username, String device, String id) {
  return TP_CLIENT + username + device + id + TP_STATUS;
}
