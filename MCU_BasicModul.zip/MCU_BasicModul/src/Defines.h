// Copyright 2020 <Hermann Buescher>
#ifndef DEFINES_H_
#define DEFINES_H_

#define ARDUINO_ARCH_SAMD_MCU

#define BASICMODUL_VERSION  "4.02"

#define SERIAL_COM_SPEED    9600

#define ESC                 0x1B
#define BS                  0x08
#define CR                  0x0D

// OLED Display Text
//#define DISPLAY_OTHER

// RTC DS3231 Interrupt every second
// RTC_INT is low every new second
#define NEWSECOND !digitalRead(RTC_INT)

// Battery
#define ADC_BATTERY_PRESENT 125
#define CHRG_STARTING_VOLT  3.5

// Pin definitions of RGB-LED
#define PIN_RGBLED_BLUE  25
#define PIN_RGBLED_RED   26
#define PIN_RGBLED_GREEN 27

// System message types
#define MSG_BAT    "BAT"
#define MSG_ECCX08 "ECCX" 
#define MSG_FLASH  "FLASH"
#define MSG_LOGBK  "LOGBK"
#define MSG_MQTT   "MQTT"
#define MSG_RAM    "RAM"
#define MSG_SDCARD "SD"
#define MSG_SENSOR "SENSO"
#define MSG_SYS    "SYS"
#define MSG_SYS_   "SYS"
#define MSG_WLAN   "WiFi"

#define TEMPERATURE_OFFSET     5.0

// Class record
#define MAX_DATA_FIELD_ELEMENTS 10
#define GET_STRING_BUFFER      200
// #define END_OF_RECORDS    0xFFFFFFFF
#define RECORD_ID         *(uint32_t *)dataField[0].field

#define MAX_NUM_OF_RECORDS     10000
#define NONE                   99999

// ECCX08
#define SLOT_SETUP                 8
#define SLOT_SSID_PWD              9
#define SLOT_MQTT                 10

// Connect WLAN-/ MQTT 
#define LOGIN_SERVERNAME_LEN      18
#define LOGIN_PORT_LEN             5
#define LOGIN_USERNAME_LEN        10
#define LOGIN_PASSWORD_LEN        20
#define LOGIN_DELAY_WLAN          10
#define LOGIN_DELAY_MQTT           5

#define CAPACITY_MQTT            250

#define FREQ_WLAN                 1    // login every  x minutes not used
#define FREQ_BACKUPRECORDONFLASH  1    // backup on Flash every x minutes
#define FREQ_ALARM               -1    // no scheduled alarm time
#define FREQ_PUBSENSOR            1    // sensor not published

#define ERRORCOUNT_REBOOT_MAX_TRY   2  // max attempts to reboot
#define ERRORCOUNT_WLAN_TRYPERLOGIN 3  // max x attempts during login
#define ERRORCOUNT_WLAN_MAX_TRY     2  // max x + 2 login attempts
#define ERRORCOUNT_MQTT_TRYPERLOGIN 3  // max x login attempts
#define ERRORCOUNT_MQTT_MAX_TRY     2  // max x attempts during login

#define ERRCODE_SYS                10
#define ERRCODE_WLAN               20
#define ERRCODE_MQTT               30
#define ERRCODE_MQTT_RETURNCODE    40
#define ERRCODE_PMIC               50
#define ERRCODE_FLASH              60
#define ERRCODE_DISABLED           99

// Serial Buffer for snprintf
#define S_LEN_OF_SERIALBUFFER   80

// Logbook
#define LBK_LEN_OF_MESSAGE     120
#define LBK_PAGESIZE            20
#define LBK_MAX_OF_LISTOFERRORS 40

// Trigger options
#define _ALARM_()             Function::alarm
#define _AIRQUALITYALARM_()   Function::airQualityAlarm
#define _BATTERYAUTOONOFF_()  Function::batteryAutoOnOff
#define _BATTERYBOOSTER_()    Function::batteryBooster
#define _BATTERYCHARGING_()   Function::batteryCharging
#define _BACKUPONFLASH_()     Function::backupRecordOnFlash
#define _CLIENTLOOP_()        Function::clientLoop
#define _PUBLISHDATA_()       Function::publishData
#define _PUBLISH_WATCHDOG_()  Function::publish_WatchDog
#define _BACKUPONSD_()        Function::backupOnSD
#define _DEBUG_()             Function::debug
#define _DEBUGTRACK_()        Function::debugTrack
#define _EXIT_()              Function::exitCmd
#define _LOGBOOK_()           Function::logbook
#define _MODUL_()             Function::modul
#define _MQTT_()              Function::mqtt
#define _MQTTBEGIN_()         Function::mqttBegin
#define _MQTTPUBLISHED_()     Function::mqttPublished
#define _TOSUBSCRIBEMQTT_()   Function::toSubscribeMQTT
#define _OLED_()              Function::oled
#define _OLEDINIT_()          Function::oledInit
#define _REBOOT_()            Function::reboot
#define _RESTORE_()           Function::restore   // Variables->ECCX08
#define _RGBLED_()            Function::rgbLed
#define _SENSORS_()           Function::sensors
#define _SECURITYMODE_()      Function::securityMode
#define _WATCHDOG_()          Function::watchDog
#define _WLAN_()              Function::wlan

#endif  // DEFINES_H_
