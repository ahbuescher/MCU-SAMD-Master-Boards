// Copyright 2021 <Hermann Buescher>
#include "./DisplayOther.h"

#ifdef DISPLAY_OTHER
void displayOther(Adafruit_SSD1306 display) {
  // if (_ALARM_() && rtc.alarmFired(2)) {
  //   display.println("Hello world");
  
}
#endif
