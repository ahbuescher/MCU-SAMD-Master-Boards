// Copyright 2020 <Hermann Buescher>
#include "./ClassState.h"
#include <stdio.h>

//  State____________________________________________________

State::State() {}

void State::update() {
  // RTC DS3231 Interrupt every second
  rtc.clearAlarm(1);

  // Every second ....
  // Update time, sensors, OLED Display, RGBLED
  now = rtc.now();

  pmic.update();
  
  if (_SENSORS_()) {
    sensors.readSensors();
    sensors.updateIAQStateOnRGB_LED();
  }

  if (_OLED_())
    displayDisplay();

  // Every minute...
  // Update flash memory, publish data, backup on SD-Card, 
  // Battery charging completed, LowBattery
  if (now.minute() != this->timeForEvent.minute.upToDate) {
    this->timeForEvent.minute.upToDate = now.minute();
    if (_SENSORS_()) {
      // Time for backing up record on flash
       if ( _BACKUPONFLASH_()) {
        if (this->timeForEvent.minute.flash == now.minute()) {
          this->timeForEvent.minute.flash = \
              (now.minute() + this->freq.backupRecordOnFlash) % 60;
          sensors.backupRecordOnFlash();
        }
      }
      // Time for publishing sensor data
      if (_MQTT_() && _PUBLISHDATA_()) {
        if (this->timeForEvent.minute.sensor == now.minute()) {
          this->timeForEvent.minute.sensor = \
                      (now.minute() + this->freq.pubSensor) % 60;
          publishSensorsState();
        }
      }
    }
    
    // Check Battery Charging completed
    if (_BATTERYCHARGING_() && pmic.chargerEnabled && !pmic.chargingCompleted) {
      chargingCompleted();
    }

    // Check Low Battery Voltage
    if (!pmic.isPowerGood()) {
      updateLowBatteryFlag();
    }

    if (_ALARM_() && rtc.alarmFired(2)) {
      rtc.clearAlarm(2);
       // Time for backing up data on SD-Card
      if (_BACKUPONSD_()) 
        fullBackupOnSD_Card();
      // Start system reboot
       if (_REBOOT_())
        systemReboot_checkOnFuncDisabled();
    }
  }
}

void State::init() {
  // error counter
  this->errorCount.wlan.login       = 0;
  this->errorCount.wlan.tryPerLogin = ERRORCOUNT_WLAN_TRYPERLOGIN;
  this->errorCount.wlan.maxTry      = ERRORCOUNT_WLAN_MAX_TRY;
  this->errorCount.mqtt.login       = 0;
  this->errorCount.mqtt.tryPerLogin = ERRORCOUNT_MQTT_TRYPERLOGIN;
  this->errorCount.mqtt.maxTry      = ERRORCOUNT_MQTT_MAX_TRY;
  
  // frequency
  this->freq.wlan                  = FREQ_WLAN;
  if (!_RESTORE_()) {                // if not stored in ECCX08
    this->freq.backupRecordOnFlash = FREQ_BACKUPRECORDONFLASH;
    this->freq.pubSensor           = FREQ_PUBSENSOR;
    this->freq.alarm               = FREQ_ALARM;
  }
  
  // update time
  this->updateTimeForEvent();
}

void State::updateTimeForEvent() {
  // update time
  now = rtc.now();                    //  get actual time

  this->timeForEvent.day.upToDate    = 0;
  this->timeForEvent.hour.upToDate   = 0;
  this->timeForEvent.minute.upToDate = now.minute();
  this->timeForEvent.second.upToDate = now.second(); 
    
  this->timeForEvent.minute.flash = (now.minute()                       \
                                   + this->freq.backupRecordOnFlash) % 60;
  this->timeForEvent.minute.sensor   = (now.minute()                     \
                                   + this->freq.pubSensor) % 60;
  this->timeForEvent.minute.wlan  = (now.minute()                       \
                                   + this->freq.wlan) % 60;
}

void  State::countCheckerAfterReboot() {
  if (this->errorCount.wlan.reboot == ERRCODE_DISABLED \
   || this->errorCount.mqtt.reboot == ERRCODE_DISABLED) {
    if (this->errorCount.wlan.reboot == ERRCODE_DISABLED) {
      clearErrorCountWLAN_();
     _WLAN_() = true;
      if (this->errorCount.mqtt.reboot > 0) {
       clearErrorCountMQTT_();
       _MQTT_() = true;
     }
    }
    if (this->errorCount.mqtt.reboot == ERRCODE_DISABLED) {
      clearErrorCountMQTT_();
      _MQTT_() = true;
    }
    saveSetupECCX08();
   }
}

void State::clearErrorCountWLAN_() {
  this->errorCount.wlan.login = 0;
  this->errorCount.wlan.reboot = 0;
}

void State::clearErrorCountMQTT_() {
  this->errorCount.mqtt.login = 0;
  this->errorCount.mqtt.reboot = 0;
}