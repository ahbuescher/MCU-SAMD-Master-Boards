// Copyright 2020 <Hermann Buescher>
#include "./ClassTrigger.h"

boolean Function::alarm;
boolean Function::airQualityAlarm;
boolean Function::batteryAutoOnOff;
boolean Function::batteryBooster;
boolean Function::batteryCharging;
boolean Function::backupRecordOnFlash;
boolean Function::backupOnSD;
boolean Function::clientLoop;
boolean Function::debug;
boolean Function::debugTrack;
boolean Function::exitCmd;
boolean Function::logbook;
boolean Function::modul;
boolean Function::mqtt;
boolean Function::mqttBegin;
boolean Function::mqttPublished;
boolean Function::oled;
boolean Function::oledInit;
boolean Function::publishData;
boolean Function::reboot;
byte    Function::restore;
boolean Function::rgbLed;
boolean Function::sensors;
boolean Function::securityMode;
boolean Function::toSubscribeMQTT;
boolean Function::watchDog;
boolean Function::wlan;


void Function::init() {
  Function::alarm                      = false;
  Function::airQualityAlarm            = false;
  Function::batteryAutoOnOff           = false;
  Function::batteryBooster             = false;
  Function::batteryCharging            = false;
  Function::backupRecordOnFlash        = false;
  Function::clientLoop                 = false;
  Function::backupOnSD                 = false;
  Function::debug                      = true;
  Function::debugTrack                 = false;
  Function::exitCmd                    = false;
  Function::logbook                    = false;
  Function::modul                      = true;
  Function::mqtt                       = false;
  Function::mqttBegin                  = false;
  Function::mqttPublished              = false;
  Function::oled                       = false;
  Function::oledInit                   = false;
  Function::publishData                = false;
  Function::reboot                     = false;
  Function::restore                    = false;
  Function::rgbLed                     = false;
  Function::sensors                    = false;
  Function::securityMode               = false;
  Function::toSubscribeMQTT            = false;
  Function::watchDog                   = false;
  Function::wlan                       = false;

}

