// Copyright 2020 <Hermann Buescher>
#ifndef CLASSSENSORS_H_
#define CLASSSENSORS_H_

#include <Arduino.h>
#include <RTClib.h>
#include <Wire.h>
#include <bsec.h>
#include "./Defines.h"
#include "./ClassLED.h"
#include "./ClassRecord.h"
#include "./ClassTrigger.h"

extern Bsec bsec;

// include ModulThings
void eraseFlashSection(uint32_t first, uint32_t size);
void errLeds(int j);
int  nextFreePos(char *buffer, int x);
void printPageBytes(uint32_t addr, byte *data_buffer, int size);

// Specific data structure specific_____________________________________

class SensorData:public TimeStamp  {
 public:
  float rawTemperature;
  float temperature;
  float pressure;
  float rawHumidity;
  float humidity;
  float iaq;
  float light;
};

//  Sensors_____________________________________________________________
class Sensors:public Record {
 public:
  Sensors();
  float      temperatureOffset;
  SensorData data;

  void   bme680init();
  void   setTemperatureOffset(float temperatureOffset);
  void   setNewTemperatureOffset();
  void   checkBME680State();
  String pubIAQStatus();
  void   setRecord();
  void   readSensors();
  void   updateIAQStateOnRGB_LED(); 
};

#endif  // CLASSSENSORS_H_
