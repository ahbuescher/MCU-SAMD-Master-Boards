// Copyright 2019 <Hermann Buescher>
#ifndef CLASSLOGBOOK__H_
#define CLASSLOGBOOK__H_

#include <Arduino.h>
#include <RTClib.h>
#include <Wire.h>
#include <bsec.h>
#include "./Defines.h"
#include "./ClassRecord.h"
#include "./ClassTrigger.h"

// include files
// ModulLogbook
void   clearListOfErrors();
void   add2ListOfErrors();

// include ModulThings
void   eraseFlashSection(uint32_t first, uint32_t size);
void   errLeds(int j);
void   analogwrite_RGB_LED(int green, int red, int blue);
int    nextFreePos(char *buffer, int x);
void   printPageBytes(uint32_t addr, byte *data_buffer, int size);
String readSerialStringCmd(int len);

// Specific data structure _____________________________________

class LogbookData:public TimeStamp {
 public:
  int  errCode;
  char message[LBK_LEN_OF_MESSAGE] = "";
};

//  Logbook_____________________________________________________________

class Logbook:public Record {
 public:
   LogbookData data;
   bool        overrun;
   
  void   backupRecordOnFlash();
  String getRecord(uint32_t addr);
  void   setRecord();
};

#endif //  CLASSLOGBOOK_H_
