// Copyright 2021 <Hermann Buescher>
#include "./ClassBattery.h"

const float factor     = 4.18/1024.0;

MessageStruct bqChargeStatusDesc[] = {{5, "Charge Status"},    \
       {NOT_CHARGING, "NOT_CHRG"},                             \
       {PRE_CHARGING, "PRE_CHRG"},                             \
       {FAST_CHARGING, "FAST_CHRG"},                           \
       {CHARGE_TERMINATION_DONE, "CHRG_TERM_DONE"}};
MessageStruct bqChargeFaultDesc[]  = {{5, "Charge Fault"},  \
       {NO_CHARGE_FAULT,"NO_FAULT"},                           \
       {INPUT_OVER_VOLTAGE, "INPUT_OVERVOLT"},                 \
       {THERMAL_SHUTDOWN, "THERM_SHUTDOWN"},                   \
       {CHARGE_SAFETY_TIME_EXPIRED, "SAFETY_TIMEEXP"}};
MessageStruct bqVBusStatusDesc[]   = {{5, "VBUS"},    \
       {UNKNOWM_MODE,"UNKNOWN_Mode"},                          \
       {USB_HOST_MODE,"USB_HOST_MODE"},                        \
       {ADAPTER_PORT_MODE,"ADAPTER_PORT_MODE"},                \
       {BOOST_MODE,"BOOST_MODE"}};
MessageStruct bqTermalFaultDesc[]  = {{4, "Termal Fault"},\
       {NO_TEMPERATURE_FAULT,"NO_TEMPERATURE_FAULT"},\
       {LOWER_THRESHOLD_TEMPERATURE_FAULT, "LOWER_THRESHOLD_TEMPERATURE_FAULT"},\  
       {HIGHER_THRESHOLD_TEMPERATURE_FAULT,"HIGHER_THRESHOLD_TEMPERATURE_FAULT"}};

void PMIC_Object::init() {
  name = description[0].text;
  code = 255;
  message = "-";
  voltage = 0;
  newEvent = false;
}

char*  PMIC_Object::findText(int key) {
  int last = description[0].key;
  for (int i = 1; i < last; i++) {
    if (key == description[i].key) {
      return description[i].text; // text found
    }
  }
  return "unkown";     // not found
}

boolean PMIC_Object::update(int actCode) {
  if (code != actCode) {
    newEvent = true;
    code = actCode;
    message = findText(code);
    voltage = analogRead(ADC_BATTERY)*factor;
    time = rtc.now();
    if (_DEBUG_()) {
      snprintf(s, sizeof(s),PSTR("%2.2fV %s - %s"), \
                                voltage, name, message);
      xSerial.printDateTimeln(MSG_BAT, s);
    }
    return true;
  } else if (newEvent) {
      newEvent = false;
  }
  return false;
}

void PMIC::configure() {


  if (!begin()) {
    xSerial.printDateTimeln(MSG_BAT, "Failed to initialize PMIC!");
    errLeds(5);
  }

  // REG00 - Input source control register
  setInputVoltageLimit(4.36);  // lower Input voltage limit
  setInputCurrentLimit(2.0);   // 2.0A

  // REG01 - Power ON configuration register
  setMinimumSystemVoltage(3.5);// minimum system voltage limit
  // tbd. OTG

  // REG02 - Charge current control register
  setChargeCurrent(0.512);     // 768mA

  // REG03 - PRECHARGE_CURRENT_CONTROL_REGISTER
  // precharge current limit 256 mA (default)
  // termination current limit 256mA (default)

  // REG04 - Charge voltage control register
  // desired voltage (default 4.208) 
  // - 4112 is a safer termination voltage, if exposing the
  //   battery to temperatures above 45°C
  setChargeVoltage(4.112); // 4.112V termination voltage

  // Ports already defined - > see bootloader
  // init_ADC_BATTERY_PORT();

  init();
  enableCharger(false);
  if (_BATTERYBOOSTER_ () && !boosterEnabled)
    enableBooster(true);
}

void PMIC::init() {
  // variables
   chargerEnabled    = false;
   boosterEnabled    = false;
   BATFETEnabled     = false;
   batteryConnected  = false;
   chargingCompleted = false;
   chargingError     = false;
   lowBattery        = false;
   voltage           = 0;
   rgbLED.on         = false;
   rgbLED.toggle     = false;

  // link to bqMode description
   bqChargeStatus.description = bqChargeStatusDesc;
   bqChargeFault.description  = bqChargeFaultDesc;   
   bqVBusStatus.description   = bqVBusStatusDesc; 
   bqTermalFault.description  = bqTermalFaultDesc;

  // init bqModes
   bqChargeStatus.init();
   bqChargeFault.init();
   bqVBusStatus.init();
   bqTermalFault.init();

   // RGBLED
   rgbLED.off();
}

boolean PMIC::enableCharger(boolean enable) {
  boolean ok = false;
  if (enable) {  
    enableCharge();
    chargerEnabled    = true;
    boosterEnabled    = false;
    BATFETEnabled     = true;
    setColorOfChargeStatus();
    xSerial.printDateTimeln(MSG_BAT, "Charging mode is on");
  } else {
      disableCharge();
      chargerEnabled = false;
      BATFETEnabled  = false;
      if (!chargingCompleted)
        setColorLEDOff();
      xSerial.printDateTimeln(MSG_BAT, "Charging mode disabled!");
  }
  delay(300);
  return chargerEnabled;
}

boolean PMIC::enableBATFET(boolean enable = false) {
  if (enable) {
    enableBATFET();
    BATFETEnabled = true;
    xSerial.printDateTimeln(MSG_BAT, "BATFET enabled !");
  } else {
    BATFETEnabled = false;
    disableBATFET();
    xSerial.printDateTimeln(MSG_BAT, "BATFET disabled!");
  }
  delay(300);
  return BATFETEnabled;
}

boolean PMIC::enableBooster(boolean enable = false) {
  if (enable) {        
    if (chargerEnabled)
      enableCharger(false);
    if (enableBoostMode()) {
      delay(500);
      boosterEnabled = true;
      xSerial.printDateTimeln(MSG_BAT, "Booster mode is on");
    } else {
      boosterEnabled = false;
      xSerial.printDateTimeln(MSG_BAT, "Error enabling Boost Mode", ERRCODE_PMIC);
    }
  } else {
    boosterEnabled = false;
    enableCharger(true);
  }
  return boosterEnabled;
}

void  PMIC::setLedStatusOn() {
  if (!rgbLED.on) {
    rgbLED.on = true;
  }
}

void PMIC::setColorOfChargeStatus() {
  setLedStatusOn();
  if (bqChargeStatus.newEvent) {
    // USB power cabel is connected - charging mode changed - led is on
    if (bqChargeStatus.code == PRE_CHARGING) {
      rgbLED.setColor(xNAV_BLUE_1);
    } else if (bqChargeStatus.code == FAST_CHARGING) {
      rgbLED.setColor(xNAV_BLUE_2);
    } else if (bqChargeStatus.code == CHARGE_TERMINATION_DONE) {
      rgbLED.setColor(xNAVY_BLUE);
    }
    rgbLED.toggle = true;
  } else {
    // USB power cabel is connected - no change in charging mode - led flashes
    if (bqChargeStatus.code == PRE_CHARGING) {
      rgbLED.toggleColor(xNAV_BLUE_1, xNAVY_BLUE);
    } else if (bqChargeStatus.code == FAST_CHARGING) {
      rgbLED.toggleColor(xNAV_BLUE_2, xNAVY_BLUE);
    } else if (bqChargeStatus.code == CHARGE_TERMINATION_DONE) {
      rgbLED.toggleColor(xNAVY_BLUE, xDARK_GREEN);
    }
  }
}

void PMIC::setColorOfChargingCompleted() {
  setLedStatusOn();
  rgbLED.setColor(xDARK_GREEN);
}

void PMIC::setColorOfLowVoltage() {
  setLedStatusOn();
  if (bqChargeFault.newEvent) {
    rgbLED.setColor(xRED);
    rgbLED.toggle = true;
  } else {
    rgbLED.toggleColor(xRED, xBLACK);
  }
}


void PMIC::setColorOfChargingError() {
  setLedStatusOn();
  if (bqChargeFault.newEvent) {
    rgbLED.setColor(xRED);
    rgbLED.toggle = true;
  } else {
    rgbLED.toggleColor(xRED, xBLACK);
  }
}

void PMIC::setColorLEDOff() {
  if (rgbLED.on) {
    rgbLED.on = false;
    rgbLED.setColor(xBLACK); 
  }
}

boolean PMIC::update() {
  if (!isPowerGood()) {
    lowBatteryVoltage();
  }
  if (_BATTERYCHARGING_() && powerConnection()) {
      bqVBusStatus.update(USBmode());
      bqChargeStatus.update(chargeStatus());
      bqChargeFault.update(getChargeFault());
      bqTermalFault.update(hasBatteryTemperatureFault());
      if (chargingORTermal_Errors())
        return false;
      if (!chargingCompleted)
        setColorOfChargeStatus();
  } else {
    batteryConnection();
  }
  return true;
}

boolean PMIC::chargingORTermal_Errors() {
  if (bqChargeFault.code != 0) { 
    // Charge Fault
    error(bqChargeFault);
    return true;
  } else if (bqTermalFault.code != 0) {
    // Temperature Fault
    error(bqTermalFault);
    return true;
  }
  // No errors
  if (chargingError) {
    chargingError = false;
    setColorLEDOff();
  }
  if (!BATFETEnabled)
    enableBATFET(true);
  return false;
}

boolean PMIC::error(PMIC_Object object) {
  chargingError = true;
  setColorOfChargingError();
  playTones(TUNE_TOP_BUTTON_PRESS);
  snprintf(s, sizeof(s),PSTR("%s - %s"), \
                        object.name,  object.message);
  xSerial.printDateTimeln(MSG_BAT, s, ERRCODE_PMIC);
  if (BATFETEnabled)
    enableBATFET(false);
  return true;
}

boolean PMIC::powerConnection() {
  // When USB charger cabel is attached and mcu is not in booster mode, \
  // let´s begin with charging.
  if (isPowerGood() && batteryConnected) {
    if (chargerEnabled) {
      // Charge mode is on. Battery is charging
      return true;
    } else if (_EXIT_() \
          &&  (!_BATTERYAUTOONOFF_() || (_BATTERYAUTOONOFF_() && !chargingCompleted))) {
      // Turn charging mode on -  not active in command mode 
      enableCharger(true);
      lowBattery = false;
      return true;
    }
  } else if (!isPowerGood()) {
    // in BoosterMode: - isPowerGood() returns always false!
    if (chargerEnabled) {
      // => Power from Battery
      enableCharger(false);
    }
    if (chargingCompleted) {
      // isPowerGood() = true && !batteryConnected 
      // => USB power cabel is attached. Battery is detached 
      chargingCompleted = false;
      setColorLEDOff();
    }
  }
  return false;
}

// Ports already defined - > see bootloader
void PMIC::init_ADC_BATTERY_PORT() {
  pinMode(ADC_BATTERY, OUTPUT);
  digitalWrite(ADC_BATTERY, LOW);
  delay(10);
  pinMode(ADC_BATTERY, INPUT);
  delay(100);
}

boolean PMIC::isADC_BATTERYPresent() {
  if (analogRead(ADC_BATTERY)  > ADC_BATTERY_PRESENT ) {
    return true;
   } else {
    return false;
  }
}

boolean PMIC::batteryConnection() {
  // Event: battery is attachted or detached
  boolean batteryConnected_act;
  batteryConnected_act = isADC_BATTERYPresent();
  if (batteryConnected !=  batteryConnected_act) {
    batteryConnected = batteryConnected_act;
    // Battery detached
    if (!batteryConnected) {
      bqChargeStatus.init();
      chargingCompleted = false;
      setColorLEDOff();
    }
  }
  return batteryConnected;
}


float PMIC::updateBatteryVoltage() {
  voltage = analogRead(ADC_BATTERY)*factor;
  return voltage;
}

boolean PMIC::lowBatteryVoltage() {
  updateBatteryVoltage();
  if (voltage  < CHRG_STARTING_VOLT) {
    if (!lowBattery) {
      // lowBattery = true; -> see things - lowBattery()
      timeOfLowBattery = rtc.now();
      xSerial.printDateTimeln(MSG_BAT, "*** Low Battery Alarm!", ERRCODE_PMIC);
    }
    setColorOfLowVoltage();
    playTones(TUNE_TOP_BUTTON_PRESS);
  } else if (lowBattery) {
    lowBattery = false;
    xSerial.printDateTimeln(MSG_BAT, "Battery is ok!");
  }
  return lowBattery;
}

PMIC         pmic;
PMIC_Object  bqChargeStatus;
PMIC_Object  bqChargeFault;
PMIC_Object  bqVBusStatus;
PMIC_Object  bqTermalFault;