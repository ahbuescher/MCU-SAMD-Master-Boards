// Copyright 2020 <Hermann Buescher>
#include "./ClassSensors.h"


bsec_virtual_sensor_t sensorList[10] {
    BSEC_OUTPUT_RAW_TEMPERATURE,
    BSEC_OUTPUT_RAW_PRESSURE,
    BSEC_OUTPUT_RAW_HUMIDITY,
    BSEC_OUTPUT_RAW_GAS,
    BSEC_OUTPUT_IAQ,
    BSEC_OUTPUT_STATIC_IAQ,
    BSEC_OUTPUT_CO2_EQUIVALENT,
    BSEC_OUTPUT_BREATH_VOC_EQUIVALENT,
    BSEC_OUTPUT_SENSOR_HEAT_COMPENSATED_TEMPERATURE,
    BSEC_OUTPUT_SENSOR_HEAT_COMPENSATED_HUMIDITY,
};

Bsec bsec;

Sensors::Sensors() {}

void Sensors::setRecord() {
  data.recordId     = getNumOfRecords();
  data.date.year    = now.year();
  data.date.month   = now.month();
  data.date.day     = now.day();
  data.time.hour    = now.hour();
  data.time.minute  = now.minute();
  data.time.second  = now.second();
  readSensors();
}


void Sensors::bme680init() {
  bsec.begin(BME680_I2C_ADDR_PRIMARY, Wire);
  setTemperatureOffset(this->temperatureOffset);
  bsec.updateSubscription(sensorList, 10, BSEC_SAMPLE_RATE_LP);
  if (_DEBUG_()) {
    snprintf(s, sizeof(s), PSTR("BSEC lib V %d.%d.%d.%d"),\
                           bsec.version.major,\
                           bsec.version.minor,\
                           bsec.version.major_bugfix,\
                           bsec.version.minor_bugfix);
    xSerial.printDateTimeln(MSG_SYS, s);
    checkBME680State();
  }
}

void Sensors::setTemperatureOffset(float temperatureOffset) {
  if (this->temperatureOffset < 0  || this->temperatureOffset > 20)
    this->temperatureOffset = TEMPERATURE_OFFSET; // initial value
  bsec.setTemperatureOffset(this->temperatureOffset);
}

void Sensors::setNewTemperatureOffset() {
  // char s[80];
  float newTemperatureOffset;
  boolean update = false;
  boolean valid  = false;
  newTemperatureOffset = this->temperatureOffset;
  while(true) {
    snprintf(s, sizeof(s), PSTR("Temperature Offset is %.3f - ok?"),\
                                newTemperatureOffset);
    if (xSerial.ask(s) == "Y") {
      if (update) {
        this->temperatureOffset = newTemperatureOffset;
        setTemperatureOffset(this->temperatureOffset);
        snprintf(s, sizeof(s), PSTR("%s %.3f"), \
                                    "the temperature offset is ", \
                                    this->temperatureOffset);
        xSerial.printDateTimeln(MSG_SYS, s);
        checkBME680State();
      }
      return;
    } else if (xSerial.reTurn.esc) {
      return;
    }
    valid = false;
    while (!valid) {
      Serial.print("Please enter the new value (0.xxx - 20.xxx): ");
      newTemperatureOffset = xSerial.readString().toFloat();
      if (xSerial.reTurn.esc) {
        return;
      } else if (xSerial.reTurn.cr) {
        break;
      }
      if (rangeOfFloat.validate(newTemperatureOffset, 0.0, 20.0)) {
        update = true;
        valid = true;
      } else {
        xSerial.printDateTimeln("MSG_SENSOR","Value out of range!");
      }
    }
  }
}

void Sensors::checkBME680State() {
  if (bsec.status != BSEC_OK) {
    if (bsec.status < BSEC_OK) {
      snprintf(s, sizeof(s), PSTR("BSEC error code : %d"), bsec.status);
      xSerial.printDateTimeln(MSG_SYS, s);
      for (;;)
        errLeds(50);  // Halt in case of failure
    } else {
      snprintf(s, sizeof(s), PSTR("BSEC warning code : %d"), bsec.status);
      xSerial.printDateTimeln(MSG_SYS, s);
    }
  }
  if (bsec.bme680Status != BME680_OK) {
    if (bsec.bme680Status < BME680_OK) {
      snprintf(s, sizeof(s), PSTR("BME error code : %d"), bsec.bme680Status);
      xSerial.printDateTimeln(MSG_SYS, s);
      for (;;)
        errLeds(50);  // Halt in case of failure
    } else {
      snprintf(s, sizeof(s), PSTR("BME warning code : %d"), bsec.bme680Status);
      xSerial.printDateTimeln(MSG_SYS, s);
    }
  }
  xSerial.printDateTimeln(MSG_SYS, "BME680 passed test!");
}

void Sensors::readSensors() {
    if (bsec.run()) {
    // If new data is available...get BME680 data 
    digitalWrite(LED_BUILTIN, HIGH);
    data.rawTemperature = bsec.rawTemperature;
    data.temperature    = bsec.temperature;
    data.pressure       = bsec.pressure/100;
    data.rawHumidity    = bsec.rawHumidity;
    data.humidity       = bsec.humidity;
    data.iaq            = bsec.iaq;
  } else {
    digitalWrite(LED_BUILTIN, LOW);
  }
  data.light = analogRead(LIGHT_SENSOR);
}

void Sensors::updateIAQStateOnRGB_LED() {
  if (data.iaq < 151) {
    // Airquality is ok
    // Airquality Alarm still on ? -> turn off
    if (_AIRQUALITYALARM_()) {
        // disable LED in Alarm-Mode
        _AIRQUALITYALARM_() = false;
        xSerial.printDateTimeln(MSG_SENSOR, "Airquality alarm disabled!");
        if (!_RGBLED_())
          rgbLED.off();                       // level 0 = turn LED off         
    }
    // Option: RGB_LED is on
    if ( _RGBLED_()) {
      if (data.iaq < 51)                      // level 1 = green:
        rgbLED.setColor(xDARK_GREEN);
      if (data.iaq >50 && data.iaq < 101)     // level 2 = lime:
        rgbLED.setColor(xLIME); 
      if (data.iaq > 100 && data.iaq < 151)   // level 3 = yellow:
        rgbLED.setColor(xYELLOW);
    }
  } else {
    // Airquality is bad
    if (!_AIRQUALITYALARM_()) {
      // enable Alarm-Mode
      _AIRQUALITYALARM_() = true;
      xSerial.printDateTimeln(MSG_SENSOR, "Airquality alarm enabled!"); 
    }
    
    if (data.iaq > 150 && data.iaq < 201)     // level 4 = dark-orange:
      rgbLED.setColor(xDARK_ORANGE);
    if (data.iaq > 200 && data.iaq < 301)     // level 5 = red:
      rgbLED.setColor(xRED);
    if (data.iaq > 300)                       // level 6 = magenta:
      rgbLED.setColor(xMAGENTA);
  }
}

String Sensors::pubIAQStatus() {
  String airQuality = "unknown-value";
  
  if (data.iaq < 51)                            // level 1 = green:
    airQuality = "excellent-value";
  if (data.iaq > 50 && data.iaq < 101)          // level 2 = green-yellow:
     airQuality = "good-value";
  if (data.iaq > 100 && data.iaq < 151)         // level 3 = yellow:
     airQuality = "fair-value";
  if (data.iaq > 150 && data.iaq < 201)         // level 4 = orange-red:
     airQuality = "inferior-value";
  if (data.iaq > 200)                           // level 5 = red/magenta
    airQuality = "poor-value";

  return airQuality;
}
