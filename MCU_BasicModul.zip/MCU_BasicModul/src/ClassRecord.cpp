// Copyright 2019 <Hermann Buescher>
#include "./ClassRecord.h"

File    dataFile;

const uint32_t endOfRecords = 0xFFFFFFFF;

Record::Record() {}

void  Record::setFirstPointerAddress(uint32_t firstPointerAddr) {
        this->first = firstPointerAddr;
}

void  Record::setLastDataAddress(uint32_t lastDataAddr) {
        this->lastDataAddr = lastDataAddr;
}

void  Record::setRecord() {
        Serial.println("Virtual Function of Record");
}     //  virtual function

void  Record::setSizeOfRecordData(uint32_t sizeOfRecordData) {
  _sizeOfRecordData = sizeOfRecordData;
}

void  Record::setSizeOfReservedBuffer() {
  _sizeOfReservedBuffer = this->lastDataAddr - this->first;
}

void  Record::setNumOfRecords(uint32_t numOfRecords) {
  _numOfRecords = numOfRecords;
}

void  Record::setMaxNumOfRecords(uint32_t maxNumOfRecords) {
  if (maxNumOfRecords == 0) {
    _maxNumOfRecords = _sizeOfReservedBuffer / _sizeOfRecordData;
  } else {
    _maxNumOfRecords = maxNumOfRecords;
  }
}

uint32_t Record::getNumOfRecords() {
  return _numOfRecords;
}

uint32_t Record::getMaxNumOfRecords() {
  return _maxNumOfRecords;
}

uint32_t Record::getSizeOfRecordData()  {
  return _sizeOfRecordData;
}

uint32_t Record::getSizeOfReservedBuffer() {
  return _sizeOfReservedBuffer;
}

uint32_t Record::getNext(uint32_t addr) {
  return addr + _sizeOfRecordData;
}

uint32_t Record::getPrev(uint32_t addr) {
  return addr - _sizeOfRecordData;
}



uint32_t Record::nextFreePos(char *buffer, uint32_t x) {
  while (x++ < 80)
    if (buffer[x] == 0)
      break;
  // printPageBytes((uint32_t)buffer, (byte *)buffer, 80);
  return x;
}

//  Record::Flash functions_____________________________________________

void Record::eraseFlashReservedBuffer() {
  if (eraseFlashBlock64K(first, getSizeOfReservedBuffer())) {
    initPointer();
    xSerial.printDateTimeln(MSG_FLASH, "erase flash section finished!");
  } else {
    xSerial.printDateTimeln(MSG_FLASH, "error - erase flash section failed");
    errLeds(50);
  }
}

void Record::readFlash(uint32_t addr) {
  if (flash.readByteArray(addr, (uint8_t *)dataField[0].field, \
       getSizeOfRecordData(), false) ) {
    delay(40);
    if ( _DEBUGTRACK_() ) {
      serialDebugPrint("Flash_read ", addr, ' ');
      //  printPageBytes((uint32_t)dataField[0].field,        \
                        (uint8_t *)dataField[0].field,        \
                              getSizeOfRecordData());
      //  printPageBytes(addr, (uint8_t *)dataField[0].field, \
                              getSizeOfRecordData());
    }
  } else {
    serialDebugPrint("error: Flash_read!", addr, ' ');
    if (_DEBUG_()) {
      printPageBytes(addr, (uint8_t *)dataField[0].field, \
                                  getSizeOfRecordData());
      _EXIT_() = false; // skip logbook entry "command is active"
      modulCommand_();
    }
  }
}

void Record::writeFlash(uint32_t addr) {
  if (flash.writeByteArray(addr, (uint8_t *)dataField[0].field, \
                           getSizeOfRecordData(), true)) {
    delay(40);
    if (_DEBUGTRACK_()) {
      serialDebugPrint("Flash_write ", addr, ' ');
      // printPageBytes(addr, (uint8_t *)dataField[0].field,\
      //                                getSizeOfRecordData());
    }
    last = addr;
    act  = getNext(addr);
    setNumOfRecords(getNumOfRecords() + 1);
  } else {
    serialDebugPrint("error: Flash_write!", addr, ' ');
    if (_DEBUG_()) {
      printPageBytes(addr, (uint8_t *)dataField[0].field, \
                                  getSizeOfRecordData());
      _EXIT_() = false; // skip logbook entry "command is active"
      modulCommand_();
    }
  }
}

//  Record::Data functions______________________________________________

// virtual function

void Record::backupRecordOnFlash() {
  if (flashBegin()) {
    if (getNumOfRecords()> getMaxNumOfRecords()) {
      numOfRecordsOverrun();
    } else {
      setRecord();
      writeFlash(act);
    }
  }
  deselectFlash();
}

void Record::numOfRecordsOverrun() {
  snprintf(s, sizeof(s), PSTR("error  not enough memory for %s data!"), recName.c_str());
  xSerial.printDateTimeln(MSG_FLASH, s);
  if (_DEBUG_()){
    snprintf(s, sizeof(s), PSTR("error at address: %d!"), last);
    xSerial.printDateTimeln(MSG_FLASH, s); 
  }
  if (checkSD_Card()) {
    backup();
  } else {
    eraseFlashReservedBuffer();
  }
}


uint32_t Record::findLastRecord(uint32_t first, uint32_t last) {
    uint32_t i = first + (last - first)        \
                 / (getSizeOfRecordData() * 2) \
                 *  getSizeOfRecordData();
    readFlash(i);
    if (RECORD_ID < endOfRecords) {
       first = i;
       readFlash(getNext(i));
       if (RECORD_ID == endOfRecords)
         return i;
    } else {
      last = i;
    }
    return findLastRecord(first, last);
}

void Record::initPointer() {
  if (flashBegin()) {
    readFlash(first);
    // If MCU resetted, find last pointer address
    // 1. If memory is empty, act = first
    if (RECORD_ID == endOfRecords) {
      act  = first;
      setNumOfRecords(1);
    } else {
       // 2. If not, find last record
       last = first + getMaxNumOfRecords() * getSizeOfRecordData();
       act = findLastRecord(first, last);
       readFlash(act);
       // 3. set next record for recording
       setNumOfRecords(RECORD_ID+1);
       act = getNext(act);
    }
    last = act;
  }
  deselectFlash();
}


String  Record::getStringOfRecord(boolean json, char delim) {
  char   buffer[GET_STRING_BUFFER] = {0};
  char   *ptr = buffer;

  if (json)
    *ptr++ = '[';
  for (int j = 0; j < numOfFieldElements; j++) {
    if (json)
      ptr += snprintf(ptr, dataField[j].desc.length() + 5, "{\"%s\":", \
                     const_cast<char*>(dataField[j].desc.c_str()));
    switch (dataField[j].type) {
      case type_uint32_t:
        ptr += snprintf(ptr, dataField[j].len + 1, "%*d",\
                             dataField[j].len,                \
                *(uint32_t *)dataField[j].field);
        if (json) 
          ptr += snprintf(ptr, 2, "%s", "}");
        break;
      case type_record:
        ptr += snprintf(ptr, dataField[j].len + 1, "%*d",\
                             dataField[j].len,                \
                *(uint32_t *)dataField[j].field);
        if (json) 
          ptr += snprintf(ptr, 2, "%s", "}");
        break;
      case type_int:
        ptr += snprintf(ptr, dataField[j].len + 1, "%*d",\
                             dataField[j].len,                \
                     *(int *)dataField[j].field);
        if (json) 
          ptr += snprintf(ptr, 2, "%s", "}");
        break;
      case type_float:
        ptr += snprintf(ptr, 11, "%.2f",                      \
                   *(float *)dataField[j].field);
        if (json) 
          ptr += snprintf(ptr, 2, "%s", "}");
        break;
      case type_string:
       if (json)
          ptr += snprintf(ptr, 2, "%s", "\"");
        ptr += snprintf(ptr, dataField[j].len + 1, "%s",  \
                     (char *)dataField[j].field);
       if (json) 
        ptr += snprintf(ptr, 3, "%s", "\"}");
        break;
      case type_date:
        if (json)
          ptr += snprintf(ptr, 2, "%s", "\"");
        ptr +=snprintf(ptr, 11, "%04d/%02d/%02d",                       \
                *(int *) dataField[j].field,                            \
                *(uint8_t *)(dataField[j].field                         \
                              + sizeof(timeStamp.date.year)),           \
                *(uint8_t *)(dataField[j].field                         \
                              + sizeof(timeStamp.date.year)             \
                              + sizeof(timeStamp.date.month)));
        if (json)
          ptr += snprintf(ptr, 3, "%s", "\"}");
        break; 
      case type_time:
        if (json)
          ptr += snprintf(ptr, 2, "%s", "\"");
        ptr += snprintf(ptr, 9, "%02d:%02d:%02d",                       \
                *(uint8_t *) dataField[j].field,                        \
                *(uint8_t *)(dataField[j].field                         \
                              + sizeof(timeStamp.time.hour)),           \
                *(uint8_t *)(dataField[j].field                         \
                              + sizeof(timeStamp.time.hour)             \
                              + sizeof(timeStamp.time.minute)));
        if (json)
          ptr += snprintf(ptr, 3, "%s", "\"}");
    }
    *ptr++ = delim; 
  }
  ptr--;
  if (json)
      *ptr++ = ']';
  *ptr = '\0';

  //Serial.println("SerialprintBuffer:");
  //printPageBytes((uint32_t)buffer, (byte *)buffer, sizeof(buffer));
  return buffer;
}


void Record::serialDebugPrint(char *task, uint32_t addr, char blank) {
  char sDebug[120] = {0};
  if (RECORD_ID != endOfRecords ) {
    snprintf(sDebug, sizeof(sDebug), PSTR("%s 0x%07x: %s"),\
           task, addr, getStringOfRecord(false, blank).c_str());
  } else {
    snprintf(sDebug, sizeof(s), PSTR("RECORD_ID out of range <addr 0xFFFFFFFF>"));
  }
  xSerial.println(sDebug); 
}

//  Record::Memory Data functions_______________________________________
void Record::setFlashMemoryAddress(String   pointerName,\
                                   uint32_t *pointer, \
                                   uint32_t addrBegin,\
                                   uint32_t addrEnd) {
  // char s[80];
  if (*pointer < addrBegin)
    *pointer = addrBegin;
  while (true) {
    snprintf(s, sizeof(s), PSTR("%-5s: address 0x%x - ok?"), pointerName.c_str(), *pointer);
    if (xSerial.ask(s) == "Y") {
      if (pointerName == "last") {
        if (0 == this->lastDataAddr - this->first) {
          xSerial.printDateTimeln(MSG_FLASH, "Memory allocation error! 0 bytes reserved!"); 
        } else {
          setSizeOfReservedBuffer();
          setMaxNumOfRecords();
          //  Flash reserved memory for logbook data  - 1 block = 64K
          snprintf(s, sizeof(s), PSTR("0x%x  bytes allocated for data!"), \
                                        getSizeOfReservedBuffer());
          xSerial.printDateTimeln(MSG_FLASH, s);
          break;
        }
      } else {
        break;
      }
    } else if (xSerial.reTurn.esc) {
      return;
    }
    readFlashMemoryAddress(pointer, addrBegin, addrEnd);
    snprintf(s, sizeof(s),PSTR("%s flash address is 0x%x"),\
                                pointerName.c_str(), *pointer);
    xSerial.printDateTimeln(MSG_FLASH, s);
  }
}

void Record::readFlashMemoryAddress(uint32_t *pointer, \
                                    uint32_t addrBegin,\
                                    uint32_t addrEnd) {
  char s[80];
  String   inputString;
  uint32_t inputAddr;
  while (true) {
    snprintf(s, sizeof(s), PSTR("Please enter new value [0x%X - 0x%X]: "), addrBegin,addrEnd);
    Serial.print(s);
    inputString = xSerial.readString(false);
    if (xSerial.reTurn.esc)
      return;
    inputAddr = xString.hexToInt(inputString);
    if (inputAddr == 0xFFFFFFFF) {
      xSerial.printDateTimeln(MSG_FLASH, "Hex value is not valid (0xXXXXXX)!");
    } else if (inputAddr % 0x10000 != 0) {
      xSerial.printDateTimeln(MSG_FLASH, "Address not valid! Only multiple of 64K-blocks!");
    } else if (!rangeOfInteger.validate(inputAddr, addrBegin, addrEnd)) {
      xSerial.printDateTimeln(MSG_FLASH, "Address out of range");
    } else {
      *pointer = rangeOfInteger.result;
      return;
    }
  }
}

void Record::report(char *s, size_t size) {
  // Title
  snprintf(s, size, PSTR("* %s"), recName.c_str());
  Serial.println(s);
  // Startaddress
  snprintf(s, size, PSTR("*   %-18s: %-3s 0x%06x"), "Startaddress", " ", first);
  Serial.println(s);
  // Endaddress
  snprintf(s, size, PSTR("*   %-18s: %-3s 0x%06x"), "Endaddress", " ", lastDataAddr);
  Serial.println(s);
  // reserved memory buffer - thereof used
  snprintf(s, size, PSTR("*   %-18s: %-3s 0x%06x %-6s < thereof used %.02f%%>"), "Reserved Memory",\
                         " ", getSizeOfReservedBuffer(), "bytes",\
                         usedMemPercentage());
  Serial.println(s);
  // records total
  snprintf(s, size, PSTR("*   %-18s: %-3s 0x%06x %-6s"), \
                         "size of Record", " ", getSizeOfRecordData(), "bytes");
  Serial.println(s);
  snprintf(s, size, PSTR("*   %-18s: %-3s %8d"), \
                         "max Num of Records", " ",  getMaxNumOfRecords());
  Serial.println(s);
  // records actual
  snprintf(s, size, PSTR("*   %-18s: %-3s %8d %-6s < addr of actual record: 0x%06x >"), \
                         "Num of Records"," ", getNumOfRecords()-1, " ", act);
  Serial.println(s);
}

int Record::setFrequency(int frequency) {
  // char s[80];
  int newFrequency;
  boolean valid;
  if (frequency == 0)
    frequency = 1;
  while (true) {
    snprintf(s, sizeof(s), PSTR("Save data every %d minutes? [1-59] - ok?"),\
                           frequency);
    if (xSerial.ask(s) == "Y"  || xSerial.reTurn.esc) {
      return frequency;
    }
    valid = false;
    while (!valid) {
      Serial.print("Please enter the new value (1 - 59): ");
      newFrequency = xSerial.readString().toInt();
      if (xSerial.reTurn.esc) {
        return frequency;
      } else if (xSerial.reTurn.cr) {
        break;
      }
      if (rangeOfInteger.validate(newFrequency, 1, 59)) {
        frequency = rangeOfInteger.result;
        valid = true;
      } else {
        xSerial.println("Value out of range!");
      }
    }
  }
}

float Record::usedMemPercentage() {
  float used = ((float)getNumOfRecords()-1)/(float)getMaxNumOfRecords();
  return used * 100.00;
}

// Record::SD-Card functions____________________________________________

void Record::writeSD_CARD() {
  uint32_t i_act = RECORD_ID;
  uint32_t i_prev = i_act;

  playTones(TUNE_MOVE);
  systemDelay(2000);
  // Write data on SD_CARD
  flashBegin();
  act = first;
  readFlash(act);
  while (i_act < endOfRecords) {
    digitalWrite(LED_BUILTIN, HIGH);
    dataFile.println(getStringOfRecord(false,','));
    digitalWrite(LED_BUILTIN, LOW);
    if (_DEBUGTRACK_())
      serialDebugPrint("SD-Card_write ", act, ',');
    act = getNext(act);
    readFlash(act);
    i_prev = i_act;
    i_act = RECORD_ID;
  }
  // erase Flash Section
  eraseFlashReservedBuffer();
  if (i_prev != endOfRecords) {
    snprintf(s, sizeof(s), PSTR("SD-Card Total number of Records written: %d"),\
                          i_prev);
    xSerial.printDateTimeln(MSG_SDCARD, s);
  }
}

void Record::backup() {
  snprintf(s, sizeof(s), PSTR("SD-Card backup of %s data is running!!"),\
                              recName.c_str());
  xSerial.printDateTimeln(MSG_SDCARD, s);
  if (backupOnSD_Card(recName.substring(0,2))) {
    snprintf(s, sizeof(s), PSTR("SD-Card backup of %s data completed!"),\
                              recName.c_str());
    xSerial.printDateTimeln(MSG_SDCARD, s);
  }
  playTones(TUNE_DONE);
    systemDelay(2000);
}

boolean Record::backupOnSD_Card(String title) {
  // do not interrupt due to MQTT messages...
  if (_MQTT_()) { 
    disconnectMQTT();
  }

  // Callback function of SdFat.h for date and time
  SdFile::dateTimeCallback(dateTime);
  
  // SD_Card: SPI_HALF_SPEED ! 
  if (SD_CardBegin()) {
    now = rtc.now();
    char bufferTime[] = "YYMMDD";
    title = title + String(now.toString(bufferTime)) + ".txt";

    char filename[20];
    snprintf(filename, sizeof(filename), "%s", title.c_str());
    snprintf(s, sizeof(s), PSTR("SD-Card Backup Filename "),\
                              filename);
    xSerial.printDateTimeln(MSG_SDCARD, s);
    dataFile = SD.open(filename, FILE_WRITE);
    writeSD_CARD();
    dataFile.close();
    deselectSD_Card();
    return true;
  } else {
    xSerial.printDateTimeln(MSG_SDCARD, "Backup failed - SD_Card error", ERRCODE_SYS);
    return false;
  }
}


//  Debug functions_____________________________________________________
void Record::printPointers() {
    char buffer[GET_STRING_BUFFER] = {0};
    snprintf(buffer, sizeof(buffer), \
             PSTR("First:%d, actual:%d, last: %d, numOfRecords: %d"), \
              first, \
              act,   \
              last,  \
              getNumOfRecords());
    Serial.println(buffer);
}
