// Copyright 2020 <Hermann Buescher>
#include "./ModulThings.h"

//  Battery____________________________________________________________
void chargingCompleted() {
  uint8_t minutes = now.minute();
  if (pmic.bqChargeStatus.time.minute() > now.minute()) {
    minutes += 60;
  }
  // if no CTD status change for 5 minutes
  if ((pmic.bqChargeStatus.code == CHARGE_TERMINATION_DONE) \
      && minutes > pmic.bqChargeStatus.time.minute() + 1) {
    pmic.chargingCompleted = true;
    pmic.setColorOfChargingCompleted();
    xSerial.printDateTimeln(MSG_BAT, "Battery charging completed!");
    if (_BATTERYAUTOONOFF_()) {
      pmic.enableCharger(false);
    }
  }
}

void updateLowBatteryFlag() {
  uint8_t minutes = now.minute();
  // after one minute of low battery Voltage, the lowBattery flag is set
  if (pmic.timeOfLowBattery.minute() > now.minute()) {
    minutes += 60;
  }
  if (minutes > pmic.timeOfLowBattery.minute() + 1) {
    pmic.lowBattery = true;
  }
}

void printPMICHelp() {
  xSerial.println(">Please enter command:");
  SerialprintOptionOnOffln(25, "pm[PMIC HostMode]", _BATTERYCHARGING_());
  SerialprintOptionOnOffln(25, "pb[PMIC Booster]",  _BATTERYBOOSTER_());
  SerialprintOptionOnOffln(25, "au[charging auto OnOff]", _BATTERYAUTOONOFF_());
  SerialprintOptionOnOffln(25, "ch[charging Mode]", &pmic.chargerEnabled);
  snprintf(s, sizeof(s),PSTR("> %-25s: %2.2fA"), \
                      "cu[setChargeCurrent]", pmic.getChargeCurrent());
  xSerial.println(s);   
  xSerial.println("> li[st Status], ex[it]");
}

void SerialprintPMICStatus() {
  Serial.println();
  xSerial.println(">>*** BQ24195 Controller Mode ***");
  snprintf(s, sizeof(s),PSTR("> %-30s: %2.2fV"), \
                             "Battery status", pmic.voltage);
  xSerial.println(s);
  SerialprintOptionOnOffln(30, "BATFET", pmic.BATFETEnabled);
  if (!pmic.chargerEnabled)
    SerialprintOptionOnOffln(30, "Battery connected", pmic.batteryConnected);
  if (pmic.batteryConnected && pmic.chargingCompleted) {
    snprintf(s, sizeof(s),PSTR("> %-30s: %2.2fV"), \
                             "Charging completed", pmic.bqChargeStatus.voltage);
    xSerial.println(s);
    snprintf(s, sizeof(s),PSTR("> %-30s: %s"), \
                             "Charge terme done", pmic.bqChargeStatus.time.timestamp());
    xSerial.println(s);
    }
  SerialprintOptionTextln(30, "USBMode",        pmic.bqVBusStatus.message);
  SerialprintOptionTextln(30, "Charge Status",  pmic.bqChargeStatus.message);
  SerialprintOptionTextln(30, "Charge Fault",   pmic.bqChargeFault.message);
  SerialprintOptionTextln(30, "Bat Temp Fault", pmic.bqTermalFault.message);
  xSerial.println(">");
}

void SerialprintPMICStatus_list() {
  xSerial.printDateTimeln(MSG_BAT, "*** BQ24195 Controller Mode ***");
  SerialprintDateTimeOptionFloatln(35, "Battery PIN",  pmic.voltage, "V"); 
  SerialprintDateTimeOptionOnOffln(35, "Charger",      pmic.chargerEnabled);
  SerialprintDateTimeOptionOnOffln(35, "BATFET",       pmic.BATFETEnabled);
  SerialprintDateTimeOptionTextln( 35, "*** BQ24195 Register Status ***", " ");
  SerialprintDateTimeOptionFloatln(35, "REG00 Input Voltage Limit",       pmic.getInputVoltageLimit(), "V") ;
  SerialprintDateTimeOptionFloatln(35, "      Input Current Limit",       pmic.getInputCurrentLimit(), "A") ;
  SerialprintDateTimeOptionFloatln(35, "REG01 Minimum System Voltage",    pmic.getMinimumSystemVoltage(), "V") ;
  SerialprintDateTimeOptionFloatln(35, "REG02 Charge Current",            pmic.getChargeCurrent(), "A");
  SerialprintDateTimeOptionFloatln(35, "REG03 PreCharge Current",         pmic.getPreChargeCurrent(), "A");
  SerialprintDateTimeOptionFloatln(35, "      Term Charge Current",       pmic.getTermChargeCurrent(), "A");
  SerialprintDateTimeOptionFloatln(35, "REG04 Charge Voltage",            pmic.getChargeVoltage(), "V") ;
  SerialprintDateTimeOptionTextln( 35, "REG08 USBMode",                   pmic.bqVBusStatus.message);
  SerialprintDateTimeOptionTextln( 35, "      Charge Status",             pmic.bqChargeStatus.message);
  SerialprintDateTimeOptionYesNoln(35, "      Power is good",             pmic.isPowerGood());
  SerialprintDateTimeOptionYesNoln(35, "      DPM Status",                pmic.dpmStat());
  SerialprintDateTimeOptionYesNoln(35, "      in Thermal Regulation",     pmic.isHot());
  SerialprintDateTimeOptionYesNoln(35, "      in VSYSMIN Regulation",     pmic.getVsysStat());
  SerialprintDateTimeOptionTextln( 35, "REG09 Charge Fault",              pmic.bqChargeFault.message);
  SerialprintDateTimeOptionYesNoln(35, "      Watchdog Timer Expiration", pmic.isWatchdogExpired());
  SerialprintDateTimeOptionYesNoln(35, "      Bat Over Voltage Fault",    pmic.isBatteryInOverVoltage());
  SerialprintDateTimeOptionTextln( 35, "      Bat Temperature Fault",     pmic.bqTermalFault.message);
}

// xSerial.println
void SerialprintOptionTextln(int width, char *t,  char *u) {
  snprintf(s, sizeof(s),PSTR("> %-*s: %s "), width, t, u);
  xSerial.println(s); 
} 

void SerialprintOptionOnOffln(int width, char *t, boolean option) {
  snprintf(s, sizeof(s),PSTR("> %-*s: %-3s "), width, t, bool2OnOff(option).c_str());
  xSerial.println(s); 
}

// xSerial.printDateTimeln
void SerialprintDateTimeOptionTextln(int width, char *t, char *u) {
  snprintf(s, sizeof(s),PSTR("%-*s: %s "), width, t, u);
  xSerial.printDateTimeln(MSG_BAT, s); 
} 

void SerialprintDateTimeOptionFloatln(int width, char *t, float x, char *voltAmper) {
  snprintf(s, sizeof(s),PSTR("%-*s: %2.2f%s"), width, t, x, voltAmper);
  xSerial.printDateTimeln(MSG_BAT,s); 
} 

void SerialprintDateTimeOptionOnOffln(int width, char *t, boolean option) {
  snprintf(s, sizeof(s),PSTR("%-*s: %-3s "), width, t, bool2OnOff(option).c_str());
  xSerial.printDateTimeln(MSG_BAT,s); 
}

void SerialprintDateTimeOptionYesNoln(int width, char *t, boolean option) {
  snprintf(s, sizeof(s),PSTR("%-*s: %-3s "), width, t, bool2YesNo(option).c_str());
  xSerial.printDateTimeln(MSG_BAT, s); 
}

void pmicController() {
  String   cmdString;
  Serial.println(">>");
  while (cmdString != "EX") {
    pmic.update();
    pmic.updateBatteryVoltage();
    if (cmdString == "PM") {
      pmicController_PM();
    } else if (cmdString == "PB") {
      pmicController_PB();
    } else if (cmdString == "AU") {
      pmicController_AU();
    } else if (cmdString == "CH") {
      pmicController_CH();
    } else if (cmdString == "SE") {
      setChargeCurrent();
    }
    // print PMIC Status
    if (cmdString == "LI") {
      SerialprintPMICStatus_list();
    } else {
      SerialprintPMICStatus();
    }
    printPMICHelp(); 
    Serial.print(">");
    cmdString = xSerial.readString();
    cmdString.toUpperCase();
  }
}

// enable/ disable PMIC Controller
void  pmicController_PM() {
  if (_BATTERYCHARGING_()) {
    _BATTERYCHARGING_() = false;
    pmic.enableCharger(false);
  } else {
    _BATTERYCHARGING_() = true;
    pmic.enableCharger(true);
  }
}

// enable/ disable Booster
// in BoosterMode: - mcu gets power only from battery
//                 - no charging
//                 - to disable, charging is enabled
// To start the booster, press PB, reboot and disconnect the USB power cabel
void  pmicController_PB() {
  if (_BATTERYBOOSTER_()) {
    _BATTERYBOOSTER_() = false;
    pmic.enableBooster(false);
  } else {
    _BATTERYBOOSTER_() = true;
    if (pmic.chargerEnabled) {
      pmic.enableCharger(false);
    }
    xSerial.printDateTimeln(MSG_BAT, "Booster mode is enabled after reboot!");
    xSerial.printDateTimeln(MSG_BAT, "Do not forget to disconnect the USB power cabel!");
  }
}

// auto OnOff - on : disable charger, when batter charging is completed
//              off: charger is always on
void  pmicController_AU() {
  if (_BATTERYAUTOONOFF_()) {
    _BATTERYAUTOONOFF_() = false;
  } else {
    _BATTERYAUTOONOFF_() = true;
    pmic.chargingCompleted = false;
  }
}

// enable/ disable Battery Charging
void  pmicController_CH() {
  if (pmic.chargerEnabled) {
    pmic.enableCharger(false);
    xSerial.printDateTimeln(MSG_BAT, "Reboot is recommended before leaving command mode!");
  } else if (_BATTERYBOOSTER_() == true) {
    xSerial.printDateTimeln(MSG_BAT, "Please switch off the Booster first!");
    return;
  } else {
    _BATTERYCHARGING_() = true;
    pmic.enableCharger(true);
  }
}

// setChargeCurrent
void setChargeCurrent() {
  String cmdStr;
  float current;
  Serial.print(">> Please enter charge current in mA () [0.512 - 2.048]: ");
  cmdStr = xSerial.readString();
  xSerial.println(">");
  current = cmdStr.toFloat();
  if (current > 2.048) {
    current = 2.048;
  } else if (current < 0.512) {
    current = 0.512;
  }
  if (pmic.setChargeCurrent(current)) {
    SerialprintDateTimeOptionFloatln(35, "BQ24195 - charge current updated ", current, "A") ;
  } else {
    xSerial.printDateTimeln(MSG_BAT, "BQ24195 - CHARGE_CURRENT_CONTROL_REGISTER write error!");
  }
}

// Buzzer______________________________________________________________

// see ClassTones

//  Flash functions___________________________________________________
SPIFlash flash(EEPROM_CS, &SPI);

uint32_t flashCapacity;

void eraseFlash() {
  if (flashBegin()) {
    xSerial.printDateTimeln(MSG_FLASH,  "flash erase started....");
    if (!flash.eraseChip()) {
      xSerial.printDateTimeln(MSG_FLASH,  "error  flash erase failed!");
      errLeds(50);
    } 
  }
  deselectFlash();
  if (_LOGBOOK_())
    logbook.initPointer();
  if (_SENSORS_())
    sensors.initPointer();
  if (_DEBUG_())
    flashprintCapacity();
  xSerial.printDateTimeln(MSG_FLASH,  "full chip erase completed.");
}

boolean eraseFlashBlock64K(uint32_t first, uint32_t size) {
  String msg;
  boolean ok;
  uint32_t addr        = first;
  uint32_t block64K    = 64 * 1024;
  uint32_t numOfBlocks = size / block64K + 1;
  if (flashBegin()) {
    xSerial.printDateTimeln(MSG_FLASH,  "flash erase started....");
    for (int i = 0; i < numOfBlocks; i++) {
      digitalWrite(LED_BUILTIN, HIGH);
      ok = flash.eraseBlock64K(addr);
      digitalWrite(LED_BUILTIN, LOW);
      delay(500);   //According to the Datasheet deleting a sector takes 400ms max
      if (ok) {
        // reset logbook pointer
        if (_LOGBOOK_()) {
          if (addr == logbook.first) {
            logbook.act  = logbook.first;
            logbook.setNumOfRecords(1);
          }
        }
        if (_DEBUG_()) {
          snprintf(s, sizeof(s), \
                  PSTR("64K block deleted starting from addr 0x%6d"),\
                  addr);
          xSerial.printDateTimeln(MSG_FLASH, s); 
        }
        addr = addr + block64K;
      } else {
        if (_DEBUG_()) {    
          snprintf(s, sizeof(s),\
                  PSTR("error - 64K block could not be deleted starting from addr 0x%6x"),\
                  addr);  
          xSerial.printDateTimeln(MSG_FLASH, s);
        }
        errLeds(50);
        return false;
      }
    }
    snprintf(s, sizeof(s), PSTR("flash erased from start addr 0x%6x to 0x%6x"),\
                                first, addr);
    xSerial.printDateTimeln(MSG_FLASH, s);
  } 
  deselectFlash();
  return true;
}


boolean flashBegin() {
  selectFlash();
  if (!flash.begin()) {
    xSerial.printDateTimeln(MSG_FLASH,  "error flash allocation failed");
    errLeds(50);
    return false;
  }
  return true;
}

void flashGetCapacity() {
  flashCapacity = 0;
   if (flashBegin()) {
      flashCapacity = flash.getCapacity(); 
      delay(100); 
      if (!flashCapacity)  
        xSerial.printDateTimeln(MSG_FLASH,  "error flash capacity is zero");     
   }
}

void flashprintCapacity() {
  Serial.println();
  snprintf(s, sizeof(s), PSTR("flash Memory %d bytes."), flashCapacity);
  xSerial.printDateTimeln(MSG_FLASH, s);
}

void deselectFlash() {
  digitalWrite(EEPROM_CS, HIGH);
  if (_OLED_())
    selectOLED();
}

void selectFlash() {
  if (_OLED_())
    deselectOLED();
  digitalWrite(EEPROM_CS, LOW);
}

// SD-Card functions____________________________________________________

//  Callback function of SdFat.h
void dateTime(uint16_t* date, uint16_t* time) {
    DateTime now = rtc.now();
    
    // return date using FAT_DATE macro to format fields
    *date = FAT_DATE(now.year(), now.month(), now.day());

    // return time using FAT_TIME macro to format fields
    *time = FAT_TIME(now.hour(), now.minute(), now.second());
}

boolean checkSD_Card() {
  digitalWrite(SDCARD_CS, LOW);
  boolean status;
  if (SD.begin(SDCARD_CS)) {
    status = true;
  } else {
    status = false;    
  }
  deselectSD_Card();
  return status;
}

void deselectSD_Card() {
  SD.end();
  digitalWrite(SDCARD_CS, HIGH);
  if (_OLED_())
    selectOLED();
}

boolean SD_CardBegin() {
  for (int i = 0; i < 5; i++) {
    selectSD_Card();
    if (SD.begin(SDCARD_CS)) {
      xSerial.printDateTimeln(MSG_SDCARD, "SD-Card initialized.");
      return true;
    } else {
      blink.fast();
      displayText("SD-Card error!");
      xSerial.printDateTimeln(MSG_SDCARD, "SD-Card failed, or is not present");
      errLeds(3);
      deselectSD_Card();
    }
  }
  return false;
}

void selectSD_Card() {
  if (_OLED_())
    deselectOLED();
  digitalWrite(SDCARD_CS, LOW);
}

void fullBackupOnSD_Card() {
  if (_SENSORS_() && _BACKUPONFLASH_())
    sensors.backup();
  if (_LOGBOOK_())
    logbook.backup();
  if (!(_SENSORS_() && _BACKUPONFLASH_()) && !_LOGBOOK_())
    xSerial.printDateTimeln(MSG_SYS, "Backup canceled - Sensors and Logbook are off");
}

//  OLED_______________________________________________________________

const int screenWidth  = 128;  // OLED display width, in pixels
const int screenHeight =  64;  // OLED display height, in pixels

// Adafruit_SSD1306 display(screenWidth, screenHeigth,
//   MOSI, SCLK, CON_SPI_DC, CON_SPI_RST, CON_SPI_CS);
Adafruit_SSD1306 display(screenWidth, screenHeight,
                        &SPI, CON_SPI_DC, CON_SPI_RST, CON_SPI_CS);

boolean displayBegin() {
  selectOLED();
  // SSD1306_SW
  // ITCHCAPVCC = generate display voltage from 3.3V internally
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3D)) {
    xSerial.printDateTimeln(MSG_SYS, "display SSD1306 allocation failed");
    return false;
  } else {
    xSerial.printDateTimeln(MSG_SYS, "OLED Display is enabled"); 
    displayClear(); 
    return true;
  }
}

void displayClear() {
  display.clearDisplay();
  display.setTextSize(1);               // Normal 8x8 Pixel scale
  display.setTextColor(SSD1306_WHITE); // Draw white text
  display.display();
}

void displayText(String string) {
  display.clearDisplay();
  display.setTextSize(1);               // Normal 8x8 Pixel scale
  display.setTextColor(SSD1306_WHITE); // Draw white text
  display.setCursor(0, 0);            // Start at top-left corner
  display.println(string);
  display.display();
}

void displayInit() {
  if (displayBegin()) {
    _OLEDINIT_() = true;
  } else {
    _OLED_() = false;
    _OLEDINIT_() = false;
    xSerial.printDateTimeln(MSG_SYS, "OLED display is disabled?");
  }
}

void displayDisplay() {
  // Clear display
  display.clearDisplay();
  display.setTextSize(1);             // Normal 1:1 pixel scale
  display.setTextColor(SSD1306_WHITE); // Draw white text
  display.setCursor(0, 0);            // Start at top-left corner
  // print DateTime
  snprintf(s, sizeof(s), \
    PSTR("%4d/%02d/%02d   %02d:%02d:%02d"),\
      now.year(),\
      now.month(),\
      now.day(),\
      now.hour(),\
      now.minute(),\
      now.second());    
  display.println(s);
  // print Sensors state
  if (_SENSORS_()) {
    snprintf(s, sizeof(s), PSTR("%-9s %7.2f %-3s"), \
                        "Temp", sensors.data.temperature, "Cel");
    display.println(s);
    snprintf(s, sizeof(s), PSTR("%-9s %7.2f %-3s"),\
                        "Pressure",sensors.data.pressure, "hPa");
    display.println(s);
    snprintf(s, sizeof(s), PSTR("%-9s %7.2f %-3s"), \
                        "Humidity", sensors.data.humidity, "%");
    display.println(s);
    snprintf(s, sizeof(s), PSTR("%-9s %7.2f %-3s"), \
                        "IAQ",  sensors.data.iaq, " ");
    display.println(s);
    snprintf(s, sizeof(s), PSTR("%-9s %7.2f %-3s"), \
                        "Light", sensors.data.light, "lux");
    display.println(s);
  }
  // print Wifi and MQTT Status
  if (_WLAN_()) {
    if (WiFi.status() == WL_CONNECTED) {
      display.print(F("WiFi "));
      display.print(WiFi.SSID());
      display.print("  ");
      display.print(WiFi.RSSI());
      if (_MQTT_() && (client.connected() || _MQTTPUBLISHED_())) {
        _MQTTPUBLISHED_() = false;
        display.println(F(" *"));
      } else {
        display.println(F(" !"));
     }
    } else {
      display.println(F("No WiFi connection!"));
    }
  }
#ifdef DISPLAY_OTHER
  displayOther(display);
#endif
  // print Battery Status
  if (pmic.chargerEnabled) {
    pmic.updateBatteryVoltage();
    display.print(F("*"));
    display.print(pmic.voltage);
    display.print(F("V ")); 
    if (pmic.bqChargeFault.code == NO_CHARGE_FAULT ) {
      display.println(pmic.bqChargeStatus.message);
    } else {
      display.println(pmic.bqChargeFault.message);
    }
  } else if (pmic.isADC_BATTERYPresent()) {
    pmic.updateBatteryVoltage();
    if (pmic.lowBattery) {
       snprintf(s, sizeof(s), PSTR("%-13s"), "*Low Battery");
    } else if (pmic.boosterEnabled) {
      snprintf(s, sizeof(s), PSTR("%-13s"), "*Booster");
    } else {
      snprintf(s, sizeof(s), PSTR("%-13s"), "Battery");
    }
    display.print(s);
    display.print(pmic.voltage);;
    display.println(F(" V "));
  }
  // print to OLED screen
  display.display();
}

void selectOLED() {
  digitalWrite(CON_SPI_CS, LOW);
  if (_OLEDINIT_()) {
    display.clearDisplay();
    display.display();
  }
}

void deselectOLED() {
  digitalWrite(CON_SPI_CS, HIGH);
}

//  RTC________________________________________________________________
// real clock
RTC_DS3231 rtc;
DateTime   now;
Time       time;
Date       date;

void initRTC() {
  pinMode(RTC_INT, INPUT_PULLUP);

  if (!rtc.begin()) {
    Serial.println("Couldn't find RTC");
  }
  if(rtc.lostPower()) {
    // this will adjust to the date and time at compilation
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }

  rtc.disable32K();
  rtc.writeSqwPinMode(DS3231_OFF);

  rtc.clearAlarm(1);
  rtc.clearAlarm(2);

  // this mode triggers the alarm every the second
  if (!rtc.setAlarm1(rtc.now(), DS3231_A1_PerSecond)) {
    Serial.println("Error, alarm wasn't set!");
  }

  // this mode triggers the alarm every minute (no match);
  // if(!rtc.setAlarm2(rtc.now(), )) {
  //  Serial.println("Error, alarm wasn't set!");
  //}
}

boolean validTime(Time time) {
  if ((time.hour   >= 0 && time.hour   <=23) &&\
      (time.minute >= 0 && time.minute <=59) &&\
      (time.second >= 0 && time.second <=59))
    return true;
  else
    return false;
}

boolean validDate(Date date) {
  if ((date.year  > 2018)                 &&\
      (date.month >=1 && date.month <=12) &&\
      (date.day   >=1 && date.day   <=31))
    return true;
  else
    return false;
}

boolean validTimeString(String time) {
  boolean ok = false;
  if ( (time.length() == 8 && time.charAt(2) == ':' && time.charAt(5) == ':') \
    || (time.length() == 5 && time.charAt(2) == ':') \
    || (time.length() == 6 || time.length() == 4)) {
    ok = validTime(strtoTime(time));
  }
  return ok;
}

Time strtoTime(String str) {
  Time time;
  if (str.length() == 8) {
    time.hour   = str.substring(0, 2).toInt();
    time.minute = str.substring(3, 5).toInt();
    time.second = str.substring(6, 8).toInt();   
  } else if (str.length() == 5) {
    time.hour   = str.substring(0, 2).toInt();
    time.minute = str.substring(3, 5).toInt();
    time.second = 0;  
  } else if (str.length() == 4) {
    time.hour   = str.substring(0, 2).toInt();
    time.minute = str.substring(2, 4).toInt();
    time.second = 0;  
  } else {
    time.hour   = str.substring(0, 2).toInt();
    time.minute = str.substring(2, 4).toInt();
    time.second = str.substring(4, 6).toInt();
  } 
  return time;
}

Date strtoDate(String str) {
  Date date;
  if (str.length() == 10) {
    date.day   = str.substring(0, 2).toInt();
    date.month = str.substring(3, 5).toInt();
    date.year  = str.substring(6, 10).toInt();
  } else {
    date.day   = str.substring(0, 2).toInt();
    date.month = str.substring(2, 4).toInt();
    date.year  = str.substring(4, 8).toInt();
  }
  return date;
}

String inttoStrHH_MM(int i) {
  int hour = i / 100;
  i = i - hour*100;
  snprintf(s, sizeof(s), PSTR("%02d:%02d"), hour, i);
  return s;
}

//  Aux functions______________________________________________________


// System
void systemDelay(int waits) {
  unsigned long  delayMicroSeconds;
  delayMicroSeconds = micros() + waits * 1000;
  while (micros() < delayMicroSeconds) {
    if (NEWSECOND && _EXIT_() && _OLED_() && _OLEDINIT_()) {
      now = rtc.now();
      displayDisplay();
    }
    if (Serial.available()) {
      char c = (char)Serial.read();
      // not in command mode, open command mode
      if (_EXIT_() && c == '#') {
        modulCommand_();
        return;
      }
      if (c == ESC) {
        return;
       }
     }
  }
}

void systemReboot(const char *message, int code) {
  snprintf(s, sizeof(s), PSTR("REBOOT %s"), message);
  xSerial.printDateTimeln(MSG_SYS, s);
  // System restart in 2 seconds 
  Watchdog.enable(2000); 
  xSerial.printDateTimeln(MSG_SYS , "WATCHDOG Shutdown and restart in 4 seconds!", code);
  while (true)
      ;
} 

void systemReboot_checkOnFuncDisabled() {
  // Reboot, if WLAN or MQTT are deactivated due to failed login
  if (_WATCHDOG_()) {
    if (state.errorCount.wlan.reboot == 99
        || state.errorCount.mqtt.reboot  ==  99) {
      systemReboot("- connection problems not solved!", ERRCODE_SYS);
    } 
  } else {
    xSerial.printDateTimeln(MSG_SYS, "Reboot aborted. WatchDog not enabled!"); 
  }
}

void _commandMode(boolean enable) {
  if (enable) {
    _EXIT_() = false;
    blink.fast();
    xSerial.printDateTimeln(MSG_SYS, "command mode is active!");
   if (_LOGBOOK_())
      logbook.initPointer();
  } else {
    _EXIT_() = true;
    Serial.println();
    blink.deselect();
    saveSetupECCX08();
    xSerial.printDateTimeln(MSG_SYS, "left command mode. System is running!");
    state.init();

  }
}

char* String2char(String string) {
  if (string.length() != 0) {
    char *p = const_cast<char*>(string.c_str());
    return p;
  }
}

String readSerialStringCmd(int len) {
  String cmd;
  cmd = xSerial.readString();
  if (!isDigit(cmd.charAt(0))) {
    cmd = cmd.substring(0, len);
    cmd.toUpperCase();
  }
  return cmd;
}

void logbookBackupRecordOnFlash(char *messageType,\
                                char *message, \
                               int   errCode) {
  snprintf(logbook.data.message, sizeof(logbook.data.message), \
                                 PSTR("%-5s %s"), messageType, message);
  logbook.data.errCode = errCode;
  logbook.backupRecordOnFlash();
}


boolean wait4Serialread(uint long waits, char c) {
  uint long microSeconds = micros() + 1000 * waits;
  uint long time4Beep = 0;
  while(micros() < microSeconds) {
    if (micros() > time4Beep) {
      playTones(TUNE_STARTUP);
      time4Beep = micros() + 1000000;
    }
    if (Serial.available() && (char)Serial.read() == c ) {
      return true;
    }
  }
  return false;
}

String bool2OnOff(int i) {
  if (i == 1)
    return "on";
  else if (i == 0)
    return "off";
  else 
    return " to check";
}

String bool2YesNo(int i) {
  if (i == 1)
    return "yes";
  else if (i == 0)
    return "no";
  else 
    return " to check";
}

int onOff2bool(String string) {
  if (string == "on") {
    return 1;
  } else if (string == "off") {
    return 0;
  } else {
    return -1;
  }
}

// Debug
void printPageBytes(uint32_t addr, byte *data_buffer, int size) {
  char addrBuffer[12];
  char buffer[3];
  char asciiChar;
  int  asciiCode;
  int z = 0;
  boolean endOfSize = false;
  for (int a = 0; a < 16; ++a) {
    if (!endOfSize) {
      snprintf(addrBuffer, sizeof(addrBuffer), PSTR("%010X: "), (addr + a * 16), HEX);
      Serial.print(addrBuffer);
      // print byte (hex)
      for (int b = 0; b < 16; ++b) {
        snprintf(buffer, sizeof(buffer), PSTR("%02X"), \
                  (uint8_t)data_buffer[a * 16 + b]);
        Serial.print(buffer);
        Serial.print(" ");
      }
      // print char (ascii)
      for (int c = 0; c < 16; ++c) {
        if (z++ < size) {
          asciiCode = (uint8_t)data_buffer[a * 16 + c];
          if (31 < asciiCode && asciiCode < 127)
            asciiChar = (char)data_buffer[a * 16 + c];
          else
            asciiChar = '.';
          snprintf(buffer, sizeof(buffer), PSTR("%c"), asciiChar);
          Serial.print(buffer);
        } else {
          endOfSize = true;
          break;
        }        
      }  
      Serial.println();
    }
  }
  Serial.println();
}

void dumpBuffer() {
  uint32_t addr = 0;;
  uint8_t  dataBuffer[SPI_PAGESIZE];
  Logbook  logbookBuffer;
  char *target = MSG_FLASH;
  String   cmdString;
  byte     *buffer;
  Serial.println();
  if (_DEBUG_()) {
    Serial.println(">>Struct Buffer Sensors:");
    printPageBytes((uint32_t)&sensors.data,                             \
                   (byte *)&sensors.data,                               \
                    sizeof(SensorData));
    Serial.println(">>Struct Buffer Logbook:");
    printPageBytes((uint32_t)&logbook.data,                             \
                   (byte *)&logbook.data,                               \
                    sizeof(LogbookData));
    Serial.print(">>Addr RAM Buffer for Flash Data: ");                
    Serial.println((uint32_t)dataBuffer, HEX);
  }
  printDumpHelp();
  snprintf(s, sizeof(s), PSTR(">> %-5s "),target);
  Serial.print(s);
  cmdString = xSerial.readString();
  cmdString.toUpperCase();
  while (cmdString != "EX") {
    if (cmdString == "RA") {
      target = MSG_RAM;
      addr = 0;
    } else if (cmdString == "FL") {
      target = MSG_FLASH; 
      addr = 0;
    } else if (cmdString == "-") {
      addr = addr - SPI_PAGESIZE;
    } else if (cmdString == "+") {
      addr = addr + SPI_PAGESIZE;     
    } else if (isDigit(cmdString.charAt(0))) {
        addr = xString.hexToInt(cmdString);
    } else {
       printDumpHelp();      
    }
    if (target == MSG_RAM) {
        buffer = (byte *)addr;
    } else {
      if (flashBegin())
        flash.readByteArray(addr, dataBuffer, SPI_PAGESIZE, false);
      deselectFlash();    
      buffer = dataBuffer;
    }
    snprintf(s, sizeof(s), PSTR("> %-5s dump at address 0x%6x"), \
                                target, addr);
    Serial.println(s);
    printPageBytes(addr, buffer, SPI_PAGESIZE);
    snprintf(s, sizeof(s), PSTR(">> %-5s "),target);
    Serial.print(s);
    cmdString = xSerial.readString();
    cmdString.toUpperCase();
  }
}

void printDumpHelp() {
  xSerial.println(">*** Dump Buffer Mode ***");
  xSerial.println(">Please enter command");
  xSerial.println("> skip to RAM  : ra[m]"); 
  xSerial.println("> skip to Flash: fl[ash]");   
  xSerial.println("> prev page    : -");
  xSerial.println("> next page    : +");
  xSerial.println("> addr HEX/DEC : 0x[[0..9],[A..F]]"); 
  xSerial.println("> Exit         : ex[it]");
  xSerial.println("> ");
}

// Error
void errLeds(int j) {
  blink.fast();
  for (int i=0; i < j; i++) {
    playTones(TUNE_TOP_BUTTON_PRESS);
    systemDelay(1000);
  }
  blink.deselect();
}
