// Copyright 2021 <Hermann Buescher>
#include "./ModulTest.h"

void testFunction() {
  String string;
  int n;
  Serial.println("run test");
  Serial.println("nothing to do! :-)");
  // put your setup code here, to run test
}