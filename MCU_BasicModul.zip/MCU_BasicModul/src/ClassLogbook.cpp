//  Copyright 2019 <Hermann Buescher>
#include "./ClassLogbook.h"

void Logbook::backupRecordOnFlash() {
  if (flashBegin()) {
    // Check overrun - 10 messages in reserve
    if ((getNumOfRecords() > getMaxNumOfRecords() - 5) && !overrun) {
      overrun = true;
      numOfRecordsOverrun();
      overrun = false;
    } else {
      setRecord();
      writeFlash(act);
    }
  }
  deselectFlash();
}

String Logbook::getRecord(uint32_t act) {
  readFlash(act);
  return getStringOfRecord(',');
}

void Logbook::setRecord() {
  data.recordId     = getNumOfRecords();
  data.date.year    = now.year();
  data.date.month   = now.month();
  data.date.day     = now.day();
  data.time.hour    = now.hour();
  data.time.minute  = now.minute();
  data.time.second  = now.second();
  // => things logbookBackupRecordOnFlash
  // data.errCode      = errCode;
  // snprintf(data.message, sizeof(data.message),PSTR("%s"), string);
}; 


