// Copyright 2020 <Hermann Buescher>
#include "./ModulCommand.h"

#define CMD_ABOUT         "AB"
#define CMD_BATTERY       "BA"
#define CMD_BROWSE_LOGBK  "BR"
#define CMD_DATE          "DA"
#define CMD_DEBUG         "DE"
#define CMD_DEBUGTRACK    "DT"
#define CMD_DUMP          "DU"
#define CMD_ERASEFLASH    "ER"
#define CMD_EXIT          "EX"
#define CMD_LIST          "LI"
#define CMD_LOGBOOK       "LO"
#define CMD_LOAD          "LX"
#define CMD_MEMORY        "ME"
#define CMD_MODUL         "MO"
#define CMD_MQTT          "MQ"
#define CMD_OLED          "OL"
#define CMD_REBOOT        "RB"
#define CMD_RESET         "RS"
#define CMD_RGB_LED       "RG"
#define CMD_SCHEDULETASK  "ST"
#define CMD_BACKUP_SD     "SD"
#define CMD_SENSORS       "SE"
#define CMD_SAVE          "SX"
#define CMD_TEST_CONNECT  "TC"
#define CMD_TEST          "TE"
#define CMD_TIME          "TI"
#define CMD_WATCHDOG      "WA"
#define CMD_WLAN          "WI"

String cmdStr = "";
String cmd;

void modulCommand_() {
  _commandMode(true);
  xSerial.println("Hey you! Welcome!");
  commandHelp();
  while (!_EXIT_()) {
    cmdStr = xSerial.readString();
    cmd = cmdStr.substring(0, 2);
    cmd.toUpperCase();
    if (cmd == CMD_SCHEDULETASK)        { execAlarm();
    } else if (cmd == CMD_ABOUT)        { execAbout();
    } else if (cmd == CMD_BATTERY)      { execBattery();
    } else if (cmd == CMD_BACKUP_SD)    { execBackupOnSD();
    } else if (cmd == CMD_LOGBOOK)      { execLogbook();
    } else if (cmd == CMD_BROWSE_LOGBK) { execBrowseLogbook();   
    } else if (cmd == CMD_DATE)         { execDateOptions();
    } else if (cmd == CMD_DEBUG)        { execDebug();
    } else if (cmd == CMD_DEBUGTRACK)   { execDebugTrack();
    } else if (cmd == CMD_DUMP)         { execDump();
    } else if (cmd == CMD_ERASEFLASH)   { execEraseFlash();
    } else if (cmd == CMD_EXIT)         { execExit();
    } else if (cmd == CMD_LIST)         { execListOptions();
    } else if (cmd == CMD_LOAD)         { execLoadSetup();
    } else if (cmd == CMD_MEMORY)       { execMemory();
    } else if (cmd == CMD_MODUL)        { execModul();
    } else if (cmd == CMD_MQTT)         { execMQTT();
    } else if (cmd == CMD_OLED)         { execOLEDOptions();
    } else if (cmd == CMD_REBOOT)       { execReboot();
    } else if (cmd == CMD_RESET)        { execReset();
    } else if (cmd == CMD_RGB_LED)      { execRGBLEDOptions();
    } else if (cmd == CMD_SAVE)         { execSaveSetup();
    } else if (cmd == CMD_SENSORS)      { execSensors();
    } else if (cmd == CMD_TEST)         { execTest();
    } else if (cmd == CMD_TEST_CONNECT) { execTestConnections();
    } else if (cmd == CMD_TIME)         { execTimeOptions();
    } else if (cmd == CMD_WATCHDOG)     { execWatchDog();
    } else if (cmd == CMD_WLAN)         { execWLAN();
    } else {
      xSerial.println("<unknown command>\r");
      commandHelp();
    }
  }
}

void commandHelp() {
  if (_SECURITYMODE_()) {
    xSerial.println("");
    xSerial.println("*** Booting is not yet completed! ***");
    xSerial.println("*** System is in security mode!   ***");
    xSerial.println("");
  }
  xSerial.println("Please enter command");
  xSerial.println("WiFi/ MQTT: Wi[Fi], mq[tt], t[est]c[onnections]");
  xSerial.println("Sensors   : se[nsors],");
  xSerial.println("Logbook   : br[owse], lo[gbook]");
  xSerial.println("Clock     : da[te], ti[me], s[chedule]T[ask]");
  xSerial.println("Other     : ba[ttery], OL[ED], RG[B-LED],");
  xSerial.println("Backup    : er[aseFlash], sd[-Card backup],");
  xSerial.println("ECCX08    : lx[[loadECCX08], sx[saveECCX08],");
  xSerial.println("Debug     : de[bug], dt[rack], du[mp], li[st], me[mory],");
  xSerial.println("System    : ab[out], mo[dul],r[e]b[oot], r[e]s[et], te[st],wa[tchDog],");
  xSerial.println("Exit      : ex[it]"); 
}
// General

void execAbout() {
  snprintf(s , sizeof(s), "Firmware Version %s", BASICMODUL_VERSION);
  xSerial.printDateTimeln(MSG_SYS, s);
}

// Boolean Options_____________________________________________________________

//  COM functions______________________________________________________
// WLAN
void execWLAN() { 
  boolean hiddenInput; 
  xSerial.askAndSet("WiFi", &_WLAN_());
  if (xSerial.reTurn.esc || xSerial.reTurn.err) {
    return;
  }
  if (!_WLAN_()) {
    if (xSerial.reTurn.string == "N") {
      _MQTT_() = false;
      disconnectMQTT();
      disconnectWLAN();
      state.errorCount.wlan.login = 0;
    }
    return;
  }
  // Login data
  loadECCX08("SSID and Password loaded from Slot ", SLOT_SSID_PWD);
  boolean updateSSID = setECCX08Buffer("SSID",       \
                                   BUFFER_SSID_ADDR, \
                                   BUFFER_SSID_LEN,  \
                                   hiddenInput = false);
  boolean updatePWD  = setECCX08Buffer("Password",   \
                                   BUFFER_PWD_ADDR,  \
                                   BUFFER_PWD_LEN,   \
                                   hiddenInput = true);
  // Confirm login data
  if (xSerial.ask("Please confirm WiFi login data?") == "Y") {
    if (updateSSID || updatePWD) {
      _RESTORE_() = true;
      saveECCX08("SSID and Password saved in Slot ", SLOT_SSID_PWD);
    }
    beginWiFi();
    if (xSerial.ask("Test connection ?") == "Y") {
      testWiFiConnection();
    }
  } else {
    _WLAN_() = false;
    xSerial.println("WiFi login settings canceled!");
  }
}

// MQTT
void execMQTT() {  
  xSerial.askAndSet("MQTT", &_MQTT_());
  if (xSerial.reTurn.esc || xSerial.reTurn.err) {
    return;
  }
  // MQTT was ON. Close the connection!
  if (!_MQTT_()) {
    if (xSerial.reTurn.string == "N") {
      disconnectMQTT();
      state.errorCount.mqtt.login = 0;
    }
    return;
  }
  // No WLAN connection
  if (!_WLAN_()) {
    _MQTT_() = false;
    xSerial.println("please activate WiFi first!");
    return;
  }
  // Login data
  loadECCX08("IP Address and Port loaded from Slot ", SLOT_MQTT);
  boolean updateServer   = setECCX08Buffer("IP address",\
                                       BUFFER_SERVER_ADDR, \
                                       BUFFER_SERVER_LEN);
  boolean updatePort     = setECCX08Buffer("Port",\
                                       BUFFER_PORT_ADDR,  \
                                       BUFFER_PORT_LEN);
  boolean updateUsername = setECCX08Buffer("Username",\
                                       BUFFER_USERNAME_ADDR,\
                                       BUFFER_USERNAME_LEN);
  
  // Client Loop
  xSerial.askAndSet("Client Loop", &_CLIENTLOOP_());
  if (xSerial.reTurn.esc) {
    _MQTT_() = false;
    return;
  }
  if (!_CLIENTLOOP_()) {
    disconnectMQTT();
  }
  
  // Confirm login data
  if (xSerial.ask("Please confirm MQTT login data?") == "Y") {
    if (updateServer || updatePort || updateUsername) {
      _RESTORE_() = true;
      saveECCX08("IPAddress and Port saved in Slot ", SLOT_MQTT);
      if (_MQTTBEGIN_())
        disconnectMQTT();
      beginMQTT();
    }
    if (xSerial.ask("Test connection ?") == "Y") {
      testMQTTConnection();
      disconnectMQTT();
    }
  } else {
    _MQTT_() = false;
    xSerial.println("MQTT login settings canceled!");
  }
}

String getNewCode(const char *target, int len, boolean hidden) {
  // char s[80] = {0};
  String code, code2;
  while(true) {
    snprintf(s, sizeof(s), PSTR("New %-16s: "), target);
    Serial.print(s);
    code = xSerial.readString(hidden);
    if (xSerial.reTurn.esc)
      return "";
    if (checkStrlen(code, len)) {
      if (!hidden) {
        return code;
      } else {
        snprintf(s, sizeof(s), PSTR("%-20s: "), "Please repeat");
        Serial.print(s);
        code2 = xSerial.readString(hidden);
        if (xSerial.reTurn.esc)
          return "";
        if (checkStrlen(code2, len) && code == code2) {
          xSerial.println("Congratulation - Passwords match!");
          return code;
        } else {
          xSerial.println("No match - Please try again!");
        }
      }
    }
  }
}

boolean checkStrlen(String string, int strlen) {
  if (string.length() > strlen) {
    snprintf(s, sizeof(s), PSTR("String is too long - max length %d bytes"), strlen);
    xSerial.printDateTimeln(MSG_SYS, s);
    return false;
  } else {
    return true;
  }
}


//  ECCX08 functions____________________________________________________

boolean setECCX08Buffer(const char *target, int addr, int len, boolean hiddenInput) {
  // char s[80];
  char sHidden[30];
  char *ptr;
  String  newCode    = "";
  String  code       = String((char*)(bufferECCX08+addr));
  boolean hidden     = false;
  boolean update     = false;

  while (true) {
     // clear buffer
    xString.clearBuffer(s, sizeof(s),0);
    // get new code
    if (code.length() == 0 || update) {
      newCode = getNewCode(target, len, hiddenInput); 
      if (newCode.length() != 0) {
        update = true;
        code = newCode;
      }
    }
    // Format the verification code
    if (hiddenInput) {
      xString.clearBuffer(sHidden, sizeof(sHidden), 0);
      xString.clearBuffer(sHidden, code.length() + 1, '*');
      ptr = sHidden;
    } else {
      ptr = const_cast<char*>(code.c_str());
    }
    // code confirmation
    snprintf(s, sizeof(s), PSTR("%-20s: %-*s - ok?"),\
             target, LOGIN_PASSWORD_LEN, ptr);
    if (xSerial.ask(s) == "Y") {
      // code is confirmed
      if (update) {
        writeBufferStr(code, addr, len);
      }
      return update;
    } else if (xSerial.reTurn.esc) {
      // cancel confirmation
      return update;
    } else {
      // new code
      update = true;
    }
  }
}

// 
void execSaveSetup() {
  saveSetupECCX08();
}

void execLoadSetup() {
  loadSetupECCX08();
}

// Sensors, Logbook and Flash-Options________________________________________
// Sensors
void execSensors() {
  // char s[80];
  xSerial.askAndSet("Sensor function", &_SENSORS_());
  if (xSerial.reTurn.esc || xSerial.reTurn.err) {
    return;
  }
  if (_SENSORS_()) {
     _RESTORE_() = true;
    // Set temperature offset
    sensors.setNewTemperatureOffset();
    // backup on flash?
    if (xSerial.ask("Save sensor data on flash - ok? ") == "Y") {
      // recommended to erase sensors data flash memory!
       _BACKUPONFLASH_() = true;
      if (xSerial.ask("It is recommended to delete the flash memory! - ok?") == "Y") {
        if (xSerial.ask("Please confirm with YES: ") == "YES") {
          playTones(TUNE_DONE);
          sensors.eraseFlashReservedBuffer();
        } else {
          return;
        }
      }
      //  Flash memory startadress
      sensors.setFlashMemoryAddress("first", &sensors.first, 0x10000, 0x170000);
      sensors.setFlashMemoryAddress("last",  &sensors.lastDataAddr,  0x20000, 0x1F0000);
      // frequency - every x minutes
      state.freq.backupRecordOnFlash = sensors.setFrequency(state.freq.backupRecordOnFlash);
      // init Pointer
      sensors.initPointer();
    } else {
      _BACKUPONFLASH_() = false;
    }
    // publish mqtt?
    if (xSerial.ask("Publish Sensors state - ok?") == "Y") {
      _PUBLISHDATA_() = true;
       // frequency - every x minutes
      state.freq.pubSensor = sensors.setFrequency(state.freq.pubSensor);
    } else {
      _PUBLISHDATA_() = false;
    }
  } else {
    _SENSORS_() = false;
  }
}

// Logbook
void execLogbook() {
  // char s[80];
  xSerial.askAndSet("Logbook", &_LOGBOOK_());
  if (xSerial.reTurn.esc || xSerial.reTurn.err) {
    return;
  }
  if (_LOGBOOK_()) {
    _RESTORE_() = true;
    if (xSerial.ask("It is recommended to delete the flash memory! - ok?") == "Y") {
      if (xSerial.ask("Please confirm with YES: ") == "YES") {
        playTones(TUNE_DONE);
          logbook.eraseFlashReservedBuffer();
      } else {
        return;
      }
    }
    //  Flash memory startadress
    logbook.setFlashMemoryAddress("first", &logbook.first, 0x100000, 0x170000);
    logbook.setFlashMemoryAddress("last",  &logbook.lastDataAddr,  0x150000, 0x1F0000);
    // init pointers
    logbook.initPointer();
  } else {
    _LOGBOOK_() = false;
  }
}

void execBrowseLogbook() {
  if (_LOGBOOK_()) {
    browseLogbook();
    logbook.initPointer();
  } else {
   xSerial.println("Please open Logbook before browsing!");
  }
}

// Flash memory
void execBackupRecordOnFlash() {
  if (xSerial.ask("Activate Backup on Flash - ok? ") == "Y") {
    flashprintCapacity();
    _BACKUPONFLASH_() = true;
  } else {
    _BACKUPONFLASH_() = false;
  }
}

void execBackupOnSD() {
  // char s[80];
  if (xSerial.ask("Start the backup on SD now - ok? ") == "Y") {
    blink.deselect();
    fullBackupOnSD_Card();
    blink.fast();
  } else {
    if (_ALARM_()) {
      snprintf(s, sizeof(s), PSTR("Scheduled time for the backup is at %s - ok?"),\
                                   + inttoStrHH_MM(state.freq.alarm).c_str());
      if (xSerial.ask(s) == "Y") {
        _BACKUPONSD_() = true;
        _RESTORE_() = true;
        snprintf(s, sizeof(s), PSTR("Daily backup is scheduled at %s!"), \
                                inttoStrHH_MM(state.freq.alarm).c_str());
        xSerial.printDateTimeln(MSG_SDCARD, s);
        xSerial.printDateTimeln(MSG_SDCARD, "Do not forget to insert the SD-Card!");
        return;
      } else {
        xSerial.println("Backup settings canceled!");
      }
    } else {
      xSerial.println("Backup settings candeled, please set the time for the alarm first");
    }
     _BACKUPONSD_() = false;
  }
}

boolean checkMemory() {
  if  ( (sensors.first < logbook.first && sensors.lastDataAddr < logbook.first)\ 
   || (logbook.first < sensors.first && logbook.lastDataAddr < sensors.first)) {
    return true;
  } else {
    xSerial.printDateTimeln(MSG_FLASH,  "Reserve of 64K between the memory areas is mandatory!");
    return false;
  }
}

void execEraseFlash() {
  if (xSerial.ask("Erase sensors data and logbook flash memory? - ok?") == "Y") {
    Serial.print("Please confirm with YES: ");
    if (xSerial.ask("Please confirm with YES: ") == "YES") {
      playTones(TUNE_DONE);
      eraseFlash();
    }
  }
}

//  RTC functions______________________________________________________
// Time
void execTimeOptions() {
  while (true) {
    now = rtc.now();
    snprintf(s,sizeof(s),PSTR("Set Time: [%02d%02d%02d] "),\
                          now.hour(), now.minute(), now.second());
    Serial.print(s);
    cmdStr = xSerial.readString();
    cmdStr = cmdStr.substring(0, 6);
    if (xSerial.reTurn.esc) {
      return;
    } else {
      if (updateTime(cmdStr)) {
        return;
      }
    }
  }
}

//Date
void execDateOptions() {
  while (true) {
    now = rtc.now();
    snprintf(s,sizeof(s),PSTR("Set Date: [%02d%02d%4d] "),\
                          now.day(), now.month(), now.year());
    Serial.print(s);
    cmdStr = xSerial.readString();
    cmdStr = cmdStr.substring(0, 8);
    if (xSerial.reTurn.esc) {
      return;
    } else {
      if (updateDate(cmdStr)) {
        return;
      }
    }
  }
}

// update HHMMSS
boolean updateTime(String str) {  
  Time time;
  time = strtoTime(str);
  if (validTime(time)) {
    now = rtc.now();
    rtc.adjust(DateTime(now.year(), now.month(), now.day(), \
                        time.hour, time.minute, time.second));
    xSerial.printDateTimeln(MSG_SYS, "New time set!");
    return true;
  } else {
    snprintf(s, sizeof(s), PSTR("error: time %s is not valid! "), str);
    xSerial.printDateTimeln(MSG_SYS, s);
    return false;
  }
}

// update DDMMYYYY
boolean updateDate(String str) {
  Date date = strtoDate(cmdStr);
  if (validDate(date)) {
    now = rtc.now();
    rtc.adjust(DateTime(date.year, date.month, date.day, \
                        now.hour(), now.minute(), now.second()));
    xSerial.printDateTimeln(MSG_SYS,  "New date set!");
  } else {
    snprintf(s, sizeof(s), PSTR("error: Date %s is not valid! "), str);
    xSerial.printDateTimeln(MSG_SYS, s);
  }
}


// Alarm
void execAlarm() {
  String cmdStr;
  xSerial.askAndSet("Schedule Task", &_ALARM_());
  if (xSerial.reTurn.esc || !_ALARM_()) 
    return;
  // Set Time of alarm
  _RESTORE_() = true; 
  Time time = getAlarmTime();
  if (!xSerial.reTurn.esc) {
    if (rtc.setAlarm2(DateTime(now.year(), now.month(), now.day(), \
                      time.hour, time.minute, 0), DS3231_A2_Hour)) {
      state.freq.alarm = time.hour * 100 + time.minute;
      snprintf(s, sizeof(s), PSTR("The daily tasks are scheduled at %s!"), \
                              inttoStrHH_MM(state.freq.alarm).c_str());
      xSerial.printDateTimeln(MSG_SYS, s);
    } else {
      state.freq.alarm = -1;
      xSerial.printDateTimeln(MSG_SYS, "RTC Error: alarm wasn't set!");
    }
  } else {
    xSerial.println("Alarm settings canceled!");
  }
}

Time getAlarmTime() {
  while (true) {
    Serial.print("Set the alarm [hhmm]: ");
    cmdStr = xSerial.readString();
    if (xSerial.reTurn.esc) {
      break;
    } else {
      if (validTimeString(cmdStr)) {
        return strtoTime(cmdStr);
      } else {
        snprintf(s, sizeof(s), PSTR("error: time %s is not valid! "), cmdStr);
        xSerial.printDateTimeln(MSG_SYS, s);
      }
    }
  }
}

// System Options_________________________________________________________________
void execBattery() {
  pmicController();
}

void execDebug() {
  xSerial.askAndSet("Debug", &_DEBUG_());
}

void execDebugTrack() {
  xSerial.askAndSet("Debug tracking", &_DEBUGTRACK_());
}

void execDump() {
  dumpBuffer();
}

void execExit() {
  if (xSerial.ask("Exit Setup?") == "Y") {
    if (_LOGBOOK_() || (_SENSORS_() && _BACKUPONFLASH_())) {
      if (!checkMemory())
        return;
    }
    _commandMode(false);
  }
}

void execMemory() {
  Serial.println();
  snprintf(s, sizeof(s),PSTR("* %-20s: %d bytes"), "SAMD21J free RAM", freeMemory());
  Serial.println(s);
  snprintf(s, sizeof(s),PSTR("* %-20s: %d MB/ HEX 0x%x bytes"), "Flash memory (size)",\
                               flashCapacity/ 1048576, flashCapacity);
  Serial.println(s);
  sensors.report(s, sizeof(s));
  logbook.report(s, sizeof(s));
  xSerial.println();
}

void execModul() {
    xSerial.askAndSet("Modul", &_MODUL_());
}

void execOLEDOptions() {
  xSerial.askAndSet("OLED", &_OLED_());
  if (_OLED_()) {
    if (!_OLEDINIT_())
      displayInit();
    selectOLED();
  } else {
    displayClear();
    deselectOLED();
  }
}

void execTestConnections() {
  if (xSerial.ask("Test WiFi/ MQTT connections?") == "Y") {
    testWiFiConnection();
    if (_MQTT_())
      testMQTTConnection();
  }
}

void execRGBLEDOptions() {
  xSerial.askAndSet("RGB-LED", &_RGBLED_());
  if (!_RGBLED_())
    rgbLED.off();
}

void execReboot() {
  // char s[80];
  if (xSerial.ask("Reboot system now?") == "Y") {
    execSaveSetup();
    systemReboot("on immediate request!", 0);
  } else if (!xSerial.reTurn.esc) {
    if (_ALARM_()) {
      snprintf(s, sizeof(s), \
               PSTR("Schedule a reboot if the connections are down at %s - ok?"), \
               inttoStrHH_MM(state.freq.alarm).c_str());
      if (xSerial.ask(s) == "Y") {
        if (xSerial.reTurn.esc)
          return;
        _REBOOT_()   = true;
        _WATCHDOG_() = true;
        _RESTORE_()  = true;
        Serial.println();
        snprintf(s, sizeof(s), \
            PSTR("If the WiFi connection is down, system reboot is scheduled at %s!"),\
                 inttoStrHH_MM(state.freq.alarm).c_str());
        xSerial.printDateTimeln(MSG_SYS, s);
        return;
      } else {
        xSerial.println("Reboot settings canceled!");
      }
    } else {
      xSerial.println(\
                  "Reboot settings canceled, please set the time for the alarm first");
    }
    _REBOOT_() = false;
  }
}

void execReset() {
  if (xSerial.ask("Reset system to factory settings?") == "Y") {
    if (xSerial.ask("Please confirm with yes: ") == "YES") {
      _RESTORE_() = false;
      xSerial.printDateTimeln(MSG_SYS,  "System reset!");
      state.init();
      clearBuffer();
      saveECCX08("Clear EXXC08 Buffer of Slot", SLOT_SETUP);
      saveECCX08("Clear EXXC08 Buffer of Slot", SLOT_SSID_PWD);
      saveECCX08("Clear EXXC08 Buffer of Slot", SLOT_MQTT);
      loginWLAN.set((char*)bufferECCX08,\
                    (char*)(bufferECCX08 + BUFFER_PWD_ADDR));
      loginMQTT.set((char*) bufferECCX08,\
           atoi((char*)(bufferECCX08 + BUFFER_PORT_ADDR)), \
                (char*)(bufferECCX08 + BUFFER_USERNAME_ADDR));
      execEraseFlash();
      xSerial.printDateTimeln(MSG_SYS, "System reset done!");
      systemReboot("System reset done!", 0);
    } else {
      xSerial.println("Reset canceled!");
    }
  }
}

void execTest() {
  uint32_t addr        = logbook.first;
  uint32_t block64K    = 64 * 1024;
  uint32_t numOfBlocks = logbook.getSizeOfReservedBuffer() \
                         / block64K + 1;
  if (xSerial.ask("Run test ") == "Y") { 
    _EXIT_() = true;
     testFunction();
    _EXIT_() = false;
  }
  xSerial.println("");
}

void execWatchDog() {
  xSerial.askAndSet("WatchDog", &_WATCHDOG_());
}

//  List Options__________________________________________________________________
//
void execListOptions() {
  boolean sd_Card = checkSD_Card();
  Serial.println();
  // Wifi
  listOptionBoolean("WiFi", &_WLAN_());
  if (_WLAN_()) {
    snprintf(s, sizeof(s), PSTR("< %-10s: %-13s%s%-4s, SSID: %s >"), "local IP", \
                           wiFiIPAddress().c_str(), " ", " ",\
                           loginWLAN.get()->server);
    Serial.println(s);
  } else {
    Serial.println();
  }
  // MQTT
  listOptionBoolean("MQTT", &_MQTT_());
  if (_MQTT_()) {
    snprintf(s, sizeof(s),PSTR("< %-10s: %-13s%s%-4d, user: %s >"), "Server IP",\
                          loginMQTT.get()->server, "/",\
                          loginMQTT.get()->port,\
                          loginMQTT.get()->username);
    Serial.println(s);
    listOptionBooleanTabln("Client loop", &_CLIENTLOOP_());
  } else {
    Serial.println();
  }
  // Sensors
  listOptionBooleanln("Sensors", &_SENSORS_());
  snprintf(s, sizeof(s), PSTR("*   %-18s: %-3s %2.3f"), "Temperature Offset", " ",\
                         sensors.temperatureOffset);
  Serial.println(s);
  listOptionBooleanTab("Backup on Flash", &_BACKUPONFLASH_());
  if (_BACKUPONFLASH_()) {
    listOptionSaveEveryFreqln(state.freq.backupRecordOnFlash);
  } else {
    Serial.println();
  }
  listOptionBooleanTab("Publish data", &_PUBLISHDATA_());
  if (_MQTT_() && _PUBLISHDATA_()) {
    listOptionSaveEveryFreqln(state.freq.pubSensor);
  } else {
    Serial.println();
  }
  // Logbook
  listOptionBooleanln("Logbook", &_LOGBOOK_());
  // Alarm
  listOptionBooleanAlarmln("Scheduled tasks", &_ALARM_());
  // Reboot
  listOptionBooleanTabln("Reboot (no WiFi)", &_REBOOT_());
  // Backup on SD
  listOptionBooleanTab("Backup on SD", &_BACKUPONSD_());
  // SD-Card
  if (sd_Card) {
     snprintf(s, sizeof(s),PSTR("< SD-CARD is available>"));
  } else {
    snprintf(s, sizeof(s),PSTR("< SD-CARD is not available>"));
  }
  Serial.println(s);
  // listOptionBooleanln(s, sizeof(s), "Modul", &_MODUL_());
  // OLED
  listOptionBooleanln("OLED", &_OLED_());
  // RGB-LED
  listOptionBooleanln("RGB-LED", &_RGBLED_());
  //PMIC
  listOptionBoolean("PMIC", &_BATTERYCHARGING_());
  snprintf(s, sizeof(s),PSTR("< Booster is %s >"), \
                        bool2OnOff(_BATTERYBOOSTER_()).c_str());
  Serial.println(s);
  // Debug/ Debug-Tracking
  listOptionBoolean("DEBUG", &_DEBUG_());
  snprintf(s, sizeof(s),PSTR("< Tracking is %s >"), \
                        bool2OnOff(_DEBUGTRACK_()).c_str());
  Serial.println(s);
  // Watchdog
  listOptionBoolean("Watchdog", &_WATCHDOG_());
  snprintf(s, sizeof(s),PSTR("< reboot counter (max. %d) WiFi: %d -  MQTT: %d"), \
                        ERRORCOUNT_REBOOT_MAX_TRY, \
                        state.errorCount.wlan.reboot, \
                        state.errorCount.mqtt.reboot);
  xSerial.println(s);
}

void listOptionBoolean(char *t, boolean *option) {
  snprintf(s, sizeof(s),PSTR("* %-20s: %-3s "), t, bool2OnOff(*option).c_str());
  Serial.print(s); 
}

void listOptionBooleanln(char *t, boolean *option) {
  snprintf(s, sizeof(s),PSTR("* %-20s: %-3s "), t, bool2OnOff(*option).c_str());
  Serial.println(s); 
}

void listOptionBooleanTab(char *t, boolean *option) {
  snprintf(s, sizeof(s),PSTR("*   %-18s: %-3s "), t, bool2OnOff(*option).c_str());
  Serial.print(s); 
}

void listOptionBooleanTabln(char *t, boolean *option) {
  snprintf(s, sizeof(s),PSTR("*   %-18s: %-3s "), t, bool2OnOff(*option).c_str());
  Serial.println(s); 
}

void listOptionBooleanAlarmln(char *t, boolean *option) {
  snprintf(s, sizeof(s),PSTR("* %-20s: %-3s "), t, bool2OnOff(*option).c_str());
  Serial.print(s); 
  if (_ALARM_()) {
    snprintf(s, sizeof(s),PSTR("< daily at %s > "), inttoStrHH_MM(state.freq.alarm).c_str());
    Serial.println(s); 
  }  else {
    Serial.println(); 
  }
}

void listOptionSaveEveryFreqln(int freq) {
  snprintf(s, sizeof(s),PSTR("< save data every %d minute(s) > "), freq);
  Serial.println(s); 
}



