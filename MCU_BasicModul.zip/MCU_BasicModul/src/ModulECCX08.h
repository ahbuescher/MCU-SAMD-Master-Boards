// Copyright 2020 <Hermann Buescher>

#ifndef MODULECCX08_H_
#define MODULECCX08_H_

#include <Arduino.h>
#include <ArduinoECCX08.h>
#include <RTClib.h>
#include "./Defines.h"
#include "./ClassRecord.h"
#include "./ClassSensors.h"
#include "./ModulSensors.h"
#include "./ClassLogbook.h"
#include "./ModulLogbook.h"
#include "./ClassState.h"

// include declarations
// Things
extern RTC_DS3231 rtc;
extern State      state;

void   initRTC();

//  ECCX08______________________________________________________________

extern byte      bufferECCX08[72];  // =BUFFER_SSID_ADDR
extern const int BUFFER_PWD_ADDR;
extern const int BUFFER_PWD_LEN;
extern const int BUFFER_SSID_ADDR;
extern const int BUFFER_SSID_LEN;
extern const int BUFFER_PORT_ADDR;
extern const int BUFFER_PORT_LEN;
extern const int BUFFER_USERNAME_ADDR;
extern const int BUFFER_USERNAME_LEN;
extern const int BUFFER_SERVER_ADDR;
extern const int BUFFER_SERVER_LEN;

void  clearBuffer();
void* load(void* destination, void* source, size_t count);
void  loadECCX08(const char *message, const int slot);
void  loadSetupECCX08();
void  loadXbit();
void* save(void* destination, void* source, size_t count);
void  saveECCX08(const char *message, const int slot);
void  saveSetupECCX08();
void  saveXbit();
void  writeBufferStr(String str, int addr, int len);


#endif  // MODULECCX08_H_
