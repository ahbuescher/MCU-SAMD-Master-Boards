// Copyright 2019 <Hermann Buescher>
#ifndef MODULSETUP_H_
#define MODULSETUP_H_

#include "Arduino.h"
#include <WiFiNINA.h>             // WIFI
#include <utility/wifi_drv.h>     // RGB_LED
#include <ArduinoECCX08.h>
#include <Adafruit_SleepyDog.h>
#include "./Defines.h"
#include "./ClassSensors.h"
#include "./ModulSensors.h"
#include "./ClassLogbook.h"
#include "./ModulLogbook.h"
#include "./ModulThings.h"
#include "./ClassLogin.h"
#include "./ClassState.h"
#include "./ModulCommand.h"

extern SensorData sensorData;
extern Sensors    sensors;
extern Logbook    logbook;
extern State      state;
extern Login      loginWLAN;
extern Login      loginMQTT;
extern PMIC       pmic;

extern byte        bufferECCX08[72];
extern RTC_DS3231  rtc;
extern DateTime    now;

void   modulSetup();
void   logbookSetup();

#endif  // MODULSETUP_H_
