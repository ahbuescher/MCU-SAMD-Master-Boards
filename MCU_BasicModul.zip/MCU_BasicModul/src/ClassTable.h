// Copyright 2021 <Hermann Buescher>
#ifndef CLASSTABLE__H_
#define CLASSTABLE__H_

#include <Arduino.h>

struct TableStruct {
   int  key;
   char text[40];
};

class Table {
  public:
   Table(TableStruct linkToElements[]);
   TableStruct *element;

   char* findText(int key);
};

#endif //  CLASSTABLE_H_