// Copyright 2019 <Hermann Buescher>
#ifndef MODULSENSORS_H_
#define MODULSENSORS_H_

#include <Arduino.h>
#include "./ClassSensors.h"
#include "./defines.h"

extern SensorData sensorData;
extern Sensors    sensors;
extern char s[S_LEN_OF_SERIALBUFFER];

void   sensorsSetup();
#endif  // MODULSENSORS_H_
