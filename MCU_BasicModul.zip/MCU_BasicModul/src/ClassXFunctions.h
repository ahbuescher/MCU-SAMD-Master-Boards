// Copyright 2019 <Hermann Buescher>
#ifndef CLASSXFUNCTIONS__H_
#define CLASSXFUNCTIONS__H_
#include <Arduino.h>
#include <Defines.h>
#include <RTClib.h>
#include "./ClassTrigger.h"

extern RTC_DS3231 rtc;
extern DateTime   now;
extern char s[S_LEN_OF_SERIALBUFFER];

// includes_____________________________________
// things
void logbookBackupRecordOnFlash(char *messageType,\
                                char *message, \
                                int   errCode);
String   bool2OnOff(int i);
void     printPageBytes(uint32_t addr, byte *data_buffer, int size);

class XString:public String {
  public:
   const char *bool2OnOff(int i);
   uint32_t    hexToInt(String hexDecString);
   void        clearBuffer(const char* s, size_t size, int ascii = 0);
};

extern XString xString;

struct ReTurn {
  boolean err;
  boolean cr;
  boolean esc;
  int     length;
  String  string;
};

class XSerial {
 public:
  ReTurn  reTurn;
  String  ask(char *str);
  void    askAndSet(char *str, boolean *option);
  String  readString(boolean hidden = false);
  void    println(char *str = "");
  void    printDateTimeln(char *messageType, \
                          char *message,\
                          int errCode = 0);
};
extern XSerial xSerial;

#endif  // CLASSXFUNCTIONS_H_
