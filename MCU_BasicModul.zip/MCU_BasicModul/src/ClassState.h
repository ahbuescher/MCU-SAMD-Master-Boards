// Copyright 2020 <Hermann Buescher>
#ifndef CLASSSTATE_H_
#define CLASSSTATE_H_

#include <Arduino.h>
#include "./defines.h"
//  #include <RTClib.h>
#include "./ClassBattery.h"
#include "./ClassSensors.h"
#include "./ClassLogbook.h"
// #include "./ModulThings.h"

extern  RTC_DS3231 rtc;
extern  DateTime   now;
extern  Sensors    sensors;
extern  Logbook    logbook;
extern  PMIC       pmic;

// Include functions
//   WLAN
void    deactivateWLAN();
boolean connectStatusWLAN_();
//   MQTT
void    publishSensorsState();
//   SD-Card
void    backupOnSD_Card();
void    fullBackupOnSD_Card();
// Things
void    chargingCompleted();
void    updateLowBatteryFlag();
void    displayClear();
void    displayDisplay();
void    displayInit();
boolean isChargingTerminationDone();
void    systemReboot_checkOnFuncDisabled();
boolean updatePMIC();
// ECCX08
void    saveSetupECCX08();

//  State_______________________________________________
struct ErrorCount {
    struct WLAN {
        int login;
        int tryPerLogin;
        int maxTry;
        int reboot;
    } wlan;
    struct MQTT {
        int login;
        int tryPerLogin;
        int maxTry;
        int reboot;
    } mqtt;
};

struct Frequency {
    int wlan;           // check WLAN connection every x minutes
    int backupRecordOnFlash;  // save record every x minutes
    int pubSensor;      // publish sensor data every x seconds
    int alarm;          // Alarm every day at HHMMSS or -1
};

struct TimeForEvent {   // Scheduler
  struct Day {
     uint8_t upToDate;  // new day
  } day;
  struct Hour {
     uint8_t upToDate;  // new hour
  } hour;
  struct Minute {
    uint8_t upToDate;  // new minute
    int     flash;     // tims for flash actions <freq: every x minutes>
    int     sensor;    // time for data update  <freq: every x minutes>
    int     wlan;      // time for wlan actions  <freq: every x minutes>
  } minute;
  struct Second {
    uint8_t upToDate;  // new second
  } second;
};

class State {
 public:
    State();

    TimeForEvent timeForEvent;
    ErrorCount   errorCount;
    Frequency    freq;
    void         clearErrorCountWLAN_();
    void         clearErrorCountMQTT_();
    void         countCheckerAfterReboot();
    void         init();
    void         updateTimeForEvent();
    void         update();
};

#endif  // CLASSSTATE_H_
