// Copyright <Hermann Buescher>
#ifndef MODULCOM_H_
#define MODULCOM_H_

#include <Arduino.h>
#include <WiFiNINA.h>             // WIFI
#include <utility/wifi_drv.h>     // RGB_LED
#include <MQTT.h>
#include <Adafruit_SleepyDog.h>
#include "./Defines.h"
#include "./ClassTable.h"
#include "./ClassSensors.h"
#include "./ModulThings.h"
#include "./ClassLogin.h"
#include "./ClassState.h"
#include "./ClassTopics.h"
#include "./ModulECCX08.h"

// include declarations
// Modul ECCX08
extern byte bufferECCX08[72];  // =BUFFER_SSID_ADDR
void  loadECCX08(const char *message, const int slot);

// Things
void systemReboot(const char *message, int errorCode);

void rebootOrDeactivate(String string);

//  WLAN_______________________________________________________________
extern WiFiClient net;
extern State      state;
extern Login      loginWLAN;

void    beginWiFi();
boolean connect2WLAN_();
void    disconnectWLAN();
void    listNetworks();
void    printWifiErrorStatus(int thisType);
boolean connectStatusWLAN();
void    testWiFiConnection();
//  MQTT_______________________________________________________________

extern Sensors sensors;
extern State state;
extern Login loginMQTT;
extern String pubIAQStatus();

void    beginMQTT();
int     clientPublish(String topic, String message);
boolean connect2MQTT_();
boolean disconnectMQTT();
boolean loopMQTT_();
boolean connectStatusMQTT();
void    publishSensorsState();
void    printMQTTErrorStatus(int thisType);
void    printMQTTReturnCode(int thisType);
boolean repairLoopMQTT_();
void    subscribe();
void    testMQTTConnection();
String  wiFiIPAddress();

#endif  // MODULCOM_H_
