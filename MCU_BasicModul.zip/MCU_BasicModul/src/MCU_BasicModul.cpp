// Copyright 2019 <Hermann Buescher
#include "./MCU_BasicModul.h"

const size_t capacityMqtt = CAPACITY_MQTT;

// Serialprint buffer
char s[S_LEN_OF_SERIALBUFFER] = {0};

// Init Objects
Sensors        sensors;
SensorData     sensorData;
Logbook        logbook;
TimeStamp      timeStamp;
RangeOfInteger rangeOfInteger;
RangeOfFloat   rangeOfFloat;
XSerial        xSerial;
State          state;
Function       func;
Login          loginWLAN;
Login          loginMQTT;

BasicModul::BasicModul() {}

void   BasicModul::command() {
    modulCommand_();
}

void BasicModul::commandMode(boolean enable) {
  _commandMode(enable);
}

boolean BasicModul::connect2MQTT() {
  if (_MQTT_())
    return connect2MQTT_();
}

boolean BasicModul::connect2WLAN() {
  if (_WLAN_())
    return connect2WLAN_();
}

boolean BasicModul::loopMQTT() {
  if (_MQTT_()) {
    if (loopMQTT_()) {
      return true;
    } else {
      return repairLoopMQTT_();
    }
  }
}

void    BasicModul::onMessageMQTT() {
  //  client.onMessage(messageReceived);
  //  tbd void  messageReceived(String &topic_, String &payload);
}

void     BasicModul::setup() {
    modulSetup();
}

void     BasicModul::update() {
  if (_MODUL_()) {
    state.update();
  }
}

