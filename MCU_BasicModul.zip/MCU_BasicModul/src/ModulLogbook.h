// Copyright 2019 <Hermann Buescher>
#ifndef MODULLOGBOOK_H_
#define MODULLOGBOOK_H_

#include <Arduino.h>
#include "./ClassLogbook.h"
#include "./defines.h"


extern Logbook logbook;
extern char s[S_LEN_OF_SERIALBUFFER];

uint32_t  adjustPageSize(int32_t recordId, int32_t pageSize);
uint32_t  adjustRecordId(int32_t recordId, int32_t pageSize);
void      browseLogbook();
void      logbookSetup();
void      printBrowseLogbookHelp();
void      printLogbookRecords(uint32_t recordId, uint32_t pageSize);

#endif  // MODULSENSORS_H_
