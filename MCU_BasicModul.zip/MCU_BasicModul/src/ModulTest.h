// Copyright 2021 <Hermann Buescher>
#ifndef TEST_H_
#define TEST_H_

#include <Arduino.h>
#include "./classLED.h"
#include "./ClassSensors.h"
#include "./ModulSensors.h"
#include "./ClassLogbook.h"
#include "./ModulLogbook.h"

extern Sensors sensors;
extern Logbook logbook;
void testFunction();

#endif //  TEST_H_