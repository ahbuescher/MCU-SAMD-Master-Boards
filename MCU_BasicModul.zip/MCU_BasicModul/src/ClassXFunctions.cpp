// Copyright 2019 <Hermann Buescher>
#include "./ClassXFunctions.h"

XString xString;

const char *XString::bool2OnOff(int i) {
  if (i == 1)
    return "on";
  else if (i == 0)
    return "off";
  else 
    return " to check";
}

void XString::clearBuffer(const char* s, size_t size, int ascii) {
  char *ptr = (char *)s;
  for (int i = 0; i < size - 1; i++)
    *ptr++ = ascii;
  *ptr = '\0';
}

uint32_t XString::hexToInt(String string) {
  char s[20] = {0};
  int      x = 0;
  uint32_t y = 0;
  int strlen = string.length();
  memcpy(s, string.c_str(), strlen);
  // check 0x or 0X
  if (s[0] != 0x30 ||(s[1] != 0x58 && s[1] != 0x78))
    return -1;
  int i = 2;
  while (i < strlen) {
    // A - F
    if (s[i] > 0x40 && s[i] < 0x47) {
      x = s[i] - 0x37;
    // a - f
    } else if (s[i] > 0x60 && s[i] < 0x67) {
      x = s[i] - 0x57;
    // 0 - 9
    } else if (s[i] > 0x2F && s[i] < 0x3A) {
      x = s[i] - 0x30;
    }
    y = y * 16 + (uint32_t)x;
    i++;
  }
  return y;
}

String XSerial::ask(char *str) {
  // char s[80] = {0};
  reTurn.esc = false;
  reTurn.cr  = false;
  reTurn.err = false;
  reTurn.string = "Please answer with y[es] or n[o]!";
  snprintf(s, sizeof(s), PSTR("%s y[es]/n[o]"), str);
  Serial.print(s);
  String inputString = readString();
  // printPageBytes((uint32_t)s, (byte *)s, sizeof(s));
  inputString.toUpperCase();
  if (inputString.length() == 0) {   // ESC OR CR
    reTurn.esc = true;
    return reTurn.string = "N";
  } 
  if (inputString == "YES") {
    return reTurn.string ="YES";
  } else if (inputString == "NO") {
    return reTurn.string = "NO";
  }
  char c =  inputString.charAt(0);
  if (c == 'Y') {
    return reTurn.string = "Y";
  } else if (c == 'N') {
    return reTurn.string = "N";
  }
  reTurn.err = true;
  return reTurn.string;
}

void XSerial::askAndSet(char *str, boolean *option) {
  // char s[80];
  snprintf(s, sizeof(s), PSTR("%s is %s - ok?:"), str, xString.bool2OnOff((int)*option));
  Serial.print(s);
  reTurn.string = ask("");
  if (reTurn.string == "N") {
    if (!reTurn.esc) {
      *option = !*option;
      snprintf(s, sizeof(s), PSTR("%s is %s !"), str, xString.bool2OnOff((int)*option));
      println(s);
    }
  } else if (reTurn.string != "Y") {
    reTurn.err = true;
    println("Please answer with y[es] or n[o]!");
  }
}

String XSerial::readString(boolean hidden) {
  reTurn.cr = false;
  reTurn.esc = false;
  reTurn.length = 0;
  char s[40] = {0};
  char *ptr = s;
  char c;
  int n = 0;
  while (c != '\r') {
    if (Serial.available()) {
      c = (char)Serial.read();
      if (c == ESC) {            // ESC
        // cancel
        reTurn.esc = true;
        println();
        return "ESC";
      } else if (c == CR) {    // CR
        if (n == 0) {
          // return - nothing to do
          reTurn.cr = true;
          println();
          return "CR";
        } else {
          // read serial finished
          break;
        }
      } 
      if (hidden) {
        Serial.print('*');
      } else {
        Serial.print(c);
      }
      if (c == BS) {    // BS
        if (n > 0) {
          Serial.print(" \b");
          n = n - 1;
          ptr--;
        } else if (n == 0) {
          Serial.print(" ");
        }
      } else {
        *ptr++ = c;
        n++;
      }
    }
  }
  *ptr = '\0';
  reTurn.length = n;
  println();
  // printPageBytes(uint32_t(s), (byte *)s, sizeof(s));
  return String(s);
}

void XSerial::println(char *str) {
  // char s[80] = {0};
  snprintf(s, sizeof(s), PSTR("%s"), str);
  Serial.println(s);
  if (!_EXIT_())
    Serial.print(">");
}

void XSerial::printDateTimeln(char *messageType, char *message, int errCode) {
  char sDateTime[120] = {0};
  now = rtc.now();
  if (!_EXIT_()) {
    snprintf(sDateTime, sizeof(sDateTime), PSTR("\b%s %-5s %s"), now.timestamp().c_str(), messageType, message);
  } else {
    snprintf(sDateTime, sizeof(sDateTime), PSTR("%s %-5s %s"), now.timestamp().c_str(), messageType, message);
  }
  if (_LOGBOOK_() && _EXIT_()) {
    logbookBackupRecordOnFlash(messageType, message, errCode);
  }
  Serial.println(sDateTime);
  if (!_EXIT_())
    Serial.print(">");
}