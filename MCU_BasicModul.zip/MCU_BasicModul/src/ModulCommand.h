// Copyright 2019 <Hermann Buescher>
#ifndef MODULCOMMAND_H_
#define MODULCOMMAND_H_

#include <MemoryFree.h>
#include "./Defines.h"
#include "./ClassRecord.h"
#include "./ClassSensors.h"
#include "./ModulSensors.h"
#include "./ClassLogbook.h"
#include "./ModulLogbook.h"
#include "./ClassTrigger.h"
#include "./ClassState.h"
#include "./ModulThings.h"
#include "./ClassXFunctions.h"
#include "./ClassLogin.h"
#include "./ModulCom.h"
#include "./ModulTest.h"

extern  State state;
extern  Record record;
extern  Function func;
extern  RangeOfInteger rangeOfInteger;
extern  RangeOfFloat rangeOfFloat;
extern  XSerial xSerial;
extern  uint32_t flashCapacity;

// Include functions
// ECCX08
extern byte      bufferECCX08[72];  // =BUFFER_SSID_ADDR
extern const int BUFFER_PWD_ADDR;
extern const int BUFFER_PWD_LEN;
extern const int BUFFER_SSID_ADDR;
extern const int BUFFER_SSID_LEN;
extern const int BUFFER_PORT_ADDR;
extern const int BUFFER_PORT_LEN;
extern const int BUFFER_USERNAME_ADDR;
extern const int BUFFER_USERNAME_LEN;
extern const int BUFFER_SERVER_ADDR;
extern const int BUFFER_SERVER_LEN;

void    clearBuffer();
void    loadECCX08(String infoText, const int slot);
void    loadSetupECCX08();
void    saveSetupECCX08();
void    saveECCX08(String infoText, const int slot);

//  Command_____________________________________________________________
void    commandHelp();
String  getNewTarget(String target, int  len);
void    listOptionBoolean(char *t, boolean *option);
void    listOptionBooleanln(char *t, boolean *option);
void    listOptionBooleanTab(char *t, boolean *option);
void    listOptionBooleanTabln(char *t, boolean *option);
void    listOptionBooleanAlarmln(char *t, boolean *option);
void    listOptionSaveEveryFreqln(int freq);
void    loadOptions2Boolean_addr_0(byte byte_);
void    loadOptions2Boolean_addr_1(byte byte_);
void    modulCommand_();
boolean updateTime(String str);
boolean updateDate(String str);
void    writeBufferStr(String str, int addr, int len);
void    execAbout();
void    execAlarm();
void    execBattery();
void    execBackupOnSD();
void    execBackupRecordOnFlash();
void    execBrowseLogbook();
void    execDateOptions();
void    execDebug();
void    execDebugTrack();
void    execDump();
void    execEraseFlash();
void    execExit();
void    execListOptions();
void    execLoadSetup();
void    execLogbook();
void    execMemory();
void    execModul();
void    execMQTT();
void    execOLEDOptions();
void    execRGBLEDOptions();
void    execSave_ssid_pwd();
void    execSaveSetup();
void    execSensors();
void    execReboot();
void    execReset();
void    execTest();
void    execTestConnections();
void    execTimeOptions();
void    execWatchDog();
void    execWLAN();
boolean execYesNoOptions(String string);
Time    getAlarmTime();
String  getNewCode(const char *target, int len, boolean hidden);
boolean setECCX08Buffer(const char *target, int addr, int len, boolean hiddenInput = false);
boolean checkStrlen(String string, int strlen);
#endif  // MODULCOMMAND_H_
