// Copyright 2019 <Hermann Buescher>
#ifndef CLASSRECORD_H_
#define CLASSRECORD_H_

#include <Arduino.h>
#include <RTClib.h>
#include <SD.h>
#include <SPIMemory.h>        // Flash memory
#include <MemoryFree.h>
#include "./Defines.h"
#include "./ClassLED.h"
#include "./ClassTrigger.h"
#include "./ClassXFunctions.h"

extern RTC_DS3231 rtc;
extern DateTime   now;
extern SPIFlash   flash;
extern XSerial    xSerial;
extern char s[S_LEN_OF_SERIALBUFFER];

// include funtions_____________________________________________________
// Com
  boolean disconnectMQTT();
  boolean connect2MQTT_();

// Command

extern float reservedMemKB();
extern float usedMemKB();
extern float unusedMemPercentage();
void         execMemoryFree();
void         modulCommand_();

//   ModulThings.h

//     Buzzer
extern const int TUNE_STARTUP;
extern const int TUNE_TOP_BUTTON_PRESS;
extern const int TUNE_BOTTOM_BUTTON_PRESS;
extern const int TUNE_DONE;
extern const int TUNE_MOVE;
extern const int MAX_TUNES;
void    playTones(int tune);
uint32_t stringOfHextoInteger(String string);

// OLED
void   displayInit();
void   displayClear();
void   displayText(String string);
void   displayBackupCompleted();
void   displayBackupRecordNo(char *s, uint32_t x); 
void   displayEraseFlash(char *s);
void   selectOLED();

//     Flash
extern const uint32_t endOfRecords;
extern  uint32_t capacity;
void    eraseFlash();
boolean eraseFlashBlock64K(uint32_t first, uint32_t size);
boolean flashBegin();
void    deselectFlash();
void    selectFlash();

//     SD-Card
void    dateTime(uint16_t* date, uint16_t* time);
boolean checkSD_Card();
void    deselectSD_Card();
void    selectSD_Card();
boolean SD_CardBegin();

//     Aux
extern  XString xString;
void    systemDelay(int waits);
char*   String2char(String string);
void    printPageBytes(uint32_t addr, byte *data_buffer, int size);
void    errLeds(int j);

//  Struct data_________________________________________________________
//  ECCX08 Check validate integer input
struct RangeOfInteger {
  boolean ok;
  uint32_t result;
  boolean validate(uint32_t i, uint32_t min, uint32_t max) {
    if (i >= min && i <= max) {
      result = i;
      return true;
    } else {
      return false;
    }
  }
};
extern  RangeOfInteger rangeOfInteger;

struct RangeOfFloat {
  boolean ok;
  float result;
  boolean validate(float i, float min, float max) {
    if (i >= min && i <= max) {
      result = i;
      return true;
    } else {
      return false;
    }
  }
};
extern  RangeOfFloat rangeOfFloat;



struct DataField {
    String   desc;
    uint32_t field;
    int      type;
    int      len;
};

enum DataType {
    type_uint8_t,
    type_uint16_t,
    type_uint32_t,
    type_int,
    type_char,
    type_float,
    type_string,
    type_record,
    type_date,
    type_time
};

class TimeStamp {
 public:
  uint32_t recordId;
  struct DATE {
    int year;
    uint8_t month;
    uint8_t day;
  } date;
  struct TIME {
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
  } time;
};

extern TimeStamp timeStamp;

//  Record______________________________________________________________
class Record {
 public:
  Record();
  DataField dataField[MAX_DATA_FIELD_ELEMENTS];
  int       numOfFieldElements;

  // Name, Numbers, Addresses and Pointers
  String   recName;
  // pointer of record
  uint32_t first; 
  uint32_t act;
  uint32_t last;
  // Reserved Memmory area: 
  //    StartAddress -> first
  //    EndAddress   -> lastAddress
  uint32_t lastDataAddr;

  uint32_t nextFreePos(char *buffer, uint32_t x);
  uint32_t getSizeOfRecordData();
  uint32_t getSizeOfReservedBuffer();
  uint32_t getNumOfRecords();
  uint32_t getMaxNumOfRecords();
  uint32_t getNext(uint32_t addr);
  uint32_t getPrev(uint32_t addr);

  void    setFirstPointerAddress(uint32_t firstPointerAddr);
  void    setLastDataAddress(uint32_t lastDataAddr);
  void    setMaxNumOfRecords(uint32_t maxNumOfRecords = 0);
  void    setNumOfRecords(uint32_t numOfRecords);
  void    setSizeOfRecordData(uint32_t sizeOfRecordData);
  void    setSizeOfReservedBuffer();

  //  Record::Flash functions___________________________________________
  void    eraseFlashReservedBuffer();
  void    readFlash(uint32_t addr);
  void    writeFlash(uint32_t addr);
  
  //  Record::Data functions____________________________________________
  uint32_t findLastRecord(uint32_t first, uint32_t last);
  String  getStringOfRecord(boolean json = false, char delim = ',' );
  void    initPointer();
  void    numOfRecordsOverrun();
  void    serialDebugPrint(char *task, uint32_t addr, char blank);
  virtual void backupRecordOnFlash();
  virtual void setRecord();

  //  Record::Memory Data functions_____________________________________
  void    readFlashAddress();
  void    readFlashMemoryAddress(uint32_t *pointer, \
                                 uint32_t addrBegin,\
                                 uint32_t addrEnd);
  void    report(char *s, size_t size);
  int     setFrequency(int frequency);
  void    setFlashMemoryAddress(String  firstORlast,\
                                uint32_t *pointer, \
                                uint32_t addrBegin,\
                                uint32_t addrEnd);
  float   usedMemPercentage();


  // Record::SD-Card functions__________________________________________
  virtual void   backup();
  boolean   backupOnSD_Card(String title);
  void   writeSD_CARD();
  
  //  Record::Debug functions___________________________________________
  void   printPointers();

 private:
  uint32_t _numOfRecords;
  uint32_t _maxNumOfRecords;
  uint32_t _sizeOfRecordData;
  uint32_t _sizeOfReservedBuffer;
};

#endif  // CLASSRECORD_H_
