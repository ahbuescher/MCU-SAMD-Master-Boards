// copyright 2019 <Hermann Buescher>
#include "./ClassLogin.h"

Login::Login() {}

void Login::set(char *server, char *password) {
  snprintf(_data.server, LOGIN_SERVERNAME_LEN, server);
  snprintf(_data.password, LOGIN_PASSWORD_LEN, password);
}

void Login::set(char *server, int port, char *username) {
  snprintf(_data.server, LOGIN_SERVERNAME_LEN, server);
  _data.port = port;
  snprintf(_data.username, LOGIN_USERNAME_LEN, username);
}

LoginData *Login::get() {
    return &_data;
}
