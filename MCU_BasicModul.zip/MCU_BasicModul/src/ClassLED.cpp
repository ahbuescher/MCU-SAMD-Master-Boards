// Copyright 2021 <Hermann Buescher>
#include "./ClassLED.h"

RGBLED::RGBLED(int red, int green, int blue):
_pinRED(red), _pinGREEN(green), _pinBLUE(blue)
{
}

RGBLED::RGBLED():
_pinRED(PIN_RGBLED_RED), _pinGREEN(PIN_RGBLED_GREEN), _pinBLUE(PIN_RGBLED_BLUE)
{
}

void RGBLED::init_RGB_LED_PORT() {
  WiFiDrv::pinMode(_pinRED, OUTPUT);
  WiFiDrv::pinMode(_pinGREEN, OUTPUT);
  WiFiDrv::pinMode(_pinBLUE, OUTPUT);
}

void RGBLED::analogWrite_RGB_LED(int red, int green, int blue) {
  WiFiDrv::analogWrite(_pinRED, red);
  WiFiDrv::analogWrite(_pinGREEN, green);
  WiFiDrv::analogWrite(_pinBLUE, blue);
}

void RGBLED::brightness(int rgb[3], int brightness) {
	intensity(rgb[0], rgb[1], rgb[2], brightness);
}

void RGBLED::brightness(int red, int green, int blue, int brightness) {
	intensity(red, green, blue, brightness);
}

void RGBLED::intensity(int red, int green, int blue, int brightness) {
	red = (red * brightness) / 100;
	green = (green * brightness) / 100;
	blue = (blue * brightness) / 100;
	analogWrite_RGB_LED(red, green, blue);
}

void RGBLED::setColor(int rgb[3]) {
  analogWrite_RGB_LED(rgb[0], rgb[1], rgb[2]);
}

void RGBLED::setColor(int red, int green, int blue) {
		analogWrite_RGB_LED(red, green, blue);
}

void RGBLED::off() {
	analogWrite_RGB_LED(0, 0, 0);
}

void RGBLED::toggleColor(int red, int green, int blue, \
                         int red1 = 0, int green1 = 0, int blue1 = 0) {
  if (!on) {
    on = true;
    toggle = true;
  }
  if (toggle) {
    toggle = false ;
    analogWrite_RGB_LED(red, green, blue);
  } else {
    toggle = true;
    analogWrite_RGB_LED(red1, green1, blue1);
  }
}

Blink::Blink(uint32_t period):
_period(period)
{
}

Blink::Blink():
// Number to count to with PWM (TOP value). Frequency can be calculated by
// freq = GCLK5_freq / (TCC0_prescaler * (1 + TOP_value))
// With TOP of  6.000.000, we get a 1 Hz square wave in this example
_period(6000000 - 1)
{
}

void Blink::selectPWM() {
  led = true;
  enableTCC0();
}

void Blink::deselectPWM() {
  led = false;
  disableTCC0();
}

void Blink::deselect() {
  led = false;
  deselectPWM();
  pinMode(LED_BUILTIN, OUTPUT);
}

void Blink::busy() {
  led = true;
  // clockdivider = 1
  // PWM signal to output: duty cycle  = period/8
  timer_GCLK5_TCC0_PA21(1, 100/8);
}

void Blink::fast() {
  led = true;
  // 4Hz - blink every 250ms
  // clockdivider = 1
  // PWM signal to output: 50% duty cycle  = period/2 
  timer_GCLK5_TCC0_PA21(1, 100/2);
}

void Blink::slow() {
  led = true;
  // 1Hz - blink every 1000ms:
  // clockdivider = 8
  // PWM signal to output: duty cycle  = period/2
  timer_GCLK5_TCC0_PA21(8, 100/2);
}

void Blink::verySlow() {
  led = true;
  // clockdivider = 64
  // PWM signal to output: 50% duty cycle  = period/2
  timer_GCLK5_TCC0_PA21(64, 100/2);
}

void Blink::enableTCC0() {
  TCC0->CTRLA.reg |= (TCC_CTRLA_ENABLE);
  while (TCC0->SYNCBUSY.bit.ENABLE);       // Wait for synchronization
}

void Blink::disableTCC0() {
  TCC0->CTRLA.reg &= ~TC_CTRLA_ENABLE;
  // while (GCLK->STATUS.bit.SYNCBUSY);     // Wait for synchronization 
  while (TCC0->SYNCBUSY.bit.ENABLE);  // Wait for synchronization 
}

void Blink::timer_GCLK5_TCC0_PA21(int prescale, int percentOfdutyCycle) {
  // Because we are using TCC0, limit period to 24 bits
  _period = ( _period < 0x00ffffff ) ? _period : 0x00ffffff;
  
  // Enable and configure generic clock generator 5
  GCLK->GENCTRL.reg = GCLK_GENCTRL_IDC |          // Improve duty cycle
                      GCLK_GENCTRL_GENEN |        // Enable generic clock gen
                      GCLK_GENCTRL_SRC_DFLL48M |  // Select 48MHz as source
                      GCLK_GENCTRL_ID(5);         // Select GCLK5
  while (GCLK->STATUS.bit.SYNCBUSY);              // Wait for synchronization

  // Set clock divider of prescale to generic clock generator 5
  GCLK->GENDIV.reg = GCLK_GENDIV_DIV(prescale) |  // Divide 48 MHz by prescale
                     GCLK_GENDIV_ID(5);           // Apply to GCLK5
  while (GCLK->STATUS.bit.SYNCBUSY);              // Wait for synchronization
  
  // Enable GCLK5 and connect it to TCC0 and TCC1
  GCLK->CLKCTRL.reg = GCLK_CLKCTRL_CLKEN |        // Enable generic clock
                      GCLK_CLKCTRL_GEN_GCLK5 |    // Select GCLK5
                      GCLK_CLKCTRL_ID_TCC0_TCC1;  // Feed GCLK5 to TCC1/1
  while (GCLK->STATUS.bit.SYNCBUSY);              // Wait for synchronization

  // Divide counter by 1 giving 48 MHz (1/Mhz =x ns) on each TCC0 tick
  TCC0->CTRLA.reg |= TCC_CTRLA_PRESCALER(TCC_CTRLA_PRESCALER_DIV1_Val);

  // Use "Normal PWM" (single-slope PWM): count up to PER, match on CC[n]
  TCC0->WAVE.reg = TCC_WAVE_WAVEGEN_NPWM;         // Select NPWM as waveform
  while (TCC0->SYNCBUSY.bit.WAVE);                // Wait for synchronization

  // Set the period (the number to count to (TOP) before resetting timer)
  TCC0->PER.reg = _period;
  while (TCC0->SYNCBUSY.bit.PER);

  // Set PWM signal to output 50% duty cycle
  // n for CC[n] is determined by n = x % 4 where x is from WO[x]
  TCC0->CC[3].reg = _period * percentOfdutyCycle/100;
  while (TCC0->SYNCBUSY.bit.CC3);
    
  // Configure PA21 (D1 on MCU = LED_BUILTIN) to be output
  PORT->Group[PORTA].DIRSET.reg = PORT_PA21;      // Set pin as output
  PORT->Group[PORTA].OUTCLR.reg = PORT_PA21;      // Set pin to low

  // Enable the port multiplexer for PA21
  PORT->Group[PORTA].PINCFG[21].reg |= PORT_PINCFG_PMUXEN;

  // Connect TCC0 timer to PA21. Function F is TCC0/WO[7] for PA21.
  // Odd pin num (2*n + 1): use PMUXO
  // Even pin num (2*n): use PMUXE
  PORT->Group[PORTA].PMUX[10].reg = PORT_PMUX_PMUXO_F;

  // Enable output (start PWM)
  TCC0->CTRLA.reg |= (TCC_CTRLA_ENABLE);
  while (TCC0->SYNCBUSY.bit.ENABLE);              // Wait for synchronization
}


RGBLED rgbLED(PIN_RGBLED_RED, PIN_RGBLED_GREEN, PIN_RGBLED_BLUE);
Blink  blink;

