// Copyright <Hermann Buescher>

#include "./ModulECCX08.h"

// ECCX08 Buffer;
byte     bufferECCX08[72];
void*    next = bufferECCX08;

uint32_t sensorsFirst;
uint32_t sensorsLastDataAddr;
uint32_t logbookFirst;
uint32_t logbookLastDataAddr;

// define Buffer Structure for ECCx08 Slot 8,9,10

// ECCX08 Slot 9 WLAN (max 72 bytes)

// Reserved Address  0 - 17:  WLAN SSID
const int BUFFER_SSID_ADDR     = 0;
const int BUFFER_SSID_LEN      = LOGIN_SERVERNAME_LEN;
// Reserved Address 20 - 39:  WLAN PWD
const int BUFFER_PWD_ADDR      = BUFFER_SSID_ADDR + BUFFER_SSID_LEN + 1;
const int BUFFER_PWD_LEN       = LOGIN_PASSWORD_LEN;

// ECCX08 Slot 10 MQTT (max 72 bytes)
// Reserved Address 0 - 17:  MQTT SERVER IP ADDRESS
const int BUFFER_SERVER_ADDR   = 0;
const int BUFFER_SERVER_LEN    = LOGIN_SERVERNAME_LEN;
// Reserved Address 18 - 22: MQTT PORT
const int BUFFER_PORT_ADDR     = BUFFER_SERVER_ADDR + BUFFER_SERVER_LEN + 1;
const int BUFFER_PORT_LEN      = LOGIN_PORT_LEN;
// Reserved Address 23 - 32: MQTT USERNAME
const int BUFFER_USERNAME_ADDR = BUFFER_PORT_ADDR + BUFFER_PORT_LEN + 1;
const int BUFFER_USERNAME_LEN  = LOGIN_USERNAME_LEN;

// ECCX08 Slot 8 - Setup (max 72 bytes)
// Reserved Address  0 - 2: boolean Options
uint32_t xbit[20] = {
  // Reserved Address 0
  xbit[0]  = (uint32_t)&_ALARM_(),
  xbit[1]  = (uint32_t)&_BACKUPONFLASH_(),
  xbit[2]  = (uint32_t)&_BACKUPONSD_(),
  xbit[3]  = (uint32_t)&_BATTERYAUTOONOFF_(),
  xbit[4]  = (uint32_t)&_BATTERYBOOSTER_(),
  xbit[5]  = (uint32_t)&_BATTERYCHARGING_(),
  xbit[6]  = (uint32_t)&_CLIENTLOOP_(),
  xbit[7]  = (uint32_t)&_DEBUG_(),
  // Reserved Address 1
  xbit[8]  = (uint32_t)&_DEBUGTRACK_(),
  xbit[9]  = (uint32_t)&_LOGBOOK_(),
  xbit[10] = (uint32_t)&_MODUL_(),
  xbit[11] = (uint32_t)&_MQTT_(),
  xbit[12] = (uint32_t)&_OLED_(),
  xbit[13] = (uint32_t)&_PUBLISHDATA_(),
  xbit[14] = (uint32_t)&_REBOOT_(),
  xbit[15] = (uint32_t)&_RESTORE_(),
  // Reserved Address 2
  xbit[16] = (uint32_t)&_RGBLED_(),
  xbit[17] = (uint32_t)&_SENSORS_(),
  xbit[18] = (uint32_t)&_WATCHDOG_(),
  xbit[19] = (uint32_t)&_WLAN_()
};

struct XTable4Pointers {
  uint32_t pointer;
  int      sizeOfData;
};

XTable4Pointers x[10] = {
  // Reserved Address 3 - 42 Data Options
  // Reserved Address flashStartAddress sensors
  { x[0].pointer = (uint32_t)&sensorsFirst, \
    x[0].sizeOfData = sizeof(uint32_t) 
  },
  // Reserved Address last address of sensors data
  { x[1].pointer = (uint32_t)&sensorsLastDataAddr, \
    x[1].sizeOfData = sizeof(uint32_t) 
  },
  // Reserved Address Temperature Offset
  { x[2].pointer = (uint32_t)&sensors.temperatureOffset, \
    x[2].sizeOfData = sizeof(float) 
  },
  // Reserved Address flashStartAddress logbook
  { x[3].pointer = (uint32_t)&logbookFirst, \
    x[3].sizeOfData = sizeof(uint32_t)
  },
  // Reserved Address last address of logbook data
  { x[4].pointer = (uint32_t)&logbookLastDataAddr, \
    x[4].sizeOfData = sizeof(uint32_t)
  },
  // Reserved Address scheduled alarm
  { x[5].pointer = (uint32_t)&state.freq.alarm, \
    x[5].sizeOfData = sizeof(uint32_t)
  },
  // Reserved Address state.freq.backupRecordOnFlash
  { x[6].pointer = (uint32_t)&state.freq.backupRecordOnFlash, \
    x[6].sizeOfData = sizeof(uint32_t)
  },
  // Reserved Address state.freq.pubSensor
  { x[7].pointer = (uint32_t)&state.freq.pubSensor, \
    x[7].sizeOfData = sizeof(uint32_t)
  },
  // Reserved Address errorCount WLAN reboot
  { x[8].pointer = (uint32_t)&state.errorCount.wlan.reboot, \
    x[8].sizeOfData = sizeof(uint32_t)
  },  
  // Reserved Address errorCount MQTT reboot
  { x[9].pointer = (uint32_t)&state.errorCount.mqtt.reboot, \
    x[9].sizeOfData = sizeof(uint32_t)
  }
};

//  ECCX08 functions___________________________________________________
void clearBuffer() {
  for (int i = 0; i < sizeof(bufferECCX08); i++)
    bufferECCX08[i] = '\0';
}

void* save(void* destination, void* source, size_t count) {
  memcpy(destination, source, count);
  return destination + count;
}

void saveXbit() {
  size_t countXbit = sizeof(xbit) / sizeof(xbit[0]);
  size_t countXbyte = countXbit/8 + 1; // 8bit = 1 byte
  byte byte_;
  int  z = 0;
  
  next = bufferECCX08;
  for (int i = 0; i < countXbyte; i++) {
    byte_ = 0;
    for (int j = 0; j < 8 && z < countXbit; j++) {
      byte_ += (byte)*(byte *)xbit[z] << j;
      z++;
    }
   next = save(next, &byte_, sizeof(byte));
  }
}

void saveSetupECCX08() {
  sensorsFirst        = sensors.first;
  sensorsLastDataAddr = sensors.lastDataAddr;
  logbookFirst        = logbook.first;
  logbookLastDataAddr = logbook.lastDataAddr;

  // Save Boolean Options
  saveXbit();

  // Save Data Options
  void* next = bufferECCX08 + 6;
  for (int i = 0; i < 10; i++) {
    next = save(next, (uint32_t *)x[i].pointer, x[i].sizeOfData);
  }

  saveECCX08("Setup options saved in Slot ", SLOT_SETUP);
}

void saveECCX08(const char *message, const int slot) {
  snprintf(s, sizeof(s), PSTR("%s %d"), message, slot);
  xSerial.printDateTimeln(MSG_ECCX08, s);
  // if (_DEBUG_()) {
  //  printPageBytes((uint32_t)bufferECCX08, (byte *)bufferECCX08, sizeof(bufferECCX08));
  //  Serial.println();
  //}
  ECCX08.begin();
  ECCX08.writeSlot(slot, bufferECCX08, sizeof(bufferECCX08));
  ECCX08.lock();
  ECCX08.end();
  initRTC();
}

void* load(void* destination, void* source, size_t count) {
  memcpy(destination, source, count);
  return source + count;
}

void loadXbit() {
  size_t countXbit = sizeof(xbit) / sizeof(xbit[0]);
  size_t countXbyte = countXbit/8 + 1; // 8bit = 1 byte
  next = bufferECCX08;
  byte byte_ = 0;
  int z = 0;
  for (int i = 0; i < countXbyte; i++) {
    next = load(&byte_, next,sizeof(byte));
    for (int j = 0; j < 8 && z < countXbit; j++) {
      *(boolean *)xbit[z] = byte_ >> j & 1;  
      z++;
    }
  }
}

void loadSetupECCX08() {
  loadECCX08("setup options loaded from ECCX08 Slot ", SLOT_SETUP);
  // if (_DEBUG_()) {
  //  for (int i = 0; i < sizeof(bufferECCX08); i++)
  //      Serial.print((char)bufferECCX08[i]);
  // }

  // Load Boolean Options
  loadXbit();

  // Load data Options
  void* next = bufferECCX08 + 6;
  for (int i = 0; i < 10; i++) {
    next = load((uint32_t *)x[i].pointer, next, x[i].sizeOfData);
  }
  sensors.setFirstPointerAddress(sensorsFirst);
  sensors.setLastDataAddress(sensorsLastDataAddr);
  sensors.setSizeOfReservedBuffer();
  sensors.setMaxNumOfRecords();
  logbook.setFirstPointerAddress(logbookFirst);
  logbook.setLastDataAddress(logbookLastDataAddr);
  logbook.setSizeOfReservedBuffer();
  logbook.setMaxNumOfRecords();
}

void loadECCX08(const char *message, const int slot) {
  snprintf(s, sizeof(s), PSTR("%s %d"), message, slot);
  xSerial.printDateTimeln(MSG_ECCX08, s);
  clearBuffer();
  ECCX08.begin();
  ECCX08.readSlot(slot, bufferECCX08, sizeof(bufferECCX08));
  ECCX08.end();
  // if (_DEBUG_()) {
  //  printPageBytes((uint32_t)bufferECCX08, (byte *)bufferECCX08, sizeof(bufferECCX08));
  // }
  initRTC();
}

void writeBufferStr(String str, int addr, int len) {
  xString.clearBuffer((const char *)(bufferECCX08 + addr), len, 0);
  byte *ptr = (byte *)(bufferECCX08 + addr);
  for (int i = 0; i < str.length(); i++)
    *ptr++ =  str[i];
  // if (_DEBUG_()) {
  //  printPageBytes((uint32_t)bufferECCX08, (byte *)bufferECCX08, sizeof(bufferECCX08));
  //}
}
