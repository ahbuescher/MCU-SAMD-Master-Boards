// Copyright 2019 <Hermann Buescher>
#ifndef CLASSLOGIN_H_
#define CLASSLOGIN_H_
#include <Arduino.h>
#include "./Defines.h"
#include "./ClassTrigger.h"

extern char s[S_LEN_OF_SERIALBUFFER];

struct LoginData {
  char server[LOGIN_SERVERNAME_LEN];
  int  port;
  char username[LOGIN_USERNAME_LEN];
  char password[LOGIN_PASSWORD_LEN];
};

class Login {
 public:
  Login();
  LoginData *get();

  void set(char *server, char *password);
  void set(char *server, int port, char *username); 

 private:
  LoginData _data;
};


#endif  // CLASSLOGIN_H_
