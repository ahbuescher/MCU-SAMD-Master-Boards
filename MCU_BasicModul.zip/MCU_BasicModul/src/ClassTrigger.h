// Copyright 2020 <Hermann Buescher>
#ifndef CLASSTRIGGER_H_
#define CLASSTRIGGER_H_

#include <Arduino.h>

class Function {
 public:
  static boolean alarm;
  static boolean airQualityAlarm;
  static boolean backupOnSD;
  static boolean batteryAutoOnOff;
  static boolean batteryCharging;
  static boolean batteryBooster;
  static boolean backupRecordOnFlash;
  static boolean clientLoop;
  static boolean debug;
  static boolean debugTrack;
  static boolean exitCmd;
  static boolean logbook;
  static boolean modul;
  static boolean mqtt;
  static boolean mqttBegin;
  static boolean mqttPublished;
  static boolean oled;
  static boolean oledInit;
  static boolean publishData;
  static boolean reboot;
  static byte    restore;
  static boolean rgbLed;
  static boolean securityMode;
  static boolean sensors;
  static boolean toSubscribeMQTT;
  static boolean watchDog;
  static boolean wlan;


  void init();
};
 
#endif  // CLASSTRIGGER_H_
