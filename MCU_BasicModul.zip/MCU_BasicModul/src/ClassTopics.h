// Copyright 2019 <Hermann Buescher
#ifndef CLASSTOPICS_H_
#define CLASSTOPICS_H_

#include <Arduino.h>
#include "./ClassLogin.h"

// Defined Topics
// client
#define TP_CLIENT          "client/"
#define TP_CONF_PLUS       "/conf/#"
#define TP_SWITCH_PLUS     "/switch/#"
#define TP_STATUS          "/status"


// Sensors
#define TP_AIRQ            "/sensor/airquality"
#define TP_AIRQ_CATEGORY   "/sensor/airquality/category"
#define TP_HUMID           "/sensor/humidity"
#define TP_PRESSURE        "/sensor/pressure"
#define TP_LIGHT           "/sensor/light"
#define TP_TIMESTAMP       "/sensor/report"
#define TP_TEMP            "/sensor/temperature"


// Server

String tp_User(String username);
String tp_Device(String username, String device);
String tp_DeviceStatus(String username, String device, String id);

#endif  // CLASSTOPICS_H_
