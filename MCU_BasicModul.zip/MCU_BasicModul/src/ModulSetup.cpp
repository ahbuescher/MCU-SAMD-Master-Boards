// Copyright 2020 <Hermann Buescher>
#include "./ModulSetup.h"

void modulSetup() {
  
  // Init BUZZER, LED
  pinMode(BUZZER, OUTPUT);
  pinMode(LED_BUILTIN, OUTPUT);

  // Hello world!
  digitalWrite(LED_BUILTIN, HIGH);
  // playTones(TUNE_STARTUP);

  // Start of security mode 
  _SECURITYMODE_() = true;

  // Initiate Wire Library
  Wire.begin();

  // Init Real Time Clock
  initRTC();

  _MODUL_()    = true;   // always running
  _DEBUG_()    = false;  // RTC is not yet running!
  _EXIT_()     = false;  // during start phase
  _LOGBOOK_()  = false;  // Set off logbook during first setup phase 
  _OLEDINIT_() = false;  // init OLED only once !

  // Init Flash capacity
  flashGetCapacity();

  // Restore parameters & variables from ECCX08
  execLoadSetup();

  // Setup Sensors and Logbook data fields
  sensorsSetup();
  logbookSetup();
  
  // Reboot after daily backup (rebootCounter>max)
  // Reactivate WLAN/MQTT, if connections were broken 
  state.countCheckerAfterReboot();

  // disable WatchDog
  // if (_WATCHDOG_()) {
  //  Watchdog.disable(); 
  // When WLAN is deactivated, WatchDog will be enabled.
  // }

  // Set factory settings if no settings have been made
  if (_RESTORE_() == false)
    func.init();  

  // Wait for serial connection in RESTORE or DEBUG-Mode
  if ((_RESTORE_() == false) || _DEBUG_() || _DEBUGTRACK_()) {
    while (!Serial)
      errLeds(1);
  }

  // Start-up process is interrupted 
  if ((_RESTORE_() == false) || _DEBUG_() || _DEBUGTRACK_()) {
    // in RESTORE or DEBUG-Mode
    modulCommand_();
  } else {
    // when ESC is pressed. Continue in DEBUG Mode
    blink.fast();
    if (wait4Serialread(4000, ESC))
      modulCommand_();
    blink.deselect();
    digitalWrite(LED_BUILTIN, HIGH);
  }

  // Set control Flags for time event management,\
  // ErrorCounts and Freq Flags
  state.init();

  // Init logbook pointer
  if (_LOGBOOK_())
    logbook.initPointer();

  // Init sensors pointer
  if (_SENSORS_() && _BACKUPONFLASH_())
    sensors.initPointer();

 // now ready for logbook entries
  _EXIT_() = true;

  xSerial.printDateTimeln(MSG_SYS, "System is booting...!");
  snprintf(s, sizeof(s), PSTR("Version %s - edition Dr. Peter B."), BASICMODUL_VERSION);
  xSerial.printDateTimeln(MSG_SYS, s);
  xSerial.printDateTimeln(MSG_SYS, "Loaded data from ECCX08");

  // Configure Battery Controller
  if (_DEBUG_()) {
    snprintf(s, sizeof(s), PSTR("PMIC charging mode is %s"),\
                           bool2OnOff(_BATTERYCHARGING_()).c_str());
    xSerial.printDateTimeln(MSG_BAT, s);
  }
  pmic.configure();

  // Init OLED
  if (_OLED_())
     displayInit();

  // Init BME680
  sensors.bme680init();

  // Init Light Sensor
  pinMode(LIGHT_SENSOR, INPUT);

  // Init WLAN
  if (_WLAN_())
    beginWiFi();

  // Init MQTT
  if (_MQTT_()) {
    beginMQTT();
  }

  if (_DEBUG_()) {
    snprintf(s, sizeof(s),PSTR("free RAM = %8d"), freeMemory());
    xSerial.printDateTimeln(MSG_SYS, s);
  }

  // update time
  state.updateTimeForEvent();

  // End of security mode
  _SECURITYMODE_() = false;

  digitalWrite(LED_BUILTIN, LOW);
}




