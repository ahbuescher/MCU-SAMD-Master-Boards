// Copyright 2021 <Hermann Buescher>
#include "./ClassTable.h"

Table::Table(TableStruct linkToElements[]) :
    element(linkToElements)
{

}

char *Table::findText(int key) {
  int last = element[0].key;
  for (int i = 1; i < last; i++) {
    if (key == element[i].key) {
      return element[i].text;
    }
  }
  return element[0].text;
}

