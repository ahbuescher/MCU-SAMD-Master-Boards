// Copyright 2019 <Hermann Buescher>
#include "./ModulLogbook.h"

void logbookSetup() {
  //  Init logbook dataField
  logbook.overrun = false;
  logbook.recName = "Logbook";
  logbook.numOfFieldElements = 5;
  logbook.setSizeOfRecordData(sizeof(LogbookData));
  logbook.setSizeOfReservedBuffer();
  logbook.setMaxNumOfRecords();
  logbook.dataField[0] = {"RecId",\
                          (uint32_t)&logbook.data.recordId,\
                           type_record, 5};  
  logbook.dataField[1] = {"Date",\
                         (uint32_t)&logbook.data.date.year,\
                          type_date};      
  logbook.dataField[2] = {"Time",\
                          (uint32_t)&logbook.data.time.hour,\
                          type_time};  
  logbook.dataField[3] = {"ErrCode",\
                          (uint32_t)&logbook.data.errCode,\
                          type_int, 2};   
  logbook.dataField[4] = {"Message",\
                          (uint32_t)&logbook.data.message,\
                           type_string, LBK_LEN_OF_MESSAGE}; 
}

void browseLogbook() {
  String   target   = MSG_LOGBK;
  String   cmd      = "";
  int32_t recordId = 0;
  int32_t pageSize = LBK_PAGESIZE; 

  logbook.initPointer();
  while (true) {    
    if (cmd == "EX") {
       break;
    } else if (logbook.getNumOfRecords() == 1) {
      xSerial.println("> Logbook is empty!");
      break;
    } else {
      pageSize = LBK_PAGESIZE;
      if (cmd == "--") {
        recordId = 0;
      } else if (cmd == "++") {
        recordId = logbook.getNumOfRecords() -1 - pageSize;
      } else if (cmd == "-") {
        recordId = recordId - pageSize; 
      } else if (cmd == "+") {
        recordId = recordId + pageSize;
      } else if (isDigit(cmd.charAt(0))) {
        recordId = (int32_t)cmd.toInt() - 1;
      } else {
        printBrowseLogbookHelp();
      }
      recordId = adjustRecordId(recordId, pageSize);
      pageSize = adjustPageSize(recordId, pageSize);
      Serial.println();
      printLogbookRecords(recordId, pageSize);
    }
    // read command and use the first 2 digits (text)
    Serial.print(">#" + target + " ");
    cmd = readSerialStringCmd(2);
  }
  xSerial.println("");
}

uint32_t adjustRecordId(int32_t recordId, int32_t pageSize) {
  if (recordId > (int32_t)logbook.getNumOfRecords() -1) {
    recordId = logbook.getNumOfRecords() -1 - pageSize;
  }
  if (recordId < 0) {
    recordId = 0;
  }
  return recordId;
} 

uint32_t adjustPageSize(int32_t recordId, int32_t pageSize) {
  if (pageSize > (int32_t)logbook.getNumOfRecords() -1 - recordId) {
    pageSize = logbook.getNumOfRecords() -1 - recordId;
  }
  if (pageSize == 0) {
    xSerial.println("Record out of scope");
  }
  return pageSize;
}

void printLogbookRecords(uint32_t recordId, uint32_t pageSize) {
  uint32_t addr;
  addr = logbook.first + recordId * logbook.getSizeOfRecordData(); 
  if (flashBegin()) {
    for (int i = 0; i < pageSize; i++) {
      Serial.println(logbook.getRecord(addr));
      addr = logbook.getNext(addr);
    }
    deselectFlash();
  }
}

void printBrowseLogbookHelp() {
  // char s[80];
  xSerial.println("");
  logbook.report(s, sizeof(s));
  xSerial.println("#Please enter command:");  
  xSerial.println("# recordId   : xxxxxx[0..9]"); 
  xSerial.println("# first page : --             last page  : ++");
  xSerial.println("# prev page  :  -             next page  :  +");
  xSerial.println("# list errors: er[rors]");  
  xSerial.println("# Exit       : ex[it]");
  Serial.println("");
}




