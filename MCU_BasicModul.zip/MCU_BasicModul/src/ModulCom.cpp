// Copyright <Hermann Buescher>

#include "./ModulCom.h"

TableStruct encryptionTypeDesc[] = {{7, "unkown type"},\
              {ENC_TYPE_WEP,"WEP"},  \
              {ENC_TYPE_TKIP,"WPA" },\
              {ENC_TYPE_CCMP,"WPA2"},\
              {ENC_TYPE_NONE,"None"},\
              {ENC_TYPE_AUTO,"Auto"},\
              {ENC_TYPE_UNKNOWN,"Unknown"}};

TableStruct wifiErrorStatusDesc[] = {{12,"unkown type"},\
              {WL_NO_SHIELD,"WL_NO_SHIELD/ MODULE"},    \
              {WL_IDLE_STATUS,"WL_IDLE_STATUS"},        \
              {WL_NO_SSID_AVAIL,"WL_NO_SSID_AVAIL"},    \
              {WL_SCAN_COMPLETED,"WL_SCAN_COMPLETED"},  \
              {WL_CONNECTED,"WL_CONNECTED"},            \
              {WL_CONNECT_FAILED,"WL_CONNECT_FAILED"},  \
              {WL_CONNECTION_LOST,"WL_CONNECTION_LOST"},\
              {WL_DISCONNECTED,"WL_DISCONNECTED"},      \
              {WL_AP_LISTENING,"WL_AP_LISTENING"},      \
              {WL_AP_CONNECTED,"WL_AP_CONNECTED"},      \
              {WL_AP_FAILED,"WL_AP_FAILED"}};

TableStruct MQTTErrorStatusDesc[] = {{15,"unkown type"},                            \
              {LWMQTT_SUCCESS,"LWMQTT_SUCCESS"},                                    \
              {LWMQTT_BUFFER_TOO_SHORT,"LWMQTT_BUFFER_TOO_SHORT"},                  \
              {LWMQTT_VARNUM_OVERFLOW,"LWMQTT_VARNUM_OVERFLOW"},                    \
              {LWMQTT_NETWORK_FAILED_CONNECT,"LWMQTT_NETWORK_FAILED_CONNECT"},      \
              {LWMQTT_NETWORK_TIMEOUT,"LWMQTT_NETWORK_TIMEOUT"},                    \
              {LWMQTT_NETWORK_FAILED_READ,"LWMQTT_NETWORK_FAILED_READ"},            \
              {LWMQTT_NETWORK_FAILED_WRITE,"LWMQTT_NETWORK_FAILED_WRITE"},          \
              {LWMQTT_REMAINING_LENGTH_OVERFLOW,"LWMQTT_REMAINING_LENGTH_OVERFLOW"},\
              {LWMQTT_REMAINING_LENGTH_MISMATCH,"LWMQTT_REMAINING_LENGTH_MISMATCH"},\
              {LWMQTT_MISSING_OR_WRONG_PACKET,"LWMQTT_MISSING_OR_WRONG_PACKET"},    \
              {LWMQTT_CONNECTION_DENIED,"LWMQTT_CONNECTION_DENIED"},                \
              {LWMQTT_FAILED_SUBSCRIPTION,"LWMQTT_FAILED_SUBSCRIPTION"},            \
              {LWMQTT_SUBACK_ARRAY_OVERFLOW,"LWMQTT_SUBACK_ARRAY_OVERFLOW"},        \
              {LWMQTT_PONG_TIMEOUT,"LWMQTT_PONG_TIMEOUT"}};

TableStruct MQTTReturnCodeDesc[] = {{8,"unkown type"},                              \
              {LWMQTT_CONNECTION_ACCEPTED,"LWMQTT_CONNECTION_ACCEPTED"},            \ 
              {LWMQTT_UNACCEPTABLE_PROTOCOL,"LWMQTT_UNACCEPTABLE_PROTOCOL"},        \
              {LWMQTT_IDENTIFIER_REJECTED,"LWMQTT_IDENTIFIER_REJECTED"},            \
              {LWMQTT_SERVER_UNAVAILABLE,"LWMQTT_SERVER_UNAVAILABLE"},              \
              {LWMQTT_BAD_USERNAME_OR_PASSWORD,"LWMQTT_BAD_USERNAME_OR_PASSWORD"},  \
              {LWMQTT_NOT_AUTHORIZED,"LWMQTT_NOT_AUTHORIZED"},                      \
              {LWMQTT_UNKNOWN_RETURN_CODE,"LWMQTT_UNKNOWN_RETURN_CODED"}};

Table tbl_encryptionType(encryptionTypeDesc);
Table tbl_wifiErrorStatus(wifiErrorStatusDesc);
Table tbl_MQTTErrorStatus(MQTTErrorStatusDesc);
Table tbl_MQTTReturnCode(MQTTReturnCodeDesc);

//  WLAN_______________________________________________________________

int WL_Status = WL_IDLE_STATUS;  // the Wifi radio's status

WiFiClient net;

void beginWiFi() {
  // Load Login Data
  loadECCX08("SSID and Password loaded from Slot ", SLOT_SSID_PWD);
  loginWLAN.set((char*)bufferECCX08,                                  \
                (char*)(bufferECCX08 + BUFFER_PWD_ADDR));
  // check WiFi module
  if (WiFi.status() == WL_NO_MODULE) {
    xSerial.printDateTimeln(MSG_WLAN, "Communication with WiFi module failed!");
      errLeds(10);
  }
  if (_DEBUG_())
    listNetworks();
}

void listNetworks() {
  String string;
  int    thisType;
  int    numSsid;
  xSerial.printDateTimeln(MSG_WLAN, "Scan Networks...");
  if (!_EXIT_())
    xSerial.printDateTimeln(MSG_WLAN, "Please wait and be patient! :-)");
  numSsid = WiFi.scanNetworks();
  if (numSsid == -1) {
    xSerial.printDateTimeln(MSG_WLAN, "error - couldn't get a wifi connection!");
    for (int i = 0; i < 10; i++)
      errLeds(50);
  }
  snprintf(s, sizeof(s), PSTR("%d WLAN access points found!"),numSsid);
  xSerial.printDateTimeln(MSG_WLAN, s);
  for (int thisNet = 0; thisNet < numSsid; thisNet++) {
    thisType = WiFi.encryptionType(thisNet);
    snprintf(s, sizeof(s), PSTR("%d: %s; %d dBm %s"),\
                          thisNet + 1,\
                          WiFi.SSID(thisNet),\
                          WiFi.RSSI(thisNet),\
                          tbl_encryptionType.findText(thisType));
    xSerial.printDateTimeln(MSG_WLAN, s);
  }
}

void printWifiErrorStatus(int thisType) {
  int errCode = ERRCODE_WLAN + thisType;
  if (thisType == WL_CONNECTED)
    xSerial.printDateTimeln(MSG_WLAN, \
                          tbl_wifiErrorStatus.findText(thisType));
  else
    xSerial.printDateTimeln(MSG_WLAN,\
                          tbl_wifiErrorStatus.findText(thisType),\
                          errCode);
}

void printMQTTErrorStatus(int thisType) {
  int errCode = ERRCODE_MQTT + thisType;
  if (thisType == LWMQTT_SUCCESS)
    xSerial.printDateTimeln(MSG_MQTT, tbl_MQTTErrorStatus.findText(thisType));
  else
    xSerial.printDateTimeln(MSG_MQTT, tbl_MQTTErrorStatus.findText(thisType), errCode);
}

void printMQTTReturnCode(int thisType) {
  int errCode = ERRCODE_MQTT_RETURNCODE + thisType;
  if (thisType == LWMQTT_CONNECTION_ACCEPTED)
    xSerial.printDateTimeln(MSG_MQTT, tbl_MQTTReturnCode.findText(thisType));
  else
    xSerial.printDateTimeln(MSG_MQTT, tbl_MQTTReturnCode.findText(thisType), errCode);
}

boolean connectStatusWLAN() {
  boolean connected;
  if (_WLAN_()) {
    if (WiFi.status() == WL_CONNECTED) {
      connected = true;
    } else {
      connected = connect2WLAN_();
    }
  } else {
    connected = false;
  }
  return connected;
}

void disconnectWLAN() {
  WiFi.disconnect();
  if (_DEBUG_())
    printWifiErrorStatus(WiFi.status());
  xSerial.printDateTimeln(MSG_WLAN, "disconnected!");
}

boolean connect2WLAN_() {
  snprintf(s, sizeof(s), PSTR("login->SSID %s"),\
                              loginWLAN.get()->server);
  xSerial.printDateTimeln(MSG_WLAN, s);
  if (!_EXIT_())
    xSerial.printDateTimeln(MSG_WLAN, "Please wait and be patient! :-)");
  int i = 0;
  int wifiConnect = 0;

  // if NINA Status is disconnected, logoff
  if (WiFi.status() == WL_DISCONNECTED) {
    xSerial.printDateTimeln(MSG_WLAN, "Shutdown WLAN connection!");
    disconnectWLAN();
  }
  systemDelay(500);

  while (true) {
    playTones(TUNE_BOTTOM_BUTTON_PRESS);

    wifiConnect = WiFi.begin(loginWLAN.get()->server, \
                             loginWLAN.get()->password);
    systemDelay(LOGIN_DELAY_WLAN);
    if (_DEBUG_())
      printWifiErrorStatus(wifiConnect);

    if (wifiConnect != WL_CONNECTED) {
      i++;
      playTones(TUNE_TOP_BUTTON_PRESS);
      // login failed - try again/ cancel login/ reboot
      if (i > state.errorCount.wlan.tryPerLogin) {
        state.errorCount.wlan.login++;
        if (state.errorCount.wlan.login <= ERRORCOUNT_WLAN_MAX_TRY) {
          if (!_DEBUG_())
            printWifiErrorStatus(wifiConnect);
          playTones(TUNE_MOVE);
          systemDelay(2000);
          state.updateTimeForEvent();
          return false;
        } else {
          rebootOrDeactivate(MSG_WLAN);
          state.updateTimeForEvent();
          return false;
        }
      }
    } else {
      // wifiConnect == WL_CONNECTED
      xSerial.printDateTimeln(MSG_WLAN, "connected!");
      state.clearErrorCountWLAN_();
      state.updateTimeForEvent();
      return true;   
    }
  }
}

void testWiFiConnection() {
  if (xSerial.ask("Scan WiFi connections?") == "Y") {
    listNetworks();
  }
  state.clearErrorCountWLAN_();
  if (connectStatusWLAN()) {
    xSerial.printDateTimeln(MSG_WLAN, "passed connection test!");
  }
}

//  MQTT_______________________________________________________________

const size_t capacityMQTT = CAPACITY_MQTT;
MQTTClient client(capacityMQTT);

const char key[]    = "";  // broker key
const char secret[] = "";  // broker secret


void beginMQTT() {
  _MQTTBEGIN_() = true;
  loadECCX08("IPAddress and Port loaded from Slot ", SLOT_MQTT);
  loginMQTT.set((char*) bufferECCX08,\
           atoi((char*)(bufferECCX08 + BUFFER_PORT_ADDR)), \
                (char*)(bufferECCX08 + BUFFER_USERNAME_ADDR));
  if (connectStatusWLAN()) {
    snprintf(s, sizeof(s), PSTR("login->IP: %s/%d user: %s"),\
                                loginMQTT.get()->server,\
                                loginMQTT.get()->port,\
                                loginMQTT.get()->username);
    xSerial.printDateTimeln(MSG_MQTT, s);
    client.begin(loginMQTT.get()->server, loginMQTT.get()->port, net);
    systemDelay(LOGIN_DELAY_MQTT);
  } else {
    xSerial.printDateTimeln(MSG_MQTT,  "error - no WiFi connection", ERRCODE_WLAN);
    errLeds(2);
  }
}

boolean disconnectMQTT() {
  if (client.disconnect()) {
    if (_CLIENTLOOP_())
      xSerial.printDateTimeln(MSG_MQTT, "disconnected!");
  } else {
    xSerial.printDateTimeln(MSG_MQTT, "not connected!");
    if (_DEBUG_())
      printMQTTErrorStatus(client.lastError());
  }
}

boolean connectStatusMQTT() {
  boolean connected;
  if (_MQTT_()) {
    if (client.connected()) {
      connected = true;
    } else {
      connected = connect2MQTT_();
    }
  } else {
    connected = false;
  }
  return connected;
}

boolean connect2MQTT_() {
  if (connectStatusWLAN()) {
    int i = 0;
    bool connected = false;
    while (true) {
      if (_CLIENTLOOP_())
        playTones(TUNE_BOTTOM_BUTTON_PRESS);
      if (!_EXIT_()) {
        snprintf(s, sizeof(s), PSTR("login->IP: %s/%d user: %s"),\
                                loginMQTT.get()->server,\
                                loginMQTT.get()->port,\
                                loginMQTT.get()->username);
        xSerial.printDateTimeln(MSG_MQTT, s);
        xSerial.printDateTimeln(MSG_MQTT, "Please be patient! :-)");
      }
      if (!_MQTTBEGIN_()) {
        _MQTTBEGIN_() = true;
        beginMQTT();
      }
      connected = client.connect(loginMQTT.get()->username, key, secret);
      systemDelay(LOGIN_DELAY_MQTT);

      if (_DEBUG_()) {
        printMQTTReturnCode(client.returnCode());
        printMQTTErrorStatus(client.lastError());          
      }
        
      if (!connected) {
        i++;
        // login failed - try again/ cancel login/ reboot
        if (i > state.errorCount.mqtt.tryPerLogin) {
          playTones(TUNE_MOVE);
          systemDelay(2000);
          state.errorCount.mqtt.login++;
          if (state.errorCount.mqtt.login <= ERRORCOUNT_MQTT_MAX_TRY) {
            if (!_DEBUG_()) {
              printMQTTReturnCode(client.returnCode());
              printMQTTErrorStatus(client.lastError());  
            }
            state.updateTimeForEvent();
            return false;
          } else {
            rebootOrDeactivate(MSG_MQTT);
            state.updateTimeForEvent();
            return false;
          }
        }
      } else {
        // MQTT is connected
        if (_CLIENTLOOP_()) {
          xSerial.printDateTimeln(MSG_MQTT, "connected!");
          clientPublish(tp_User(loginMQTT.get()->username), "online");
          subscribe();
        }
        state.clearErrorCountMQTT_();
        state.updateTimeForEvent();
        return true;
      }
    }
  } else {
     xSerial.printDateTimeln(MSG_MQTT, "error - no WiFi connection!");
     errLeds(2);
     return false;
  }
}

boolean loopMQTT_() {
  boolean ok;
  Watchdog.enable(8000);
  ok = client.loop();
  Watchdog.disable(); 
  if (ok) {
    delay(50);   // helps eventually
    return true;
  } else
    return false;
}


boolean repairLoopMQTT_() {  
  xSerial.printDateTimeln(MSG_MQTT, "client loop error!", ERRCODE_MQTT);
  
  int wifiConnected = WiFi.status();
  
  if (_DEBUG_()) {
      // Wifi Error status?
      printWifiErrorStatus(wifiConnected);
      // MQTT ReturnCode and Error status?
      // Get MQTT error codes, see
      //   https://github.com/256dpi/lwmqtt/blob/master/include/lwmqtt.h#L11) 
      //   https://github.com/256dpi/lwmqtt/blob/master/include/lwmqtt.h#L243)
      printMQTTReturnCode(client.returnCode());
      printMQTTErrorStatus(client.lastError());
  }  
 
  // close and cleanup the current connection and start over
  // by creating a new connection.
  disconnectMQTT();
    
  // if no WiFi connection, try to reconnect
  if (wifiConnected != WL_CONNECTED) {
    xSerial.printDateTimeln(MSG_WLAN, "try to reconnect!");
    connect2WLAN_();
  }
    
  // reconnect MQTT
  xSerial.printDateTimeln(MSG_MQTT, "try to reconnect!");
  connect2MQTT_();
    
  // check client loop again
  if (loopMQTT_()) {
    // connection repaired
    xSerial.printDateTimeln(MSG_MQTT, "client loop is ok!");  
    return true;
  } else {
    // system reboot
    rebootOrDeactivate(MSG_MQTT);
    state.updateTimeForEvent();
    return false;
  }
}

void subscribe(){
  // config data
  client.subscribe(tp_Device(loginMQTT.get()->username, TP_CONF_PLUS));
  snprintf(s, sizeof(s), PSTR("subscribed to %s"), \
                              loginMQTT.get()->username, TP_CONF_PLUS);
  xSerial.printDateTimeln(MSG_MQTT, s);
  // switches
  client.subscribe(tp_Device(loginMQTT.get()->username, TP_SWITCH_PLUS));
  snprintf(s, sizeof(s), PSTR("subscribed to %s"), \
                              loginMQTT.get()->username, TP_SWITCH_PLUS);
  xSerial.printDateTimeln(MSG_MQTT, s);
}

void publishSensorsState() {                        // virtual function
  int i = 0;
  if (connectStatusMQTT()) {
    i += clientPublish(tp_Device(loginMQTT.get()->username, TP_TIMESTAMP), \
                          now.timestamp());
    i += clientPublish(tp_Device(loginMQTT.get()->username, TP_TEMP), \
                          String(sensors.data.temperature));
    i += clientPublish(tp_Device(loginMQTT.get()->username, TP_HUMID),\
                          String(sensors.data.humidity));
    i += clientPublish(tp_Device(loginMQTT.get()->username, TP_PRESSURE),\
                          String(sensors.data.pressure));
    i += clientPublish(tp_Device(loginMQTT.get()->username, TP_AIRQ_CATEGORY),\
                          String(sensors.pubIAQStatus()));
    i += clientPublish(tp_Device(loginMQTT.get()->username, TP_AIRQ), \
                          String(sensors.data.iaq));
    i += clientPublish(tp_Device(loginMQTT.get()->username, TP_LIGHT),\
                          String(sensors.data.light));

    if (i == 7) {
      xSerial.printDateTimeln(MSG_MQTT, "sensor data published!");
      _MQTTPUBLISHED_() = true;
      if (!_CLIENTLOOP_()) {
        disconnectMQTT();
      }
    } else {
      snprintf(s, sizeof(s), PSTR("error - not all sensor data published (%i)"), i);
      xSerial.printDateTimeln(MSG_MQTT, s, ERRCODE_MQTT); 
    }
  }
}

int clientPublish(String topic, String message) {
    int returnCode = client.publish(topic, message);
    if (_DEBUG_() || returnCode != 1) {
      printMQTTReturnCode(client.returnCode());
      printMQTTErrorStatus(client.lastError()); 
    }
    return returnCode;
}

void rebootOrDeactivate(String string) {
  blink.fast();
  if (_WATCHDOG_()\
      && state.errorCount.wlan.reboot <= ERRORCOUNT_REBOOT_MAX_TRY 
      && state.errorCount.mqtt.reboot <= ERRORCOUNT_REBOOT_MAX_TRY ) {
    
    if (_MQTT_())
      disconnectMQTT();
    disconnectWLAN();   
    
    // increment reboot error counter and reboot
    int errCode;
    if (string == MSG_WLAN) {
      errCode = ERRCODE_WLAN;
      state.errorCount.wlan.reboot++;
      if (_MQTT_())
        state.errorCount.mqtt.reboot++;
    } else if (string == MSG_MQTT) {
      errCode = ERRCODE_MQTT;
      state.errorCount.mqtt.reboot++;
    }
    saveSetupECCX08();

    if (_WLAN_()) {
      systemReboot("WLAN - login failed!", errCode);
    } else if (_MQTT_()) {
      systemReboot(" MQTT - login failed!", errCode);
    }

    
    // in case of too many reboots (due to failed connections):
    // - reset reboot error counter and deactivate WLAN/MQTT functions
    // - wait for the daily backup. This will force a reboot to
    //   reactivate WLAN and MQTT. 
  } else {
    _MQTT_() = false;
    if (string == MSG_WLAN) {
      _WLAN_() = false;
      state.errorCount.wlan.reboot = ERRCODE_DISABLED;
      xSerial.printDateTimeln(MSG_WLAN, "WiFi-Server is down. WiFi + MQTT are deactivated!", ERRCODE_WLAN);
    } else {
      state.errorCount.mqtt.reboot = ERRCODE_DISABLED;
      xSerial.printDateTimeln(MSG_MQTT, "MQTT-Server is down. MQTT is deactivated!", ERRCODE_MQTT);  
    }
    saveSetupECCX08();
  }
}

String wiFiIPAddress() {
  char ipAddress[20] = {0};
  IPAddress ip = WiFi.localIP();
  byte *x = (byte *)&ip + 4;
  snprintf(ipAddress, sizeof(ipAddress), "%u.%u.%u.%u", \
                    *x, *(x+1), *(x+2), *(x+3));
  return ipAddress;
}

void testMQTTConnection() {
  if (_WLAN_()) {
    if (_MQTT_()) {
      // state.clearErrorCountMQTT_();
      if (connectStatusMQTT()) {
        xSerial.printDateTimeln(MSG_MQTT, "MQTT passed connection test!");
      }
    } else {
      xSerial.printDateTimeln(MSG_MQTT, "MQTT is off!");
    }
  } else {
        xSerial.printDateTimeln(MSG_WLAN, "WiFi is off!");
  }
}
