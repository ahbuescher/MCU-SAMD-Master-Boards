// Copyright 2020 <Hermann Buescher>
#ifndef MODULTHINGS_H_
#define MODULTHINGS_H_

#include <Arduino.h>
#include <Adafruit_SleepyDog.h>
#include <Wire.h>                 // I2C
#include <SPIMemory.h>            // Flash memory
#include <SD.h>
#include <RTClib.h>
#include <Arduino_PMIC_own.h>     // BQ24195
#include <Adafruit_GFX.h>         // OLED
#include <Adafruit_SSD1306.h>     // OLED
#include <WiFiNINA.h>             // WIFI
#include <MQTT.h>                 // MQTT
#include <utility/wifi_drv.h>     // RGB_LED
#include "./ClassTones.h"         // Buzzer TONES
#include "./Defines.h"
#include "./ClassLED.h"
#include "./ClassBattery.h"
#include "./ClassState.h"
#include "./ClassSensors.h"
#include "./ModulSensors.h"
#include "./ClassLogbook.h"
#include "./ModulLogbook.h"
#include "./ClassTrigger.h"
#include "./ClassXFunctions.h"
#include "./DisplayOther.h"       // Display Own Text

// ECCX08______________________________________________________________
void  saveSetupECCX08();

//  Battery____________________________________________________________
extern PMIC pmic;

void    chargingCompleted();
void    pmicController();
void    pmicController_AU();
void    pmicController_PB();
void    pmicController_PM();
void    pmicController_CH();
void    printPMICHelp();
void    SerialprintPMICStatus();
void    SerialprintPMICStatus_list();
void    setChargeCurrent();
void    updateLowBatteryFlag();

//  Buzzer_____________________________________________________________

void    playTones(int tune);


//  Flash functions___________________________________________________
extern uint32_t flashCapacity;

void    eraseFlash();
boolean eraseFlashBlock64K(uint32_t first, uint32_t size);
boolean flashBegin();
void    flashGetCapacity();
void    flashprintCapacity();
void    deselectFlash();
void    selectFlash();

//  OLED_______________________________________________________________
extern  Sensors    sensors;
extern  MQTTClient client;

void    displayClear();
void    deselectOLED();
boolean displayBegin();
void    displayDisplay();
void    displayInit();
void    displayText(String string);
void    displayPrintOther();
void    selectOLED();

//  RTC________________________________________________________________

struct Time {
  uint8_t hour;
  uint8_t minute;
  uint8_t second;
};

struct Date {
  uint16_t year;
  uint8_t  month;
  uint8_t  day;
};

extern RTC_DS3231 rtc;
extern DateTime   now;

void    initRTC();
String  inttoStrHH_MM(int i);
String  itoStrTime(int hour, int minute, int second);
String  itoStrDate(int year, int month, int day);
Time    strtoTime(String str);
Date    strtoDate(String str);
boolean validTime(Time time);
boolean validDate(Date date);
boolean validTimeString(String time);

// SD-Card functions____________________________________________________

void      fullBackupOnSD_Card();
boolean   checkSD_Card();
void      dateTime(uint16_t* date, uint16_t* time);
void      deselectSD_Card();
void      selectSD_Card();
boolean   SD_CardBegin();

//  Logbook functions___________________________________________________
extern Logbook logbook;
void logbookBackupRecordOnFlash(char *messageType,\
                               char *message, \
                               int   errCode);

// System_______________________________________________________________
extern  State state;

void systemDelay(int waits);
void systemReboot(const char *message, int code = 0);
void systemReboot_checkOnFuncDisabled();
void _commandMode(boolean enable);

// String
String   bool2OnOff(int i);
String   bool2YesNo(int i);
int      onOff2bool(String string);
String   readSerialStringCmd(int len);
void     SerialprintOptionTextln(int width, char *t,  char *u);
void     SerialprintOptionOnOffln(int width, char *t, boolean option);
void     SerialprintDateTimeOptionTextln(int width, char *t, char *u);
void     SerialprintDateTimeOptionFloatln(int width, char *t, float x, char *voltAmper);
void     SerialprintDateTimeOptionOnOffln(int width, char *t, boolean option);
void     SerialprintDateTimeOptionYesNoln(int width, char *t, boolean option);
void     SerialprintBuffer(char *buffer, int len);
boolean  wait4Serialread(uint long waits = 1000, char c = ESC);
extern   XString xString;

// Debug
void printPageBytes(uint32_t addr, byte *data_buffer, int size);
void dumpBuffer();
void printDumpHelp();

//  Error
void    errLeds(int j);


#endif  // MODULTHINGS_H_
