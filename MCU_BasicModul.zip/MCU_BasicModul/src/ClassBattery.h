// Copyright 2021 <Hermann Buescher>
#ifndef CLASSBATTERY__H_
#define CLASSBATTERY__H_

#include <Arduino.h>
#include "./Defines.h"
#include "./ClassTrigger.h"
#include <Wire.h>                 // I2C
#include <RTClib.h>
#include <Arduino_PMIC_own.h>     // BQ24195
#include "./ClassTones.h"
#include "./ClassLED.h"
#include "./ClassXFunctions.h"

extern RTC_DS3231  rtc;
extern char s[S_LEN_OF_SERIALBUFFER];

//  #include ModulThings
// RGBLED
void  analogwrite_RGB_LED(int green, int red, int blue);
// Battery
float updateBatteryVoltage();
void batteryConnection();

// String
String bool2YesNo(int i);
void  SerialprintBatteryStatus();
//  Error
void  errLeds(int j);

struct MessageStruct {
   int  key;
   char text[40];
};

class PMIC_Object {
  public:
   char     *name;
   char      *message;
   int       code;
   MessageStruct *description;
   DateTime  time;
   float     voltage;
   boolean   newEvent;
   
   void    init();
   boolean update(int actCode);
   char    *findText(int key);
};

class PMIC:public PMICClass {
  public:
   PMIC():PMICClass(Wire) {};
   boolean      chargerEnabled;
   boolean      boosterEnabled;
   boolean      BATFETEnabled;
   boolean      batteryConnected;
   boolean      chargingCompleted;
   boolean      chargingError;
   DateTime     timeOfLowBattery;
   boolean      lowBattery;
   float        voltage;
   RGBLED       rgbLED;

   PMIC_Object  bqChargeStatus;
   PMIC_Object  bqChargeFault;
   PMIC_Object  bqVBusStatus;
   PMIC_Object  bqTermalFault;
   
   boolean batteryConnection();
   boolean chargingORTermal_Errors();
   void    configure();
   boolean enableBATFET(boolean enable);
   boolean enableBooster(boolean enable);
   boolean enableCharger(boolean enable);
   boolean error(PMIC_Object object);
   boolean lowBatteryVoltage();
   void    setLedStatusOn();
   void    init();
   void    init_ADC_BATTERY_PORT(); // not used
   boolean isADC_BATTERYPresent();
   boolean powerConnection();
 
   void    setColorOfChargingCompleted();
   void    setColorOfChargeStatus();
   void    setColorOfChargingError();
   void    setColorOfLowVoltage();
   void    setColorLEDOff();
   boolean update();
   float   updateBatteryVoltage();
};

extern PMIC pmic;
extern PMIC_Object  bqChargeStatus;
extern PMIC_Object  bqChargeFault;
extern PMIC_Object  bqVBusStatus;
extern PMIC_Object  bqTermalFault;

#endif //  CLASSBATTERY_H_