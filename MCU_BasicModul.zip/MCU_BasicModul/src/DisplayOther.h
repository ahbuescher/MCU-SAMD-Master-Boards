// Copyright 2021 <Hermann Buescher>
#ifndef DISPLAYOTHER_H_
#define DISPLAYOTHER_H_

#include "./Defines.h"
#include <Adafruit_SSD1306.h>     // OLED

void displayOther(Adafruit_SSD1306 display);

#endif DISPLAYOTHER_H_