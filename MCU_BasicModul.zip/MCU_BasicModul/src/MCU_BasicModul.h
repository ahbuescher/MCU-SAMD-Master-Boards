// Copyright 2019 <Hermann Buescher>
#ifndef MCU_BASICMODUL_H_
#define MCU_BASICMODUL_H_

#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <RTClib.h>               // RTC
#include <WiFiNINA.h>             // WIFI
#include <MemoryFree.h>
#include "./Defines.h"
#include "./ClassLED.h"
#include "./ClassBattery.h"
#include "./ClassSensors.h"
#include "./ClassLogbook.h"
#include "./ModulThings.h"
#include "./ClassState.h"
#include "./ModulSetup.h"
#include "./ModulCommand.h"
#include "./ClassTopics.h"

extern RangeOfInteger rangeOfInteger;
extern RangeOfFloat rangeOfFloat;
extern MQTTClient   client;
extern SensorData   sensorData;
extern Sensors      sensors;
extern Logbook      logbook;
extern TimeStamp    timeStamp;
extern State        state;
extern Function     func;
extern Login        loginWLAN;
extern Login        loginMQTT;
extern char s[S_LEN_OF_SERIALBUFFER];

class BasicModul {
 public:
  BasicModul();

  virtual boolean loopMQTT();
  virtual void command();
  void    commandMode(boolean enable);
  boolean connect2MQTT();
  boolean connect2WLAN();
  virtual void onMessageMQTT();
  void    setup();
  void    update();
};


#endif  // MCU_BASICMODUL_H_
