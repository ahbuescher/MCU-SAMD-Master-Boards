// Copyright 2021 <Hermann Buescher>
#ifndef CLASSLED__H_
#define CLASSLED__H_

#include <Arduino.h>
#include "./Defines.h"
#include <WiFiNINA.h>
#include <utility/wifi_drv.h>

extern char s[S_LEN_OF_SERIALBUFFER];
                            
// Reds
#define xRED           255, 0, 0
#define xFIREBRICK     178, 34, 34
#define xDARK_RED      139, 0, 0
// Pinks
#define xDEEP_PINK     255, 20, 147
// Organges 
#define xORANGE_RED    255, 69, 0
#define xDARK_ORANGE   255, 140, 0
#define xORANGE        255, 165, 0
// Yellows
#define xGOLD          255, 215, 0
#define xYELLOW        255, 255, 0
// Purples
#define xMAGENTA       255, 0, 255
#define xPURPLE        128, 0 , 128
// Greens
#define xGREEN_YELLOW  173, 255, 47
#define xLIME          0, 255, 0
#define xSPRING_GREEN  0, 255, 127
#define xGREEN         0, 128, 0
#define xDARK_GREEN    0, 100, 0
// Blues/Cyans
#define xCYAN          0, 255, 255
#define xBLUE          0, 0, 255
#define xMEDIUM_BLUE   0, 0, 205
#define xNAVY_BLUE     0, 0, 128
#define xNAV_BLUE_1    0, 24, 128
#define xNAV_BLUE_2    0, 48, 128

// Whites
#define xWHITE         255, 255, 255
// Greys
#define xSILVER        192, 192,192
#define xBLACK         0, 0, 0


class RGBLED {
 public:
  RGBLED(int red, int green, int blue);
  RGBLED();
  boolean on;
  boolean toggle;

  void analogWrite_RGB_LED(int red, int green, int blue);
  void brightness(int rgb[3], int brightness);
  void brightness(int red, int green, int blue, int brightness);
  void init_RGB_LED_PORT();
  void intensity(int red, int green, int blue, int brightness);
  void off();
  void setColor(int rgb[3]);
  void setColor(int red, int green, int blue);
  void toggleColor(int red, int green, int blue, int red1, int green1, int blue1);

 private:
  int _pinRED, _pinGREEN, _pinBLUE;

};

class Blink {
 public:
  Blink(uint32_t period);
  Blink();
  boolean led;

  void selectPWM();
  void deselectPWM();
  void deselect();
  void busy();
  void fast();
  void slow();
  void verySlow();
  
 private:
  uint32_t _period;
  void enableTCC0();
  void disableTCC0();
  void timer_GCLK5_TCC0_PA21(int prescale, int percentOfdutyCycle);
};

extern RGBLED rgbLED;
extern Blink blink;
#endif //  CLASSLED_H_