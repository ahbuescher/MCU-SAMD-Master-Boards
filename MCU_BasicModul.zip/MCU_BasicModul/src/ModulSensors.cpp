// Copyright 2019 <Hermann Buescher>
#include "./ModulSensors.h"

void sensorsSetup() {
  sensors.recName = "Sensors";
  sensors.numOfFieldElements = 8;
  // SensorData
  sensors.setSizeOfRecordData(sizeof(sensorData));
  sensors.setSizeOfReservedBuffer();
  sensors.setMaxNumOfRecords();

  sensors.dataField[0]  = {"RecId",\
                          (uint32_t)&sensors.data.recordId,\
                          type_record, 5};
  sensors.dataField[1]  = {"Date",\
                          (uint32_t)&sensors.data.date.year,\
                          type_date};
  sensors.dataField[2]  = {"Time",\
                          (uint32_t)&sensors.data.time.hour,\
                           type_time};
  sensors.dataField[3]  = {"Temperature",\
                           (uint32_t)&sensors.data.temperature,\
                           type_float};
  sensors.dataField[4]  = {"Pressure",\
                           (uint32_t)&sensors.data.pressure,\
                           type_float};
  sensors.dataField[5]  = {"Humidity",\
                           (uint32_t)&sensors.data.humidity,\
                           type_float};
  sensors.dataField[6]  = {"IAQ",\
                          (uint32_t)&sensors.data.iaq,\
                           type_float};
  sensors.dataField[7]  = {"Light",\
                           (uint32_t)&sensors.data.light,\
                           type_float};
}
