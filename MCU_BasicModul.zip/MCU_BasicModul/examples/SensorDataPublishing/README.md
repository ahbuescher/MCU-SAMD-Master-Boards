// Copyright 2021 <Hermann Buescher>
//
// Basic Modul example
// 
// Die Kommunikation erfolgt über die Serielle Schnittstelle.
//   Mit # kommt man in den Command Mode und kann die verschiedenen
//   Funktionen des Moduls einstellen.
//
// Clock: 
//   Einstellung Datum   : da[te]        (DDMMYYYY)
//   Einstellung Zeit    : ti[me]        (SSMMHH)
//
// WLAN/MQTT
//   WLAN                : wl[an]        (Y/N, SSID, Password)
//   MQTT                : mq[tt]        (Y/N, user, Password, Port)
//
// Sensors - BME 680 und Lichtstärke
//    Publizieren        : pub[mqtt]     (Y/N)
//    Sensoren           : se[nsors]     (Y/N, Flash addr 0 - 1.500.000,
//                                             size       1 - 1000KB)
//
// Other
//    Battery            : ba[ttery]     => *** Battery Controller Mode ***
//    OLED-Display       : ol[ed]        (Y/N)
//    RGB-LED            : rg[led]       (Y/N) - Must be OFF in BLE Mode
//
// Backup
//    Flash löschen      : er[flash]
//    Logbuch            : lo[gbook]     (Y/N, Flash addr 0 - 1.500.000
//                                             size       1 - 1000KB)
//    Backup auf SD-Card : sd[card]      (Y/N  HHMM)
//
// ECCX08 
//    Lade Setup            : lx[ECCX08] (Parameter, Passwörter)
//    Sichere Setup         : sx[[ECCX08](Parameter, Passwörter)
//
// Debug
//    Debug Mode            : de[bug]    (Y/N)
//    Debug tracking        : dt[track]  (Y/N)
//    Dump Memory           : du[ump]    => **+ Dump Buffer Mode ***
//    Liste Setup           : li[st]
//    SRAM Memory Belegung  : me[mory]   (Y/N , SRAM Adress, DRAM Adress)
//
//  Reboot
//    System reboot         : [re]bo[ot] (Y/N  immediate or daily (HHMM)
//
//  Reset
//    System reset          : re[set]    = alle Einstellungen werden gelöscht!
//    Wacht Dog             : wa[tchDog] = System Neustart
//
//  Exit
//    Exit Command Mode     : ex[it]     (Y/N) 