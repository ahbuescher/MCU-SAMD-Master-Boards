# MCU_SAMD21J18 - Bootloader
# HB
# update 07/01/2020

Der Bootloader wurde mit Atmel Studio erstellt auf Basis des Makefiles. 
Der USB Driver ist MKR1010.

samd21_sam_ba.atsln

Achtung: aktuelle CMSIS und arm-none-eabi-gcc Verweise !

MODULE_PATH?=$(LOCALAPPDATA)/Arduino15/packages/arduino

ARM_GCC_PATH?=$(MODULE_PATH)/tools/arm-none-eabi-gcc/7-2017q4/bin/arm-none-eabi-
BUILD_PATH=build

BOARD_ID?=mcu_samd21j18
NAME?=samd21_sam_ba_mcu_j18

SAM_BA_INTERFACES?=SAM_BA_BOTH_INTERFACES
CFLAGS_EXTRA=-D__SAMD21J18A__ -DBOARD_ID_$(BOARD_ID) -D$(SAM_BA_INTERFACES)

Compiler Option - DEBUG deaktivieren, sonst gibt es einen Flash error!
#ifdef DEBUG
#  CFLAGS+=-g3 -O1 -DDEBUG=1
#else
CFLAGS+=-Os -DDEBUG=0 -flto
#endif


